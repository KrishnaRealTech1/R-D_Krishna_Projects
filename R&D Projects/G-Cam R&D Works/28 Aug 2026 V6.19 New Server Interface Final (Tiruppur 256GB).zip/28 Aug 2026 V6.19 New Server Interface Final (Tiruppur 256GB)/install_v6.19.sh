#!/usr/bin/env bash
set +H 2>/dev/null || true
set -euo pipefail

APP_DIR="/opt/gcam"
VENV_DIR="$APP_DIR/venv"

SERVICE_FILE="/etc/systemd/system/gcam.service"
CONTROLLER_SERVICE_FILE="/etc/systemd/system/gcam-controller.service"

APP_RESTART_SERVICE="/etc/systemd/system/gcam-app-restart.service"
APP_RESTART_TIMER="/etc/systemd/system/gcam-app-restart.timer"

PI_REBOOT_SERVICE="/etc/systemd/system/gcam-pi-reboot.service"
PI_REBOOT_TIMER="/etc/systemd/system/gcam-pi-reboot.timer"

MAINT_SERVICE="/etc/systemd/system/gcam-maintenance.service"
MAINT_TIMER="/etc/systemd/system/gcam-maintenance.timer"
MAINT_SCRIPT="/usr/local/bin/gcam-maintenance.sh"

BATTERY_SCRIPT="/usr/local/bin/read-battery-voltage.sh"
REBOOT_HELPER="/usr/local/bin/gcam-force-reboot.sh"

CLOUDFLARE_SERVICE_FILE="/etc/systemd/system/cloudflared.service"
CLOUDFLARE_TOKEN_DIR="/etc/gcam"
CLOUDFLARE_TOKEN_FILE="$CLOUDFLARE_TOKEN_DIR/cloudflared.token"
CLOUDFLARE_WATCHDOG_SCRIPT="/usr/local/bin/gcam-cloudflare-watchdog.sh"
CLOUDFLARE_WATCHDOG_SERVICE="/etc/systemd/system/gcam-cloudflare-watchdog.service"
CLOUDFLARE_WATCHDOG_TIMER="/etc/systemd/system/gcam-cloudflare-watchdog.timer"
CLOUDFLARE_METRICS_ADDR="127.0.0.1:20241"
CLOUDFLARE_READY_URL="http://${CLOUDFLARE_METRICS_ADDR}/ready"
LEGACY_CLOUDFLARE_PING_SCRIPT="/usr/local/bin/gcam-cloudflare-ping.sh"
LEGACY_CLOUDFLARE_PING_SERVICE="/etc/systemd/system/gcam-cloudflare-ping.service"

SUDOERS_FILE="/etc/sudoers.d/gcam-reboot"
GCAM_CONTROLLER_SUDOERS_FILE="/etc/sudoers.d/gcam-controller"

PI_USER="${SUDO_USER:-$USER}"
PI_HOME="$(getent passwd "$PI_USER" | cut -d: -f6)"

DEFAULT_RTSP_URL="rtsp://admin:Rts@12345@192.168.22.225:554/video/live?channel=1&subtype=0"
DEFAULT_CLOUDFLARE_LIVE_RTSP_URL="rtsp://admin:Rts@12345@192.168.22.225:554/video/live?channel=1&subtype=1"
DEFAULT_PI_IP="192.168.22.101"
DEFAULT_ROUTER_IP="192.168.22.1"
DEFAULT_CAMERA_IP="192.168.22.225"
DEFAULT_CAMERA_NAME="RTGCAMx"
DEFAULT_DEVICE_ID="RTGCAMx"
DEFAULT_CAMERA_CONFIG_URL="http://192.168.22.225"

DEFAULT_SUBDOMAIN_NAME="rtgcamx"
DEFAULT_BASE_DOMAIN="ifill.in"
DEFAULT_ENABLE_PERMANENT_CLOUDFLARE="yes"
DEFAULT_CLOUDFLARE_PROTOCOL="auto"

DEFAULT_MQTT_HOST="gcam-ftp.rtsiot.com"
DEFAULT_MQTT_PORT="1883"
DEFAULT_MQTT_USERNAME="realiot"
DEFAULT_MQTT_PASSWORD="realmqtt@123"
DEFAULT_MQTT_GARBAGE_TOPIC=""
DEFAULT_MQTT_CAMERA_EVENT_TOPIC="RTGCAMx/camera_event"
DEFAULT_MQTT_COMMAND_TOPIC="RTGCAMx/command"
DEFAULT_MQTT_RESPONSE_TOPIC="RTGCAMx/device_response"
DEFAULT_MQTT_COMMAND_TOKEN="GCAM_SECRET_123"

DEFAULT_TAILSCALE_MAIL_ID="krishna.realtechs1@gmail.com"

DEFAULT_SFTP_HOST="sb-ftpgcam.rtsiot.com"
DEFAULT_SFTP_PORT="20222"
DEFAULT_SFTP_USERNAME="ftpuser"
DEFAULT_SFTP_PASSWORD='ftp123!@#'
: "${DEFAULT_SFTP_HOST:=sb-ftpgcam.rtsiot.com}"
: "${DEFAULT_SFTP_PORT:=20222}"
: "${DEFAULT_SFTP_USERNAME:=ftpuser}"
if [[ -z "${DEFAULT_SFTP_PASSWORD+x}" ]]; then
  DEFAULT_SFTP_PASSWORD='ftp123!@#'
fi
DEFAULT_SFTP_BASE_DIR="/ftp/files/${DEFAULT_DEVICE_ID}"
DEFAULT_SFTP_PERSON_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Person"
DEFAULT_SFTP_PERSON_VIDEO_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Video/Person_Video"
DEFAULT_SFTP_VEHICLE_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Vehicle"
DEFAULT_SFTP_VEHICLE_VIDEO_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Video/Vehicle_Video"
DEFAULT_SFTP_GARBAGE_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Garbage"
DEFAULT_SFTP_AUDIO_DIR="/ftp/files/${DEFAULT_DEVICE_ID}/Audio"

DEFAULT_BATTERY_MODE="command"
DEFAULT_BATTERY_SYSFS_PATH=""
DEFAULT_BATTERY_COMMAND="$BATTERY_SCRIPT"
DEFAULT_BATTERY_DIVIDER_RATIO="1.0"

DEFAULT_REBOOT_TIME_1="03:00:00"
DEFAULT_REBOOT_TIME_2="15:00:00"
DEFAULT_ENABLE_PI_REBOOT_TIMER="no"

DEFAULT_RECORDING_RESERVE_GB="3.0"

DEFAULT_ROUTER_REBOOT_TIME_1="03:30"
DEFAULT_ROUTER_REBOOT_TIME_2="15:30"


echo "=================================================="
echo " G-Cam Full Clean Reinstall - V6.19 MQTT DVR Controls + Storage Playback + New Server Interface"
echo " Substream AI/Live + Mainstream HQ Upload + Data Status"
echo " + Open/Close Software + Camera Permanent URL"
echo " + Person False Detection Fix"
echo " + Garbage and Live Audio Removed"
echo "=================================================="
echo

read -rp "Enter Device ID [${DEFAULT_DEVICE_ID}]: " DEVICE_ID
DEVICE_ID="${DEVICE_ID:-$DEFAULT_DEVICE_ID}"

read -rp "Enter Camera Name [${DEFAULT_CAMERA_NAME}]: " CAMERA_NAME
CAMERA_NAME="${CAMERA_NAME:-$DEFAULT_CAMERA_NAME}"

read -rp "Enter Main RTSP URL for HIGH-QUALITY image/video upload [${DEFAULT_RTSP_URL}]: " RTSP_URL
RTSP_URL="${RTSP_URL:-$DEFAULT_RTSP_URL}"

read -rp "Enter Sub RTSP URL for AI detection + live view [${DEFAULT_CLOUDFLARE_LIVE_RTSP_URL}]: " CLOUDFLARE_LIVE_RTSP_URL
CLOUDFLARE_LIVE_RTSP_URL="${CLOUDFLARE_LIVE_RTSP_URL:-$DEFAULT_CLOUDFLARE_LIVE_RTSP_URL}"

if echo "$RTSP_URL" | grep -Eqi '/ch[0-9]+/sub/|/sub/'; then
  echo "ERROR: Main RTSP URL points to SUB stream. SFTP still images need MAIN stream." >&2
  echo "Use: rtsp://user:pass@camera-ip:554/h264/ch1/main/av_stream" >&2
  exit 1
fi

if echo "$CLOUDFLARE_LIVE_RTSP_URL" | grep -Eqi '/ch[0-9]+/main/|/main/'; then
  echo "WARNING: Sub RTSP URL appears to point to MAIN stream. AI/live should use SUB stream." >&2
fi

read -rp "Enter Raspberry Pi Local IP [${DEFAULT_PI_IP}]: " PI_IP
PI_IP="${PI_IP:-$DEFAULT_PI_IP}"

read -rp "Enter Router IP [${DEFAULT_ROUTER_IP}]: " ROUTER_IP
ROUTER_IP="${ROUTER_IP:-$DEFAULT_ROUTER_IP}"

read -rp "Enter Camera IP [${DEFAULT_CAMERA_IP}]: " CAMERA_IP
CAMERA_IP="${CAMERA_IP:-$DEFAULT_CAMERA_IP}"

read -rp "Enter Camera Configuration URL [${DEFAULT_CAMERA_CONFIG_URL}]: " CAMERA_CONFIG_URL
CAMERA_CONFIG_URL="${CAMERA_CONFIG_URL:-$DEFAULT_CAMERA_CONFIG_URL}"

read -rp "Enter Permanent Subdomain Name [${DEFAULT_SUBDOMAIN_NAME}]: " SUBDOMAIN_NAME
SUBDOMAIN_NAME="${SUBDOMAIN_NAME:-$DEFAULT_SUBDOMAIN_NAME}"

read -rp "Enter Base Domain [${DEFAULT_BASE_DOMAIN}]: " BASE_DOMAIN
BASE_DOMAIN="${BASE_DOMAIN:-$DEFAULT_BASE_DOMAIN}"

SUBDOMAIN_NAME="$(echo "$SUBDOMAIN_NAME" | tr '[:upper:]' '[:lower:]' | xargs)"
BASE_DOMAIN="$(echo "$BASE_DOMAIN" | tr '[:upper:]' '[:lower:]' | xargs)"

if ! [[ "$SUBDOMAIN_NAME" =~ ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$ ]]; then
  echo "ERROR: Invalid Cloudflare subdomain: $SUBDOMAIN_NAME" >&2
  exit 1
fi

if ! [[ "$BASE_DOMAIN" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$ ]] || [[ "$BASE_DOMAIN" != *.* ]]; then
  echo "ERROR: Invalid Cloudflare base domain: $BASE_DOMAIN" >&2
  exit 1
fi

PERMANENT_LIVE_BASE_URL="https://${SUBDOMAIN_NAME}.${BASE_DOMAIN}"
PERMANENT_CAMERA_CONFIG_URL="${PERMANENT_LIVE_BASE_URL}/camera"
PERMANENT_HEALTH_URL="${PERMANENT_LIVE_BASE_URL}/api/state"
LOCAL_HEALTH_URL="http://127.0.0.1:8080/api/state"

EXISTING_CLOUDFLARE_TUNNEL_TOKEN=""
if sudo test -s "$CLOUDFLARE_TOKEN_FILE" 2>/dev/null; then
  EXISTING_CLOUDFLARE_TUNNEL_TOKEN="$(sudo cat "$CLOUDFLARE_TOKEN_FILE" 2>/dev/null || true)"
fi

read -rp "Configure permanent named Cloudflare Tunnel on this Pi? [${DEFAULT_ENABLE_PERMANENT_CLOUDFLARE}]: " ENABLE_PERMANENT_CLOUDFLARE
ENABLE_PERMANENT_CLOUDFLARE="${ENABLE_PERMANENT_CLOUDFLARE:-$DEFAULT_ENABLE_PERMANENT_CLOUDFLARE}"
ENABLE_PERMANENT_CLOUDFLARE="$(echo "$ENABLE_PERMANENT_CLOUDFLARE" | tr '[:upper:]' '[:lower:]' | xargs)"
case "$ENABLE_PERMANENT_CLOUDFLARE" in
  y|yes|true|1) ENABLE_PERMANENT_CLOUDFLARE="yes" ;;
  *) ENABLE_PERMANENT_CLOUDFLARE="no" ;;
esac

CLOUDFLARE_TUNNEL_TOKEN=""
CLOUDFLARE_PROTOCOL="$DEFAULT_CLOUDFLARE_PROTOCOL"

if [[ "$ENABLE_PERMANENT_CLOUDFLARE" == "yes" ]]; then
  echo
  echo "Cloudflare permanent tunnel configuration"
  echo "The Cloudflare dashboard route must map ${SUBDOMAIN_NAME}.${BASE_DOMAIN} to http://localhost:8080"

  if [[ -n "$EXISTING_CLOUDFLARE_TUNNEL_TOKEN" ]]; then
    read -rsp "Paste Cloudflare tunnel token, or press Enter to reuse the installed token: " CLOUDFLARE_TUNNEL_TOKEN
  else
    read -rp "Paste Cloudflare tunnel token: " CLOUDFLARE_TUNNEL_TOKEN
  fi
  echo

  CLOUDFLARE_TUNNEL_TOKEN="${CLOUDFLARE_TUNNEL_TOKEN//$'\r'/}"

  # Accept the full command copied from Cloudflare Dashboard as a convenience.
  if [[ "$CLOUDFLARE_TUNNEL_TOKEN" == *"cloudflared"* && "$CLOUDFLARE_TUNNEL_TOKEN" == *"service install"* ]]; then
    CLOUDFLARE_TUNNEL_TOKEN="${CLOUDFLARE_TUNNEL_TOKEN##* }"
  fi

  if [[ -z "$CLOUDFLARE_TUNNEL_TOKEN" ]]; then
    CLOUDFLARE_TUNNEL_TOKEN="$EXISTING_CLOUDFLARE_TUNNEL_TOKEN"
  fi

  if [[ -z "$CLOUDFLARE_TUNNEL_TOKEN" ]]; then
    echo "ERROR: Permanent Cloudflare is enabled, but no tunnel token was supplied." >&2
    echo "Copy it from Cloudflare Dashboard -> Networking -> Tunnels -> your tunnel -> Add a replica." >&2
    exit 1
  fi

  if [[ "$CLOUDFLARE_TUNNEL_TOKEN" =~ [[:space:]] ]]; then
    echo "ERROR: Cloudflare tunnel token contains whitespace and is invalid." >&2
    exit 1
  fi

  read -rp "Cloudflare transport protocol: auto, http2 or quic [${DEFAULT_CLOUDFLARE_PROTOCOL}]: " CLOUDFLARE_PROTOCOL
  CLOUDFLARE_PROTOCOL="${CLOUDFLARE_PROTOCOL:-$DEFAULT_CLOUDFLARE_PROTOCOL}"
  CLOUDFLARE_PROTOCOL="$(echo "$CLOUDFLARE_PROTOCOL" | tr '[:upper:]' '[:lower:]' | xargs)"

  case "$CLOUDFLARE_PROTOCOL" in
    auto|http2|quic) ;;
    *)
      echo "ERROR: Cloudflare protocol must be auto, http2 or quic." >&2
      exit 1
      ;;
  esac
fi

read -rp "Enter Tailscale Mail ID [${DEFAULT_TAILSCALE_MAIL_ID}]: " TAILSCALE_MAIL_ID
TAILSCALE_MAIL_ID="${TAILSCALE_MAIL_ID:-$DEFAULT_TAILSCALE_MAIL_ID}"

echo
echo "MQTT configuration"
read -rp "Enter MQTT Host [${DEFAULT_MQTT_HOST}]: " MQTT_HOST
MQTT_HOST="${MQTT_HOST:-$DEFAULT_MQTT_HOST}"

read -rp "Enter MQTT Port [${DEFAULT_MQTT_PORT}]: " MQTT_PORT
MQTT_PORT="${MQTT_PORT:-$DEFAULT_MQTT_PORT}"

read -rp "Enter MQTT Username [${DEFAULT_MQTT_USERNAME}]: " MQTT_USERNAME
MQTT_USERNAME="${MQTT_USERNAME:-$DEFAULT_MQTT_USERNAME}"

read -rp "Enter MQTT Password [${DEFAULT_MQTT_PASSWORD}]: " MQTT_PASSWORD
MQTT_PASSWORD="${MQTT_PASSWORD:-$DEFAULT_MQTT_PASSWORD}"

MQTT_GARBAGE_TOPIC=""
# Garbage MQTT topic removed in Person + Vehicle only build.

read -rp "Enter MQTT Camera Event Topic [${DEFAULT_MQTT_CAMERA_EVENT_TOPIC}]: " MQTT_CAMERA_EVENT_TOPIC
MQTT_CAMERA_EVENT_TOPIC="${MQTT_CAMERA_EVENT_TOPIC:-$DEFAULT_MQTT_CAMERA_EVENT_TOPIC}"


read -rp "Enter MQTT Command Topic [${DEFAULT_MQTT_COMMAND_TOPIC}]: " MQTT_COMMAND_TOPIC
MQTT_COMMAND_TOPIC="${MQTT_COMMAND_TOPIC:-$DEFAULT_MQTT_COMMAND_TOPIC}"

read -rp "Enter MQTT Response Topic [${DEFAULT_MQTT_RESPONSE_TOPIC}]: " MQTT_RESPONSE_TOPIC
MQTT_RESPONSE_TOPIC="${MQTT_RESPONSE_TOPIC:-$DEFAULT_MQTT_RESPONSE_TOPIC}"

read -rp "Enter MQTT Command Token [${DEFAULT_MQTT_COMMAND_TOKEN}]: " MQTT_COMMAND_TOKEN
MQTT_COMMAND_TOKEN="${MQTT_COMMAND_TOKEN:-$DEFAULT_MQTT_COMMAND_TOKEN}"

echo
echo "SFTP configuration"
echo "IMPORTANT: Enter REAL LINUX PATH like /ftp/files/RTGCAMx"
SFTP_HOST_DEFAULT="${DEFAULT_SFTP_HOST:-sb-ftpgcam.rtsiot.com}"
SFTP_PORT_DEFAULT="${DEFAULT_SFTP_PORT:-20222}"
SFTP_USERNAME_DEFAULT="${DEFAULT_SFTP_USERNAME:-ftpuser}"
SFTP_PASSWORD_DEFAULT="${DEFAULT_SFTP_PASSWORD}"

read -rp "Enter SFTP Host [${SFTP_HOST_DEFAULT}]: " SFTP_HOST
SFTP_HOST="${SFTP_HOST:-$SFTP_HOST_DEFAULT}"

read -rp "Enter SFTP Port [${SFTP_PORT_DEFAULT}]: " SFTP_PORT
SFTP_PORT="${SFTP_PORT:-$SFTP_PORT_DEFAULT}"

read -rp "Enter SFTP Username [${SFTP_USERNAME_DEFAULT}]: " SFTP_USERNAME
SFTP_USERNAME="${SFTP_USERNAME:-$SFTP_USERNAME_DEFAULT}"

read -rp "Enter SFTP Password [${SFTP_PASSWORD_DEFAULT}]: " SFTP_PASSWORD
SFTP_PASSWORD="${SFTP_PASSWORD:-$SFTP_PASSWORD_DEFAULT}"

read -rp "Paste Main SFTP Path [${DEFAULT_SFTP_BASE_DIR}]: " SFTP_BASE_DIR
SFTP_BASE_DIR="${SFTP_BASE_DIR:-$DEFAULT_SFTP_BASE_DIR}"

read -rp "Paste Person SFTP Path [${DEFAULT_SFTP_PERSON_DIR}]: " SFTP_PERSON_DIR
SFTP_PERSON_DIR="${SFTP_PERSON_DIR:-$DEFAULT_SFTP_PERSON_DIR}"

read -rp "Paste Person Video SFTP Path [${DEFAULT_SFTP_PERSON_VIDEO_DIR}]: " SFTP_PERSON_VIDEO_DIR
SFTP_PERSON_VIDEO_DIR="${SFTP_PERSON_VIDEO_DIR:-$DEFAULT_SFTP_PERSON_VIDEO_DIR}"

read -rp "Paste Vehicle Image SFTP Path [${DEFAULT_SFTP_VEHICLE_DIR}]: " SFTP_VEHICLE_DIR
SFTP_VEHICLE_DIR="${SFTP_VEHICLE_DIR:-$DEFAULT_SFTP_VEHICLE_DIR}"

read -rp "Paste Vehicle Video SFTP Path [${DEFAULT_SFTP_VEHICLE_VIDEO_DIR}]: " SFTP_VEHICLE_VIDEO_DIR
SFTP_VEHICLE_VIDEO_DIR="${SFTP_VEHICLE_VIDEO_DIR:-$DEFAULT_SFTP_VEHICLE_VIDEO_DIR}"


SFTP_GARBAGE_DIR=""
SFTP_AUDIO_DIR=""
# Garbage and MQTT audio SFTP paths removed in Person + Vehicle only build.

if [[ "${SFTP_BASE_DIR}" != /* ]]; then
  SFTP_BASE_DIR="/${SFTP_BASE_DIR}"
fi
SFTP_BASE_DIR="${SFTP_BASE_DIR%/}"

if [[ "${SFTP_PERSON_DIR}" != /* ]]; then
  SFTP_PERSON_DIR="/${SFTP_PERSON_DIR}"
fi
SFTP_PERSON_DIR="${SFTP_PERSON_DIR%/}"

if [[ "${SFTP_PERSON_VIDEO_DIR}" != /* ]]; then
  SFTP_PERSON_VIDEO_DIR="/${SFTP_PERSON_VIDEO_DIR}"
fi
SFTP_PERSON_VIDEO_DIR="${SFTP_PERSON_VIDEO_DIR%/}"

if [[ "${SFTP_VEHICLE_DIR}" != /* ]]; then
  SFTP_VEHICLE_DIR="/${SFTP_VEHICLE_DIR}"
fi
SFTP_VEHICLE_DIR="${SFTP_VEHICLE_DIR%/}"

if [[ "${SFTP_VEHICLE_VIDEO_DIR}" != /* ]]; then
  SFTP_VEHICLE_VIDEO_DIR="/${SFTP_VEHICLE_VIDEO_DIR}"
fi
SFTP_VEHICLE_VIDEO_DIR="${SFTP_VEHICLE_VIDEO_DIR%/}"


echo
BATTERY_MODE="command"
BATTERY_SYSFS_PATH=""
BATTERY_COMMAND="$BATTERY_SCRIPT"
BATTERY_DIVIDER_RATIO="1.0"

echo "Battery interface enabled: INA226 via I2C command helper."
echo

echo
echo "Playback recording storage"
read -rp "Enter protected SD free space in GB (3 to 5) [${DEFAULT_RECORDING_RESERVE_GB}]: " RECORDING_RESERVE_GB
RECORDING_RESERVE_GB="${RECORDING_RESERVE_GB:-$DEFAULT_RECORDING_RESERVE_GB}"
if ! [[ "$RECORDING_RESERVE_GB" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
  echo "ERROR: Protected SD free space must be a number between 3 and 5 GB." >&2
  exit 1
fi
if ! awk -v value="$RECORDING_RESERVE_GB" 'BEGIN { exit !(value >= 3.0 && value <= 5.0) }'; then
  echo "ERROR: Protected SD free space must be between 3 and 5 GB." >&2
  exit 1
fi

echo
echo "Maintenance and reboot schedule"
read -rp "Enable automatic full Pi reboots twice daily? [${DEFAULT_ENABLE_PI_REBOOT_TIMER}]: " ENABLE_PI_REBOOT_TIMER
ENABLE_PI_REBOOT_TIMER="${ENABLE_PI_REBOOT_TIMER:-$DEFAULT_ENABLE_PI_REBOOT_TIMER}"
ENABLE_PI_REBOOT_TIMER="$(echo "$ENABLE_PI_REBOOT_TIMER" | tr '[:upper:]' '[:lower:]' | xargs)"
case "$ENABLE_PI_REBOOT_TIMER" in
  y|yes|true|1) ENABLE_PI_REBOOT_TIMER="yes" ;;
  *) ENABLE_PI_REBOOT_TIMER="no" ;;
esac

read -rp "Enter full Pi reboot time #1 [${DEFAULT_REBOOT_TIME_1}]: " REBOOT_TIME_1
REBOOT_TIME_1="${REBOOT_TIME_1:-$DEFAULT_REBOOT_TIME_1}"

read -rp "Enter full Pi reboot time #2 [${DEFAULT_REBOOT_TIME_2}]: " REBOOT_TIME_2
REBOOT_TIME_2="${REBOOT_TIME_2:-$DEFAULT_REBOOT_TIME_2}"

read -rp "Enter router reboot GPIO time #1 [${DEFAULT_ROUTER_REBOOT_TIME_1}]: " ROUTER_REBOOT_TIME_1
ROUTER_REBOOT_TIME_1="${ROUTER_REBOOT_TIME_1:-$DEFAULT_ROUTER_REBOOT_TIME_1}"

read -rp "Enter router reboot GPIO time #2 [${DEFAULT_ROUTER_REBOOT_TIME_2}]: " ROUTER_REBOOT_TIME_2
ROUTER_REBOOT_TIME_2="${ROUTER_REBOOT_TIME_2:-$DEFAULT_ROUTER_REBOOT_TIME_2}"

echo
echo "[1/17] Stop old services..."
sudo systemctl stop gcam.service 2>/dev/null || true
sudo systemctl disable gcam.service 2>/dev/null || true
sudo systemctl stop gcam-controller.service 2>/dev/null || true
sudo systemctl disable gcam-controller.service 2>/dev/null || true
sudo systemctl stop gcam-app-restart.timer 2>/dev/null || true
sudo systemctl disable gcam-app-restart.timer 2>/dev/null || true
sudo systemctl stop gcam-pi-reboot.timer 2>/dev/null || true
sudo systemctl disable gcam-pi-reboot.timer 2>/dev/null || true
sudo systemctl stop gcam-maintenance.timer 2>/dev/null || true
sudo systemctl disable gcam-maintenance.timer 2>/dev/null || true
sudo systemctl stop gcam-cloudflare-watchdog.timer 2>/dev/null || true
sudo systemctl disable gcam-cloudflare-watchdog.timer 2>/dev/null || true
sudo systemctl stop gcam-cloudflare-watchdog.service 2>/dev/null || true
sudo systemctl disable gcam-cloudflare-watchdog.service 2>/dev/null || true
sudo systemctl stop gcam-cloudflare-ping.service 2>/dev/null || true
sudo systemctl disable gcam-cloudflare-ping.service 2>/dev/null || true
sudo systemctl stop cloudflared.service 2>/dev/null || true
sudo systemctl disable cloudflared.service 2>/dev/null || true
sudo systemctl kill gcam.service 2>/dev/null || true
sudo systemctl kill gcam-controller.service 2>/dev/null || true
sudo pkill -9 -f "/opt/gcam/venv/bin/python /opt/gcam/app.py" 2>/dev/null || true
sudo pkill -9 -f "/opt/gcam/venv/bin/python /opt/gcam/controller.py" 2>/dev/null || true
sudo pkill -9 -f "cloudflared tunnel --url" 2>/dev/null || true
sudo pkill -9 aplay 2>/dev/null || true
sudo pkill -9 ffplay 2>/dev/null || true
# Stop any detached FFmpeg playback recorder that may still be writing old files.
sudo pkill -9 -f "$APP_DIR/files/recordings" 2>/dev/null || true
sudo rm -f \
  "$SERVICE_FILE" \
  "$CONTROLLER_SERVICE_FILE" \
  "$APP_RESTART_SERVICE" "$APP_RESTART_TIMER" \
  "$PI_REBOOT_SERVICE" "$PI_REBOOT_TIMER" \
  "$MAINT_SERVICE" "$MAINT_TIMER" \
  "$CLOUDFLARE_SERVICE_FILE" \
  "$CLOUDFLARE_WATCHDOG_SERVICE" "$CLOUDFLARE_WATCHDOG_TIMER" \
  "$LEGACY_CLOUDFLARE_PING_SERVICE"
sudo rm -f \
  "$MAINT_SCRIPT" \
  "$CLOUDFLARE_WATCHDOG_SCRIPT" \
  "$LEGACY_CLOUDFLARE_PING_SCRIPT" \
  "$SUDOERS_FILE" \
  "$GCAM_CONTROLLER_SUDOERS_FILE"
sudo systemctl daemon-reload || true

echo "[2/17] Erase old playback recordings and remove old app..."
# Clean reinstall must never reuse playback data from the previous installation.
# Delete the complete storage-based playback ring-buffer before recreating /opt/gcam.
if sudo test -d "$APP_DIR/files/recordings"; then
  echo "[INFO] Deleting old playback recordings from $APP_DIR/files/recordings ..."
  sudo rm -rf "$APP_DIR/files/recordings"
  sudo sync
  echo "[INFO] Old playback recordings erased."
else
  echo "[INFO] No old playback recordings found."
fi

# Remove the remaining old application files/data and rebuild everything cleanly.
sudo rm -rf "$APP_DIR"

echo "[3/17] Fix DNS if needed..."
if ! ping -c 1 deb.debian.org >/dev/null 2>&1; then
  sudo rm -f /etc/resolv.conf || true
  printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' | sudo tee /etc/resolv.conf >/dev/null
fi

echo "[4/17] Update apt..."
sudo apt-get update

echo "[5/17] Install system packages..."
sudo apt-get install -y \
  python3 python3-venv python3-pip python3-dev \
  python3-lgpio python3-smbus i2c-tools \
  ffmpeg alsa-utils espeak-ng curl wget ca-certificates jq sudo \
  iproute2 net-tools ethtool procps util-linux dnsutils netcat-openbsd \
  libgl1 libjpeg62-turbo libtiff6 libopenjp2-7 libopenblas-dev \
  gpiod
if dpkg -s libglib2.0-0t64 >/dev/null 2>&1; then
  sudo apt-get install -y libglib2.0-0t64
else
  sudo apt-get install -y libglib2.0-0
fi

sudo raspi-config nonint do_i2c 0 || true
sudo modprobe i2c-dev || true

echo "[6/17] Install cloudflared..."
ARCH="$(dpkg --print-architecture)"
CLOUDFLARED_DEB="$(mktemp /tmp/gcam-cloudflared.XXXXXX.deb)"
cleanup_cloudflared_deb() {
  rm -f "$CLOUDFLARED_DEB" 2>/dev/null || true
}
trap cleanup_cloudflared_deb EXIT

if [[ "$ARCH" == "arm64" ]]; then
  wget -q -O "$CLOUDFLARED_DEB" https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64.deb
elif [[ "$ARCH" == "armhf" ]]; then
  wget -q -O "$CLOUDFLARED_DEB" https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm.deb
else
  echo "Unsupported architecture for cloudflared package: $ARCH"
  exit 1
fi

if ! sudo dpkg -i "$CLOUDFLARED_DEB"; then
  sudo apt-get -f install -y
  sudo dpkg -i "$CLOUDFLARED_DEB"
fi

if [[ ! -x /usr/bin/cloudflared ]]; then
  echo "ERROR: /usr/bin/cloudflared was not installed." >&2
  exit 1
fi

CLOUDFLARED_VERSION="$(/usr/bin/cloudflared --version | awk '{print $3}')"
if ! dpkg --compare-versions "$CLOUDFLARED_VERSION" ge "2025.4.0"; then
  echo "ERROR: cloudflared ${CLOUDFLARED_VERSION} is too old for secure --token-file support." >&2
  echo "Required version: 2025.4.0 or newer." >&2
  exit 1
fi

# Backward-compatible path for older G-Cam controller builds.
sudo ln -sfn /usr/bin/cloudflared /usr/local/bin/cloudflared

echo "[INFO] Installed cloudflared version: ${CLOUDFLARED_VERSION}"

echo "[7/17] Configure ALSA default to USB speaker hw:0,0..."
sudo tee /etc/asound.conf >/dev/null <<'EOF'
pcm.!default {
    type plug
    slave.pcm "hw:0,0"
}

ctl.!default {
    type hw
    card 0
}
EOF
sudo pkill -9 aplay 2>/dev/null || true
sudo pkill -9 ffplay 2>/dev/null || true

echo "[8/17] Create folders..."
sudo mkdir -p "$APP_DIR"/{assets,data,logs,models,files,files/video,tmp,templates}
sudo chown -R "$PI_USER:$PI_USER" "$APP_DIR"

echo "[9/17] Create Python environment..."
python3 -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --upgrade pip setuptools wheel
"$VENV_DIR/bin/pip" install \
  flask==3.0.3 \
  waitress==3.0.0 \
  numpy==1.26.4 \
  opencv-python-headless==4.10.0.84 \
  requests==2.32.3 \
  urllib3==2.2.2 \
  paho-mqtt==2.1.0 \
  paramiko==3.4.0 \
  psutil==6.0.0 \
  smbus2==0.5.0

echo "[10/17] Download person/vehicle model..."
cd "$APP_DIR/models"
wget -q -O MobileNetSSD_deploy.prototxt \
  https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/master/deploy.prototxt
wget -q -O MobileNetSSD_deploy.caffemodel \
  https://github.com/chuanqi305/MobileNet-SSD/raw/master/mobilenet_iter_73000.caffemodel

# Garbage YOLO model removed. No garbage_yolo.onnx required.

echo "[11/17] Create warning audio..."
espeak-ng -s 145 -a 55 -w "$APP_DIR/assets/warning_src.wav" \
  "Warning. Person detected. Please leave the monitored area."
ffmpeg -y -i "$APP_DIR/assets/warning_src.wav" \
  -af "highpass=f=180,lowpass=f=3200,volume=0.28" \
  -ac 1 -ar 16000 -c:a pcm_s16le "$APP_DIR/assets/warning.wav" >/dev/null 2>&1
rm -f "$APP_DIR/assets/warning_src.wav"

echo "[12/17] Write config..."
cat > "$APP_DIR/data/config.json" <<JSON
{
  "rtsp_url": "$RTSP_URL",
  "cloudflare_live_rtsp_url": "$CLOUDFLARE_LIVE_RTSP_URL",
  "pi_ip": "$PI_IP",
  "router_ip": "$ROUTER_IP",
  "camera_ip": "$CAMERA_IP",
  "camera_name": "$CAMERA_NAME",
  "device_id": "$DEVICE_ID",
  "camera_config_url": "$CAMERA_CONFIG_URL",
  "permanent_camera_config_url": "$PERMANENT_CAMERA_CONFIG_URL",
  "subdomain_name": "$SUBDOMAIN_NAME",
  "base_domain": "$BASE_DOMAIN",
  "permanent_live_base_url": "$PERMANENT_LIVE_BASE_URL",
  "tailscale_mail_id": "$TAILSCALE_MAIL_ID",
  "software_version": "Version 6.19",
  "software_features": "Tiruppur Requirement Only + Live Backup Interface",
  "router_reboot_schedule": {
    "time_1": "$ROUTER_REBOOT_TIME_1",
    "time_2": "$ROUTER_REBOOT_TIME_2"
  },
  "garbage_interval_sec": 3600,
  "garbage_detection_mode": "ai",

  "person_static_stay_sec": 5.0,
  "vehicle_detection_mode": "static",
  "vehicle_static_stay_sec": 5.0,
  "vehicle_geofence_overlap_threshold": 0.35,
  "vehicle_roi": [0.00, 0.08, 1.00, 1.00],
  "vehicle_polygon": [
    [0.00, 0.08],
    [1.00, 0.08],
    [1.00, 1.00],
    [0.00, 1.00]
  ],

  "feature_flags": {
    "person_detection_enabled": true,
    "vehicle_detection_enabled": true,
    "garbage_detection_enabled": false,
    "person_video_recording_enabled": true,
    "vehicle_video_recording_enabled": true
  },
  "mqtt": {
    "host": "$MQTT_HOST",
    "port": $MQTT_PORT,
    "username": "$MQTT_USERNAME",
    "password": "$MQTT_PASSWORD",
    "garbage_topic": "",
    "camera_event_topic": "$MQTT_CAMERA_EVENT_TOPIC",
    "command_topic": "$MQTT_COMMAND_TOPIC",
    "response_topic": "$MQTT_RESPONSE_TOPIC",
    "command_token": "$MQTT_COMMAND_TOKEN"
  },
  "sftp": {
    "host": "$SFTP_HOST",
    "port": $SFTP_PORT,
    "username": "$SFTP_USERNAME",
    "password": "$SFTP_PASSWORD",
    "base_dir": "$SFTP_BASE_DIR",
    "person_dir": "$SFTP_PERSON_DIR",
    "person_video_dir": "$SFTP_PERSON_VIDEO_DIR",
    "vehicle_dir": "$SFTP_VEHICLE_DIR",
    "vehicle_video_dir": "$SFTP_VEHICLE_VIDEO_DIR",
    "garbage_dir": "",
    "audio_dir": "",
    "default_audio_dir": ""
  },
  "battery": {
    "mode": "$BATTERY_MODE",
    "sysfs_path": "$BATTERY_SYSFS_PATH",
    "command": "$BATTERY_COMMAND",
    "divider_ratio": $BATTERY_DIVIDER_RATIO
  },
  "recording": {
    "enabled": true,
    "rtsp_url": "$CLOUDFLARE_LIVE_RTSP_URL",
    "segment_sec": 10,
    "reserve_gb": $RECORDING_RESERVE_GB
  }
}
JSON

echo "[13/17] Write helper scripts..."
sudo tee "$BATTERY_SCRIPT" >/dev/null <<'EOF'
#!/usr/bin/env python3
import json
import sys
import time
from smbus2 import SMBus

I2C_BUS = 1
I2C_ADDR = 0x40

SHUNT_OHMS = 0.01
CURRENT_SIGN = 1
VOLTAGE_CORRECTION = 1.0104
CURRENT_CORRECTION = 0.7627

REG_CONFIG = 0x00
REG_SHUNT_VOLTAGE = 0x01
REG_BUS_VOLTAGE = 0x02

CONFIG_CONTINUOUS_DEFAULT = 0x4527

SAMPLES = 8
SAMPLE_DELAY = 0.02

def read_u16_be(bus: SMBus, reg: int) -> int:
    raw = bus.read_word_data(I2C_ADDR, reg)
    return ((raw & 0xFF) << 8) | (raw >> 8)

def read_s16_be(bus: SMBus, reg: int) -> int:
    value = read_u16_be(bus, reg)
    if value & 0x8000:
        value -= 0x10000
    return value

def main() -> int:
    try:
        with SMBus(I2C_BUS) as bus:
            try:
                high = (CONFIG_CONTINUOUS_DEFAULT >> 8) & 0xFF
                low = CONFIG_CONTINUOUS_DEFAULT & 0xFF
                bus.write_i2c_block_data(I2C_ADDR, REG_CONFIG, [high, low])
                time.sleep(0.1)
            except Exception:
                pass

            bus_voltage_sum = 0.0
            shunt_voltage_sum = 0.0
            bus_voltage_raw_sum = 0

            for _ in range(SAMPLES):
                bus_voltage_raw = read_u16_be(bus, REG_BUS_VOLTAGE)
                shunt_voltage_raw = read_s16_be(bus, REG_SHUNT_VOLTAGE)

                bus_voltage_sum += bus_voltage_raw * 0.00125
                shunt_voltage_sum += shunt_voltage_raw * 0.0000025
                bus_voltage_raw_sum += bus_voltage_raw

                time.sleep(SAMPLE_DELAY)

            bus_voltage_v = (bus_voltage_sum / SAMPLES) * VOLTAGE_CORRECTION
            shunt_voltage_v = shunt_voltage_sum / SAMPLES

            current_a = ((shunt_voltage_v / SHUNT_OHMS) * CURRENT_SIGN) * CURRENT_CORRECTION
            current_ma = current_a * 1000.0

            print(json.dumps({
                "battery_voltage": round(bus_voltage_v, 3),
                "battery_current_a": round(current_a, 3),
                "battery_current_ma": round(current_ma, 1),
                "debug_bus_voltage_raw": round(bus_voltage_raw_sum / SAMPLES),
                "debug_shunt_voltage_uv": round(shunt_voltage_v * 1_000_000, 2)
            }))
            return 0

    except Exception as exc:
        print(json.dumps({
            "battery_voltage": None,
            "battery_current_a": None,
            "battery_current_ma": None,
            "error": str(exc)
        }))
        return 0

if __name__ == "__main__":
    sys.exit(main())
EOF
sudo chmod +x "$BATTERY_SCRIPT"

sudo tee "$REBOOT_HELPER" >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
/usr/bin/systemctl reboot -i
EOF
sudo chmod +x "$REBOOT_HELPER"

echo "$PI_USER ALL=(root) NOPASSWD: $REBOOT_HELPER" | sudo tee "$SUDOERS_FILE" >/dev/null
sudo chmod 440 "$SUDOERS_FILE"
sudo visudo -cf "$SUDOERS_FILE" >/dev/null

cat > /tmp/gcam-controller-sudoers <<EOF
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl start gcam.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl stop gcam.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl restart gcam.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl is-active gcam.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl restart cloudflared.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl is-active cloudflared.service
$PI_USER ALL=(root) NOPASSWD: /usr/bin/systemctl start gcam-cloudflare-watchdog.service
EOF
sudo cp /tmp/gcam-controller-sudoers "$GCAM_CONTROLLER_SUDOERS_FILE"
sudo chmod 440 "$GCAM_CONTROLLER_SUDOERS_FILE"
sudo visudo -cf "$GCAM_CONTROLLER_SUDOERS_FILE" >/dev/null
rm -f /tmp/gcam-controller-sudoers

echo "[14/17] Write templates..."
cat > "$APP_DIR/templates/live.html" <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>G-Cam Live</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    html, body { margin:0; padding:0; background:#000; height:100%; }
    .wrap { display:flex; align-items:center; justify-content:center; height:100%; }
    img { width:100%; height:auto; max-height:100vh; object-fit:contain; display:block; }
  </style>
</head>
<body>
  <div class="wrap">
    <img src="{{ stream_endpoint }}" alt="Live Feed">
  </div>
</body>
</html>
HTML

cat > "$APP_DIR/templates/playback.html" <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>G-Cam Playback</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root{--bg:#08111f;--card:#101a2e;--line:#263657;--text:#eef4ff;--muted:#a7b9da;--accent:#39c6ff;--ok:#22c55e;--bad:#ef4444;--warn:#f59e0b}
    *{box-sizing:border-box}
    body{margin:0;background:linear-gradient(180deg,#07101b,#0f172a 45%,#0b1320);color:var(--text);font-family:Arial,Helvetica,sans-serif;min-height:100vh}
    .wrap{width:min(1180px,94%);margin:0 auto;padding:24px 0 40px}
    .card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px;margin-bottom:16px}
    h1{margin:0 0 8px;font-size:30px} h2{margin:0 0 12px;font-size:18px}
    .muted{color:var(--muted);font-size:13px;line-height:1.5}
    form{display:grid;grid-template-columns:repeat(4,minmax(0,1fr)) auto;gap:10px;align-items:end}
    label{display:block;color:var(--muted);font-size:12px;margin-bottom:6px}
    input,button{width:100%;border-radius:10px;border:1px solid var(--line);padding:11px 12px;font-size:14px}
    input{background:#16233f;color:var(--text)}
    button{background:var(--accent);color:#001421;font-weight:800;cursor:pointer;min-width:140px}
    video{display:block;width:100%;max-height:70vh;background:#000;border:1px solid var(--line);border-radius:12px}
    .ok{color:#8bffb2}.bad{color:#ff9b9b}.warn{color:#ffd07f}.mono{font-family:Consolas,monospace;word-break:break-all}
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
    .stat{background:#16233f;border:1px solid var(--line);border-radius:12px;padding:12px}
    .stat b{display:block;font-size:20px;margin-top:5px}
    .dates{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.date-pill{padding:6px 9px;border-radius:999px;background:#16233f;border:1px solid var(--line);font-size:12px}
    .range-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}
    .range-box{background:#16233f;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
    .range-box span{display:block;color:var(--muted);font-size:11px;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px}
    #playbackStatus{margin-top:10px;min-height:20px}
    @media(max-width:980px){form{grid-template-columns:1fr 1fr}.submit-cell{grid-column:1/-1}.submit-cell button{max-width:220px}}
    @media(max-width:620px){form{grid-template-columns:1fr}.submit-cell{grid-column:auto}.submit-cell button{max-width:none}.grid,.range-row{grid-template-columns:1fr}}
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>G-Cam Storage-Based Playback</h1>
    <div class="muted">Select a start date/time and end date/time. Playback starts at the exact requested start position, continues through saved recording segments, and stops at the selected end time. MQTT start-only playback links automatically use the latest completed recording as the end.</div>
  </div>

  <div class="card">
    <form method="get" action="/playback">
      <div>
        <label for="start_date">Start Date</label>
        <input id="start_date" name="start_date" type="date" value="{{ selected_start_date }}" required>
      </div>
      <div>
        <label for="start_time">Start Time</label>
        <input id="start_time" name="start_time" type="time" step="1" value="{{ selected_start_time }}" required>
      </div>
      <div>
        <label for="end_date">End Date</label>
        <input id="end_date" name="end_date" type="date" value="{{ selected_end_date }}" required>
      </div>
      <div>
        <label for="end_time">End Time</label>
        <input id="end_time" name="end_time" type="time" step="1" value="{{ selected_end_time }}" required>
      </div>
      <div class="submit-cell"><button type="submit">▶ Find Playback</button></div>
    </form>
  </div>

  {% if requested_start or requested_end or playback_error %}
    <div class="card">
      {% if playback %}
        <h2 class="ok">Backup available</h2>
        <video id="playbackVideo" controls autoplay preload="metadata" src="{{ playback.url }}"></video>

        <div class="range-row">
          <div class="range-box">
            <span>Requested Start</span>
            <div class="mono">{{ requested_start }}</div>
          </div>
          <div class="range-box">
            <span>Requested End</span>
            <div class="mono">{{ requested_end }}</div>
          </div>
        </div>

        <div class="muted" style="margin-top:10px">
          Current segment: <span id="currentSegment" class="mono">{{ playback.segment_start }}</span><br>
          Starting offset: <span class="mono">{{ '%.1f'|format(playback.offset_sec) }} sec</span>
        </div>
        <div id="playbackStatus" class="muted">Playing requested range...</div>
      {% else %}
        <h2 class="bad">Backup not available for the entered date/time range</h2>
        <div class="muted">{{ playback_error or 'No completed recording segment covers the requested start timestamp.' }}</div>
      {% endif %}
    </div>
  {% endif %}

  <div class="card">
    <h2>Recording storage</h2>
    <div class="grid">
      <div class="stat"><span class="muted">Recording data</span><b>{{ storage.recordings_used_gb }} GB <small style="font-size:12px;color:var(--muted)">({{ storage.recordings_used_mb }} MB)</small></b></div>
      <div class="stat"><span class="muted">Playback capacity</span><b>{{ storage.recording_capacity_gb }} GB</b></div>
      <div class="stat"><span class="muted">Available before overwrite</span><b>{{ storage.available_recording_gb }} GB</b></div>
      <div class="stat"><span class="muted">Estimated total playback</span><b>{{ storage.estimated_capacity_hours if storage.estimated_capacity_hours is not none else 'Calculating...' }}{% if storage.estimated_capacity_hours is not none %} h{% endif %}</b></div>
      <div class="stat"><span class="muted">Estimated hours before overwrite</span><b>{{ storage.estimated_remaining_hours if storage.estimated_remaining_hours is not none else 'Calculating...' }}{% if storage.estimated_remaining_hours is not none %} h{% endif %}</b></div>
      <div class="stat"><span class="muted">Recorder</span><b>{{ storage.recorder_status }}</b></div>
    </div>
    <div class="muted" style="margin-top:12px">
      SD total: {{ storage.sd_total_gb }} GB · SD free: {{ storage.sd_free_gb }} GB · Protected free-space reserve: {{ storage.reserve_gb }} GB
      <br>Segment length: {{ storage.segment_sec }} sec · Files: {{ storage.recording_file_count }} · Playable timestamp files: {{ storage.playable_file_count }}
      <br>Recording source: Shared SUB live feed · {{ storage.recording_output_width }}px · {{ storage.recording_output_fps }} FPS
      {% if storage.active_segment_name %}<br>Latest segment: <span class="mono">{{ storage.active_segment_name }}</span> · {{ storage.active_segment_mb }} MB{% endif %}
      {% if storage.recorder_last_error %}<br><span class="bad">Recorder detail: {{ storage.recorder_last_error }}</span>{% endif %}
      {% if storage.estimated_hourly_recording_gb is not none %}<br>Measured recording rate: {{ storage.estimated_hourly_recording_gb }} GB/hour{% endif %}
      {% if storage.current_playback_span_hours is not none %}<br>Current playback span: {{ storage.current_playback_span_hours }} hours{% endif %}
      {% if storage.oldest_recording %}<br>Oldest: {{ storage.oldest_recording }}{% endif %}
      {% if storage.newest_recording %}<br>Newest: {{ storage.newest_recording }}{% endif %}
      <br><span class="warn">Playback uses completed segments. With {{ storage.segment_sec }}-second segments, a new recording normally becomes searchable within about {{ storage.segment_sec + 5 }} seconds.</span>
    </div>
    {% if available_dates %}
      <div class="dates">
        {% for d in available_dates %}<span class="date-pill">{{ d }}</span>{% endfor %}
      </div>
    {% endif %}
  </div>
</div>

{% if playback %}
<script>
(() => {
  const video = document.getElementById('playbackVideo');
  const statusEl = document.getElementById('playbackStatus');
  const segmentEl = document.getElementById('currentSegment');

  let currentFile = {{ playback.relative_path | tojson }};
  let initialOffset = Number({{ playback.offset_sec | tojson }} || 0);
  let stopOffset = {{ playback.stop_offset_sec | tojson }};
  let isFinalSegment = {{ playback.is_final_segment | tojson }};
  const requestedEnd = {{ requested_end | tojson }};

  let initialSeekDone = false;
  let rangeFinished = false;
  let loadingNext = false;

  function setStatus(text, className = 'muted') {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.className = className;
  }

  function finishRange() {
    if (rangeFinished) return;
    rangeFinished = true;
    try {
      if (stopOffset !== null && stopOffset !== undefined && Number.isFinite(Number(stopOffset))) {
        const exactStop = Math.max(0, Number(stopOffset));
        if (Math.abs(video.currentTime - exactStop) > 0.08) {
          video.currentTime = exactStop;
        }
      }
    } catch (_) {}
    video.pause();
    setStatus('Playback range completed at ' + requestedEnd + '.', 'ok');
  }

  async function loadNextSegment() {
    if (loadingNext || rangeFinished || isFinalSegment) {
      if (isFinalSegment && !rangeFinished) finishRange();
      return;
    }

    loadingNext = true;
    setStatus('Loading next recording segment...', 'muted');

    try {
      const params = new URLSearchParams({
        file: currentFile,
        end: requestedEnd
      });
      const r = await fetch('/api/playback/next?' + params.toString(), {cache:'no-store'});
      const data = await r.json().catch(() => ({}));

      if (!r.ok || !data.ok || !data.playback) {
        const message = data.error || 'No continuous recording is available for the remaining requested range.';
        video.pause();
        setStatus('Playback stopped: ' + message, 'bad');
        return;
      }

      const next = data.playback;
      currentFile = next.relative_path;
      initialOffset = Number(next.offset_sec || 0);
      stopOffset = next.stop_offset_sec;
      isFinalSegment = !!next.is_final_segment;
      initialSeekDone = false;

      if (segmentEl) segmentEl.textContent = next.segment_start;

      video.src = next.url;
      video.load();
      await video.play().catch(() => {});
      setStatus('Playing requested range...', 'muted');
    } catch (_) {
      video.pause();
      setStatus('Playback stopped: network error while loading the next segment.', 'bad');
    } finally {
      loadingNext = false;
    }
  }

  video.addEventListener('loadedmetadata', () => {
    if (initialSeekDone) return;

    const duration = Number(video.duration || 0);
    const requestedOffset = Math.max(0, Number(initialOffset || 0));
    const safeOffset = duration > 0
      ? Math.min(requestedOffset, Math.max(duration - 0.05, 0))
      : requestedOffset;

    try { video.currentTime = safeOffset; } catch (_) {}
    initialSeekDone = true;
  });

  function checkExactRangeEnd() {
    if (rangeFinished || !isFinalSegment || stopOffset === null || stopOffset === undefined) return;

    const endOffset = Number(stopOffset);
    if (!Number.isFinite(endOffset)) return;

    if (video.currentTime >= Math.max(0, endOffset - 0.03)) {
      finishRange();
    }
  }

  video.addEventListener('timeupdate', checkExactRangeEnd);

  function exactStopWatcher() {
    if (rangeFinished) return;
    checkExactRangeEnd();
    window.requestAnimationFrame(exactStopWatcher);
  }
  window.requestAnimationFrame(exactStopWatcher);

  video.addEventListener('ended', async () => {
    if (rangeFinished) return;
    if (isFinalSegment) {
      finishRange();
      return;
    }
    await loadNextSegment();
  });

  video.addEventListener('error', () => {
    if (!rangeFinished) {
      setStatus('Playback error while reading the current recording segment.', 'bad');
    }
  });
})();
</script>
{% endif %}
</body>
</html>
HTML

cat > "$APP_DIR/templates/playback_live.html" <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>G-Cam MQTT DVR Playback</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <style>
    *{box-sizing:border-box}
    html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden;font-family:Arial,Helvetica,sans-serif}
    #stage{position:fixed;inset:0;background:#000;touch-action:manipulation}
    .playback-video{position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:contain;background:#000;visibility:hidden}
    .playback-video.active{visibility:visible}
    #shade{position:absolute;left:0;right:0;bottom:0;height:150px;pointer-events:none;background:linear-gradient(transparent,rgba(0,0,0,.82))}
    #controls{position:absolute;left:0;right:0;bottom:0;padding:12px 16px 14px;color:#fff;z-index:20}
    #seekRow{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:center;margin-bottom:9px}
    #seekBar{width:100%;accent-color:#fff;cursor:pointer}
    .time{font-size:12px;white-space:nowrap;text-shadow:0 1px 3px #000}
    #buttonRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .ctl{appearance:none;border:1px solid rgba(255,255,255,.35);background:rgba(15,15,15,.78);color:#fff;border-radius:7px;min-height:38px;padding:7px 11px;font-size:14px;font-weight:700;cursor:pointer}
    .ctl:hover{background:rgba(55,55,55,.88)}
    .ctl.active{background:#fff;color:#000;border-color:#fff}
    #playPause{min-width:54px;font-size:18px}
    #speedSelect{min-width:76px}
    #status{margin-left:auto;font-size:12px;color:#ddd;max-width:42vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-shadow:0 1px 3px #000}
    #playbackError{position:fixed;inset:0;display:none;align-items:center;justify-content:center;padding:24px;background:#000;color:#fff;font:16px Arial,sans-serif;text-align:center}
    @media(max-width:700px){
      #controls{padding:9px 9px 11px}
      #seekRow{gap:6px}
      .ctl{padding:6px 8px;min-height:36px}
      #status{order:10;width:100%;max-width:none;margin-left:0}
      .time{font-size:11px}
    }
  </style>
</head>
<body>
{% if playback %}
<div id="stage">
  <video id="playbackA" class="playback-video active" autoplay muted playsinline preload="auto" src="{{ playback.url }}"></video>
  <video id="playbackB" class="playback-video" muted playsinline preload="auto"></video>
  <div id="shade"></div>
  <div id="controls">
    <div id="seekRow">
      <span id="elapsed" class="time">0:00</span>
      <input id="seekBar" type="range" min="0" max="10" step="0.01" value="0" aria-label="Playback position">
      <span id="duration" class="time">0:00</span>
    </div>
    <div id="buttonRow">
      <button id="reverseBtn" class="ctl" type="button" title="Reverse playback">⏪ Reverse</button>
      <button id="playPause" class="ctl" type="button" title="Play or pause">⏸</button>
      <button id="forwardBtn" class="ctl active" type="button" title="Forward playback">Forward ⏩</button>
      <select id="speedSelect" class="ctl" title="Playback speed" aria-label="Playback speed">
        <option value="0.5">0.5×</option>
        <option value="1" selected>1×</option>
        <option value="2">2×</option>
        <option value="4">4×</option>
        <option value="8">8×</option>
      </select>
      <button id="fullscreenBtn" class="ctl" type="button" title="Fullscreen">⛶</button>
      <span id="status">Forward · 1×</span>
    </div>
  </div>
</div>
<script>
(() => {
  const stage = document.getElementById('stage');
  let activeVideo = document.getElementById('playbackA');
  let standbyVideo = document.getElementById('playbackB');

  const seekBar = document.getElementById('seekBar');
  const elapsedEl = document.getElementById('elapsed');
  const durationEl = document.getElementById('duration');
  const statusEl = document.getElementById('status');
  const playPauseBtn = document.getElementById('playPause');
  const reverseBtn = document.getElementById('reverseBtn');
  const forwardBtn = document.getElementById('forwardBtn');
  const speedSelect = document.getElementById('speedSelect');
  const fullscreenBtn = document.getElementById('fullscreenBtn');

  let currentFile = {{ playback.relative_path | tojson }};
  let currentSegmentStart = {{ playback.segment_start | tojson }};
  let initialOffset = Number({{ playback.offset_sec | tojson }} || 0);
  let initialSeekPending = true;

  let direction = 'forward';
  let speed = 1;
  let userPaused = false;
  let switching = false;
  let preparedNext = null;
  let preparedNextReady = false;
  let preparingNext = false;
  let livePollTimer = null;
  let reverseTimer = null;
  let reverseSwitchPending = false;
  let standbyGeneration = 0;

  const POLL_MS = 750;
  const REVERSE_TICK_MS = 100;

  function formatTime(seconds) {
    const value = Math.max(0, Number(seconds || 0));
    const whole = Math.floor(value);
    const hours = Math.floor(whole / 3600);
    const mins = Math.floor((whole % 3600) / 60);
    const secs = whole % 60;
    if (hours > 0) return `${hours}:${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    return `${mins}:${String(secs).padStart(2,'0')}`;
  }

  function setStatus(text) {
    if (statusEl) statusEl.textContent = text;
  }

  function playbackLabel() {
    if (userPaused) return 'Paused';
    return `${direction === 'reverse' ? 'Reverse' : 'Forward'} · ${speed}×`;
  }

  function updateButtons() {
    reverseBtn.classList.toggle('active', direction === 'reverse');
    forwardBtn.classList.toggle('active', direction === 'forward');
    playPauseBtn.textContent = userPaused ? '▶' : '⏸';
    if (!switching && !reverseSwitchPending) setStatus(playbackLabel());
  }

  function updateTimeline() {
    const duration = Number(activeVideo.duration || 0);
    const current = Number(activeVideo.currentTime || 0);
    if (duration > 0 && Number.isFinite(duration)) {
      seekBar.max = String(duration);
      seekBar.value = String(Math.min(current, duration));
      durationEl.textContent = formatTime(duration);
    }
    elapsedEl.textContent = formatTime(current);
  }

  function clearLivePoll() {
    if (livePollTimer !== null) {
      window.clearTimeout(livePollTimer);
      livePollTimer = null;
    }
  }

  function stopReverseTimer() {
    if (reverseTimer !== null) {
      window.clearInterval(reverseTimer);
      reverseTimer = null;
    }
  }

  function resetStandby() {
    standbyGeneration += 1;
    preparedNext = null;
    preparedNextReady = false;
    try { standbyVideo.pause(); } catch (_) {}
    standbyVideo.removeAttribute('src');
    try { standbyVideo.load(); } catch (_) {}
  }

  function waitForMediaReady(video, generation, maxWaitMs = 2200) {
    return new Promise(resolve => {
      if (video.readyState >= 1) {
        resolve(generation === standbyGeneration);
        return;
      }
      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        window.clearTimeout(timer);
        video.removeEventListener('loadedmetadata', done);
        video.removeEventListener('canplay', done);
        video.removeEventListener('error', done);
        resolve(generation === standbyGeneration && video.readyState >= 1);
      };
      const timer = window.setTimeout(done, maxWaitMs);
      video.addEventListener('loadedmetadata', done, {once:true});
      video.addEventListener('canplay', done, {once:true});
      video.addEventListener('error', done, {once:true});
    });
  }

  async function loadStandby(playback, positionMode) {
    const generation = ++standbyGeneration;
    try { standbyVideo.pause(); } catch (_) {}
    standbyVideo.src = playback.url;
    standbyVideo.load();

    const ready = await waitForMediaReady(standbyVideo, generation);
    if (!ready || generation !== standbyGeneration) return false;

    const duration = Number(standbyVideo.duration || 0);
    let target = 0;
    if (positionMode === 'end') {
      target = duration > 0 ? Math.max(0, duration - 0.08) : 0;
    } else {
      target = Math.max(0, Number(playback.offset_sec || 0));
      if (duration > 0) target = Math.min(target, Math.max(0, duration - 0.05));
    }
    try { standbyVideo.currentTime = target; } catch (_) {}
    standbyVideo.playbackRate = Math.max(0.5, Math.min(8, speed));
    return true;
  }

  function swapVideos(playback) {
    const oldVideo = activeVideo;
    activeVideo = standbyVideo;
    standbyVideo = oldVideo;

    activeVideo.classList.add('active');
    standbyVideo.classList.remove('active');

    currentFile = playback.relative_path;
    currentSegmentStart = playback.segment_start || currentSegmentStart;

    try { standbyVideo.pause(); } catch (_) {}
    standbyVideo.removeAttribute('src');
    try { standbyVideo.load(); } catch (_) {}

    preparedNext = null;
    preparedNextReady = false;
    updateTimeline();
  }

  async function fetchNextPlayback() {
    const params = new URLSearchParams({file: currentFile});
    const response = await fetch('/api/playback/next_live?' + params.toString(), {cache:'no-store'});
    if (!response.ok) return null;
    const data = await response.json().catch(() => ({}));
    return data.ok && data.playback ? data.playback : null;
  }

  async function fetchPreviousPlayback() {
    const params = new URLSearchParams({file: currentFile});
    const response = await fetch('/api/playback/previous_live?' + params.toString(), {cache:'no-store'});
    if (!response.ok) return null;
    const data = await response.json().catch(() => ({}));
    return data.ok && data.playback ? data.playback : null;
  }

  async function prepareNextPlayback() {
    if (direction !== 'forward' || preparingNext || preparedNext) return preparedNext;
    preparingNext = true;
    try {
      const next = await fetchNextPlayback();
      if (!next || direction !== 'forward') return null;
      preparedNext = next;
      preparedNextReady = await loadStandby(next, 'offset');
      if (!preparedNextReady) preparedNext = null;
      return preparedNext;
    } catch (_) {
      preparedNext = null;
      preparedNextReady = false;
      return null;
    } finally {
      preparingNext = false;
    }
  }

  function scheduleLivePoll() {
    clearLivePoll();
    if (direction !== 'forward' || userPaused) return;
    setStatus(`Waiting for next recording · ${speed}×`);
    livePollTimer = window.setTimeout(async () => {
      if (direction !== 'forward' || userPaused) return;
      const next = await prepareNextPlayback();
      if (next && activeVideo.ended) {
        await switchToNext();
      } else if (!next) {
        scheduleLivePoll();
      }
    }, POLL_MS);
  }

  async function switchToNext() {
    if (switching || direction !== 'forward') return;
    switching = true;
    clearLivePoll();
    setStatus('Loading next recording…');
    try {
      if (!preparedNext || !preparedNextReady) {
        const next = await prepareNextPlayback();
        if (!next || !preparedNextReady) {
          scheduleLivePoll();
          return;
        }
      }

      const next = preparedNext;
      if (!next) {
        scheduleLivePoll();
        return;
      }

      standbyVideo.playbackRate = speed;
      if (!userPaused) await standbyVideo.play().catch(() => {});
      else standbyVideo.pause();

      swapVideos(next);
      updateButtons();
      if (!userPaused) prepareNextPlayback();
    } finally {
      switching = false;
    }
  }

  async function switchToPrevious() {
    if (switching || reverseSwitchPending || direction !== 'reverse') return;
    reverseSwitchPending = true;
    switching = true;
    clearLivePoll();
    setStatus('Loading previous recording…');
    resetStandby();
    try {
      const previous = await fetchPreviousPlayback();
      if (!previous) {
        userPaused = true;
        stopReverseTimer();
        setStatus('Oldest available recording reached');
        updateButtons();
        return;
      }

      const ready = await loadStandby(previous, 'end');
      if (!ready || direction !== 'reverse') return;
      standbyVideo.pause();
      swapVideos(previous);
      updateButtons();
    } catch (_) {
      userPaused = true;
      stopReverseTimer();
      setStatus('Reverse playback stopped: previous recording unavailable');
      updateButtons();
    } finally {
      switching = false;
      reverseSwitchPending = false;
    }
  }

  function startReverseTimer() {
    stopReverseTimer();
    if (direction !== 'reverse' || userPaused) return;
    try { activeVideo.pause(); } catch (_) {}
    reverseTimer = window.setInterval(async () => {
      if (direction !== 'reverse' || userPaused || switching || reverseSwitchPending) return;
      const step = speed * (REVERSE_TICK_MS / 1000);
      const current = Number(activeVideo.currentTime || 0);
      if (current > step + 0.03) {
        try { activeVideo.currentTime = Math.max(0, current - step); } catch (_) {}
        updateTimeline();
      } else {
        await switchToPrevious();
      }
    }, REVERSE_TICK_MS);
  }

  function pausePlayback() {
    userPaused = true;
    clearLivePoll();
    stopReverseTimer();
    try { activeVideo.pause(); } catch (_) {}
    updateButtons();
  }

  function resumePlayback() {
    userPaused = false;
    if (direction === 'reverse') {
      try { activeVideo.pause(); } catch (_) {}
      startReverseTimer();
    } else {
      activeVideo.playbackRate = speed;
      if (activeVideo.ended) scheduleLivePoll();
      else activeVideo.play().catch(() => {});
      prepareNextPlayback();
    }
    updateButtons();
  }

  function setDirection(nextDirection) {
    if (nextDirection !== 'forward' && nextDirection !== 'reverse') return;
    if (direction === nextDirection && !userPaused) return;

    direction = nextDirection;
    userPaused = false;
    clearLivePoll();
    stopReverseTimer();

    if (direction === 'reverse') {
      resetStandby();
      try { activeVideo.pause(); } catch (_) {}
      startReverseTimer();
    } else {
      activeVideo.playbackRate = speed;
      activeVideo.play().catch(() => {});
      prepareNextPlayback();
    }
    updateButtons();
  }

  activeVideo.addEventListener('loadedmetadata', () => {
    if (!initialSeekPending) return;
    const duration = Number(activeVideo.duration || 0);
    let target = Math.max(0, initialOffset);
    if (duration > 0) target = Math.min(target, Math.max(0, duration - 0.05));
    try { activeVideo.currentTime = target; } catch (_) {}
    activeVideo.playbackRate = speed;
    initialSeekPending = false;
    updateTimeline();
    activeVideo.play().catch(() => {});
    prepareNextPlayback();
  }, {once:true});

  [document.getElementById('playbackA'), document.getElementById('playbackB')].forEach(video => {
    video.addEventListener('timeupdate', () => {
      if (video === activeVideo) updateTimeline();
    });
    video.addEventListener('durationchange', () => {
      if (video === activeVideo) updateTimeline();
    });
    video.addEventListener('ended', async () => {
      if (video !== activeVideo || direction !== 'forward' || userPaused) return;
      const next = preparedNext || await prepareNextPlayback();
      if (next) await switchToNext();
      else scheduleLivePoll();
    });
    video.addEventListener('error', () => {
      if (video === activeVideo && !switching) setStatus('Playback file error');
    });
  });

  playPauseBtn.addEventListener('click', () => {
    if (userPaused) resumePlayback();
    else pausePlayback();
  });

  reverseBtn.addEventListener('click', () => setDirection('reverse'));
  forwardBtn.addEventListener('click', () => setDirection('forward'));

  speedSelect.addEventListener('change', () => {
    speed = Math.max(0.5, Math.min(8, Number(speedSelect.value || 1)));
    if (direction === 'forward') {
      try { activeVideo.playbackRate = speed; } catch (_) {}
      if (preparedNextReady) {
        try { standbyVideo.playbackRate = speed; } catch (_) {}
      }
    }
    updateButtons();
  });

  seekBar.addEventListener('input', () => {
    const target = Number(seekBar.value || 0);
    if (Number.isFinite(target)) {
      try { activeVideo.currentTime = target; } catch (_) {}
      updateTimeline();
    }
  });


  fullscreenBtn.addEventListener('click', async () => {
    try {
      if (!document.fullscreenElement) await stage.requestFullscreen();
      else await document.exitFullscreen();
    } catch (_) {}
  });

  stage.addEventListener('dblclick', async () => {
    try {
      if (!document.fullscreenElement) await stage.requestFullscreen();
      else await document.exitFullscreen();
    } catch (_) {}
  });

  document.addEventListener('keydown', event => {
    if (event.target && ['INPUT','SELECT'].includes(event.target.tagName)) return;
    if (event.code === 'Space') {
      event.preventDefault();
      if (userPaused) resumePlayback(); else pausePlayback();
    }
  });

  updateButtons();
  updateTimeline();
})();
</script>
{% else %}
<div id="playbackError" style="display:flex">{{ playback_error or 'Playback is not available.' }}</div>
{% endif %}
</body>
</html>
HTML

# live_talk.html removed in Person + Vehicle only build.


cat > "$APP_DIR/templates/index.html" <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>G-Cam "RealTech Systems"</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root{
      --bg:#08111f;--card:#101a2e;--card2:#16233f;--line:#263657;--text:#eef4ff;--muted:#a7b9da;
      --accent:#39c6ff;--high:#ef4444;--med:#f59e0b;--low:#22c55e;--shadow:0 20px 45px rgba(0,0,0,.25);
    }
    *{box-sizing:border-box}
    body{margin:0;font-family:Arial,Helvetica,sans-serif;background:linear-gradient(180deg,#07101b,#0f172a 45%,#0b1320);color:var(--text)}
    .wrap{width:min(1450px,95%);margin:0 auto;padding:20px 0 40px}
    .header{display:flex;justify-content:space-between;gap:20px;align-items:center;background:rgba(16,26,46,.95);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow);padding:20px 24px;margin-bottom:18px}
    .title h1{margin:0;font-size:34px;line-height:1.1}
    .title p{margin:8px 0 0;color:var(--muted);font-size:14px}
    .meta{color:var(--muted);text-align:right;font-size:14px;line-height:1.8}
    .sev-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:18px}
    .sev-card{background:var(--card);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow);padding:18px;min-height:118px}
    .sev-label{color:var(--muted);font-size:14px;margin-bottom:10px;letter-spacing:.4px;text-transform:uppercase}
    .sev-value{font-size:54px;font-weight:700;line-height:1}
    .high .sev-value{color:var(--high)}
    .medium .sev-value{color:var(--med)}
    .low .sev-value{color:var(--low)}
    .tabs{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
    .tab-btn{background:var(--card);color:var(--text);border:1px solid var(--line);border-radius:12px;padding:12px 16px;font-weight:700;cursor:pointer}
    .tab-btn.active{background:var(--accent);color:#001421;border-color:transparent}
    .panel{display:none;background:var(--card);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow);padding:18px}
    .panel.active{display:block}
    .panel-grid{display:grid;grid-template-columns:2fr 1fr;gap:18px;align-items:start}
    .media-card,.info-box{background:var(--card2);border:1px solid var(--line);border-radius:16px}
    .media-card h3{margin:0;padding:14px 16px;border-bottom:1px solid var(--line);font-size:18px}
    .media-body{padding:14px}
    .media-body img{display:block;width:100%;border-radius:12px;border:1px solid var(--line);background:#000}
    .info{display:grid;gap:12px}
    .info-box{padding:14px}
    .info-box h4{margin:0 0 8px;color:var(--muted);font-size:13px;letter-spacing:.6px;text-transform:uppercase}
    .big{font-size:24px;font-weight:700;word-break:break-word}
    .badge{display:inline-block;padding:6px 12px;border-radius:999px;font-size:13px;font-weight:700}
    .badge.high{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.35);color:#ff9191}
    .badge.medium{background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.35);color:#ffd07f}
    .badge.low{background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);color:#8bffb2}
    .badge.none{background:rgba(148,163,184,.15);border:1px solid rgba(148,163,184,.35);color:#d5def0}
    .footer-note{color:var(--muted);margin-top:16px;font-size:13px}
    .link-box{word-break:break-all}
    .mono{font-family:Consolas,monospace}

    .controls-grid{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:14px;
      align-items:stretch;
    }
    .control-card{
      background:var(--card2);
      border:1px solid var(--line);
      border-radius:16px;
      padding:14px;
      min-height:150px;
    }
    .control-card h4{
      margin:0 0 10px;
      color:var(--muted);
      font-size:13px;
      letter-spacing:.6px;
      text-transform:uppercase;
    }
    .control-title{
      font-size:20px;
      font-weight:800;
      margin-bottom:10px;
      line-height:1.2;
    }
    .control-status{
      display:inline-block;
      padding:6px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:800;
      margin-bottom:10px;
      background:rgba(148,163,184,.15);
      border:1px solid rgba(148,163,184,.35);
      color:#d5def0;
    }
    .control-status.on{
      background:rgba(34,197,94,.15);
      border-color:rgba(34,197,94,.35);
      color:#8bffb2;
    }
    .control-status.off{
      background:rgba(239,68,68,.15);
      border-color:rgba(239,68,68,.35);
      color:#ff9b9b;
    }
    .control-actions{
      display:flex;
      flex-wrap:wrap;
      gap:8px;
      margin-top:8px;
    }
    .control-btn{
      border:1px solid var(--line);
      background:var(--card);
      color:var(--text);
      border-radius:10px;
      padding:9px 12px;
      cursor:pointer;
      font-weight:800;
      font-size:13px;
    }
    .control-btn.primary{
      background:var(--accent);
      color:#001421;
      border-color:transparent;
    }
    .control-btn.danger{
      background:rgba(239,68,68,.18);
      border-color:rgba(239,68,68,.4);
      color:#ffb4b4;
    }
    .control-btn.ok{
      background:rgba(34,197,94,.18);
      border-color:rgba(34,197,94,.4);
      color:#a7ffc1;
    }
    .control-btn:disabled{
      opacity:.55;
      cursor:not-allowed;
    }

    .control-input{
      width:100%;
      margin-top:4px;
      padding:9px 11px;
      border:1px solid var(--line);
      border-radius:10px;
      background:var(--card);
      color:var(--text);
      font-size:13px;
      outline:none;
    }

    .control-input:focus{
      border-color:var(--accent);
    }

    .control-input::placeholder{
      color:var(--muted);
    }

    .control-wide{
      grid-column:span 2;
    }
    .volume-row{
      display:flex;
      gap:10px;
      align-items:center;
      flex-wrap:wrap;
      margin-top:10px;
    }
    .volume-row input[type="range"]{
      width:min(360px,100%);
    }
    .control-status-line{
      margin-top:14px;
      padding:12px;
      border-radius:12px;
      background:var(--card2);
      border:1px solid var(--line);
      color:var(--muted);
      min-height:44px;
      font-size:13px;
    }

    body.geofence-page-only{
      background:#08111f;
      overflow-x:hidden;
    }

    body.geofence-page-only .header,
    body.geofence-page-only .sev-grid,
    body.geofence-page-only .tabs,
    body.geofence-page-only .footer-note{
      display:none !important;
    }

    body.geofence-page-only .wrap{
      width:min(980px,100%);
      margin:0 auto;
      padding:6px;
    }

    body.geofence-page-only .panel{
      display:none;
      padding:12px;
      border-radius:10px;
      box-shadow:none;
      margin:0;
    }

    body.geofence-page-only #tab-geofence.panel.active,
    body.geofence-page-only #tab-person_geofence.panel.active,
    body.geofence-page-only #tab-vehicle_geofence.panel.active{
      display:block;
    }

    body.geofence-page-only #tab-geofence > div:first-child,
    body.geofence-page-only #tab-person_geofence > div:first-child,
    body.geofence-page-only #tab-vehicle_geofence > div:first-child{
      margin-bottom:10px !important;
      font-size:13px;
      line-height:1.4;
    }

    body.geofence-page-only canvas{
      max-width:100%;
      height:auto;
    }

    body.geofence-page-only .info-box{
      box-shadow:none;
    }

    @media (max-width:980px){
      .header{flex-direction:column;align-items:flex-start}
      .meta{text-align:left}
      .panel-grid{grid-template-columns:1fr}
      .sev-grid{grid-template-columns:1fr}
      .controls-grid{grid-template-columns:1fr}
      .control-wide{grid-column:span 1}

      body.geofence-page-only .wrap{
        width:100%;
        padding:4px;
      }
    }
  </style>
</head>
<body class="{{ 'geofence-page-only' if geofence_page_only else '' }}">
<div class="wrap">
  <div class="header">
    <div class="title">
      <h1>G-Cam "RealTech Systems"</h1>
      <p>Live stream, person detect, garbage detect, MQTT audio and device status</p>
    </div>
    <div class="meta">
      <div><strong>Device ID:</strong> {{ state.device_id }}</div>
      <div><strong>Camera:</strong> {{ state.camera_ip }}</div>
      <div><strong>Raspberry Pi:</strong> {{ state.raspberry_ip }}</div>
      <div><strong>Public IP:</strong> {{ state.public_ip or "Unavailable" }}</div>
      <div><strong>Last Frame:</strong> {{ state.system.last_frame_at or "Waiting..." }}</div>
    </div>
  </div>

  <div class="sev-grid">
    <div class="sev-card high"><div class="sev-label">HIGH</div><div class="sev-value" id="highCount">{{ state.counts.HIGH }}</div></div>
    <div class="sev-card medium"><div class="sev-label">MEDIUM</div><div class="sev-value" id="mediumCount">{{ state.counts.MEDIUM }}</div></div>
    <div class="sev-card low"><div class="sev-label">LOW</div><div class="sev-value" id="lowCount">{{ state.counts.LOW }}</div></div>
  </div>

  <div class="tabs">
    <button class="tab-btn active" onclick="showTab('live', this)">Live Feed</button>
    <button class="tab-btn" onclick="showTab('garbage', this)">Last Garbage Detection</button>
    <button class="tab-btn" onclick="showTab('person', this)">Last Person Detection</button>
	<button class="tab-btn" onclick="showTab('vehicle', this)">Last Vehicle Detection</button>
	<button class="tab-btn" onclick="showTab('geofence', this)">Garbage Geofence</button>
	<button class="tab-btn" onclick="showTab('person_geofence', this)">Person Geofence</button>
	<button class="tab-btn" onclick="showTab('vehicle_geofence', this)">Vehicle Geofence</button>
    <button class="tab-btn" onclick="showTab('controls', this)">Controls</button>
    <button class="tab-btn" onclick="showTab('links', this)">Links & Status</button>
    <button class="tab-btn" onclick="showTab('device', this)">Device Health</button>
  </div>

  <div id="tab-live" class="panel active">
    <div class="panel-grid">
      <div class="media-card">
        <h3>Live RTSP Feed</h3>
        <div class="media-body">
          {% if dashboard_public_request %}
            <div id="liveFeedHint" style="color:var(--muted);font-size:13px;line-height:1.5;margin-bottom:10px">
              Public dashboard is using low-bandwidth snapshot mode to avoid Cloudflare buffering.
              Use Start Live only when you need continuous video.
            </div>
            <img
              id="liveFeedImg"
              src="{{ dashboard_snapshot_endpoint }}?t={{ ts }}"
              data-mode="snapshot"
              data-snapshot-src="{{ dashboard_snapshot_endpoint }}"
              data-stream-src="{{ dashboard_stream_endpoint }}"
              alt="Live Feed">
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
              <button class="control-btn primary" onclick="dashboardStartLive()">▶ Start Live</button>
              <button class="control-btn" onclick="dashboardUseSnapshot()">📷 Snapshot Mode</button>
            </div>
          {% else %}
            <img
              id="liveFeedImg"
              src="{{ dashboard_stream_endpoint }}"
              data-mode="stream"
              data-snapshot-src="{{ dashboard_snapshot_endpoint }}"
              data-stream-src="{{ dashboard_stream_endpoint }}"
              alt="Live Feed">
          {% endif %}
        </div>
      </div>
      <div class="info">
        <div class="info-box"><h4>Camera Status</h4><div class="big" id="cameraStatus">{{ "Connected" if state.system.camera_connected else "Disconnected" }}</div></div>
        <div class="info-box"><h4>Last Error</h4><div id="lastError">{{ state.system.last_error or "None" }}</div></div>
        <div class="info-box"><h4>Garbage Mode</h4><div id="garbageMode">{{ state.system.garbage_mode }}</div></div>
        <div class="info-box"><h4>Latest Garbage Severity</h4><div id="garbageSeverity">{% set sev = state.last_garbage.severity %}{% if sev == "HIGH" %}<span class="badge high">HIGH</span>{% elif sev == "MEDIUM" %}<span class="badge medium">MEDIUM</span>{% elif sev == "LOW" %}<span class="badge low">LOW</span>{% else %}<span class="badge none">NONE</span>{% endif %}</div></div>
        <div class="info-box"><h4>Permanent Live Link</h4><div class="link-box" id="permanentLiveUrl">{{ state.live_link.url or "Inactive" }}</div></div>
        <div class="info-box"><h4>Live Link Status</h4><div id="permanentLiveStatus">{{ state.live_link.expires_at or "Inactive" }}</div></div>
        <div class="info-box"><h4>Camera Config Permanent Link</h4><div class="link-box" id="cameraConfigUrl">{{ state.camera_config_url or "Unavailable" }}</div></div>
      </div>
    </div>
  </div>

  <div id="tab-garbage" class="panel">
    <div class="panel-grid">
      <div class="media-card">
        <h3>Last Garbage Detection Image</h3>
        <div class="media-body">{% if state.last_garbage.image %}<img id="garbageImg" src="/media/{{ state.last_garbage.image }}?t={{ ts }}" alt="Garbage">{% else %}<img id="garbageImg" src="" alt="No Garbage">{% endif %}</div>
      </div>
      <div class="info">
        <div class="info-box"><h4>Time</h4><div id="garbageTime">{{ state.last_garbage.time or "Waiting..." }}</div></div>
        <div class="info-box"><h4>Triggered By</h4><div id="garbageTriggeredBy">{{ state.last_garbage.triggered_by or "N/A" }}</div></div>
        <div class="info-box"><h4>Severity</h4><div class="big" id="garbageSeverityText">{{ state.last_garbage.severity or "NONE" }}</div></div>
        <div class="info-box"><h4>Garbage Count</h4><div class="big" id="garbageCount">{{ state.last_garbage.blob_count or 0 }}</div></div>
        <div class="info-box"><h4>Diff Ratio</h4><div id="garbageDiffRatio">{{ state.last_garbage.diff_ratio }}</div></div>
        <div class="info-box"><h4>Edge Ratio</h4><div id="garbageEdgeRatio">{{ state.last_garbage.edge_ratio }}</div></div>
        <div class="info-box"><h4>Blob Area Ratio</h4><div id="garbageBlobAreaRatio">{{ state.last_garbage.blob_area_ratio }}</div></div>
      </div>
    </div>
  </div>

  <div id="tab-person" class="panel">
    <div class="panel-grid">
      <div class="media-card">
        <h3>Last Person Detection Image</h3>
        {% set person_image = state.last_person.image or state.last_person.image_file %}
        <div class="media-body">{% if person_image %}<img id="personImg" src="/media/{{ person_image }}?t={{ ts }}" alt="Person">{% else %}<img id="personImg" src="" alt="No Person">{% endif %}</div>
      </div>
      <div class="info">
        <div class="info-box"><h4>Time</h4><div id="personTime">{{ state.last_person.time or "Waiting..." }}</div></div>
        <div class="info-box"><h4>Person Count</h4><div class="big" id="personCount">{{ state.last_person.count or 0 }}</div></div>
        <div class="info-box"><h4>Status</h4><div id="personStatus">{% if state.last_person.detected %}Detected now{% elif person_image %}Last detection saved{% else %}No recent detection{% endif %}</div></div>
        <div class="info-box"><h4>Best Confidence</h4><div id="personBestConfidence">{{ state.last_person.best_confidence or 0 }}</div></div>
        <div class="info-box"><h4>Image Upload Status</h4><div id="personImageStatus">{{ state.last_person.image_status or "None" }}</div></div>
        <div class="info-box"><h4>Image Uploaded Path</h4><div class="link-box" id="personImagePath">{{ state.last_person.image_uploaded_path or "None" }}</div></div>
        <div class="info-box">
          <h4>Person Stay Time</h4>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input id="personStaticStayInput"
              type="number"
              min="1"
              max="120"
              step="0.5"
              value="{{ state.system.person_static_stay_sec or 5 }}"
              style="width:110px;background:var(--card);color:var(--text);border:1px solid var(--line);border-radius:8px;padding:8px">
            <span style="color:var(--muted);font-size:13px">seconds</span>
            <button class="control-btn primary" onclick="savePersonStaticStay()">Save</button>
          </div>
          <div id="personStaticStayStatus" style="color:var(--muted);font-size:12px;margin-top:8px">
            Current: {{ state.system.person_static_stay_sec or 5 }} sec
          </div>
          <div style="color:var(--muted);font-size:12px;margin-top:8px;line-height:1.5">
            Event image, video and warning audio trigger only after person remains inside the person geofence for this time.
          </div>
        </div>
      </div>
    </div>
  </div>

     <div id="tab-vehicle" class="panel">
    <div class="panel-grid">
      <div class="media-card">
        <h3>Last Vehicle Detection Image</h3>
        <div class="media-body">
          {% if state.last_vehicle.image %}
            <img id="vehicleImg" src="/media/{{ state.last_vehicle.image }}?t={{ ts }}" alt="Vehicle">
          {% else %}
            <img id="vehicleImg" src="" alt="No Vehicle">
          {% endif %}
        </div>
      </div>
      <div class="info">
        <div class="info-box"><h4>Time</h4><div id="vehicleTime">{{ state.last_vehicle.time or "Waiting..." }}</div></div>
        <div class="info-box"><h4>Vehicle Count</h4><div class="big" id="vehicleCount">{{ state.last_vehicle.count or 0 }}</div></div>
        <div class="info-box"><h4>Status</h4><div id="vehicleStatus">{% if state.last_vehicle.detected and state.last_vehicle.image %}Detected now{% elif state.last_vehicle.detected %}Detected now, preparing image...{% elif (state.last_vehicle.count or 0) > 0 %}Vehicle seen, waiting stable time... {{ '%.1f'|format(state.last_vehicle.stable_inside_sec or 0) }}/{{ state.last_vehicle.stable_required_sec or state.system.vehicle_static_stay_sec or 5 }} sec | hits: {{ state.last_vehicle.stable_hit_count or 0 }} | stable vehicles: {{ state.last_vehicle.stable_vehicle_count or 0 }}{% elif state.last_vehicle.image or state.last_vehicle.image_file %}Last detection saved{% else %}No recent detection{% endif %}</div></div>
        <div class="info-box"><h4>Best Confidence</h4><div id="vehicleBestConfidence">{{ state.last_vehicle.best_confidence or 0 }}</div></div>
        <div class="info-box">
          <h4>Vehicle Detection Mode</h4>
          <div class="big" id="vehicleDetectionMode">{{ state.system.vehicle_detection_mode or state.last_vehicle.mode or "static" }}</div>
          <button id="vehicleModeToggle" onclick="toggleVehicleDetectionMode()"
            style="margin-top:10px;background:var(--accent);color:#001421;border:none;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;font-size:14px">
            🚗 Switch Mode
          </button>

          <div style="color:var(--muted);font-size:12px;margin-top:8px;line-height:1.5">
            Static detects parked/stopped vehicles. Moving detects motion-confirmed vehicles quickly.
          </div>

          <div style="margin-top:12px;border-top:1px solid var(--line);padding-top:12px">
            <h4 style="margin-bottom:8px">Static Stay Time</h4>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
              <input id="vehicleStaticStayInput"
                type="number"
                min="1"
                max="120"
                step="0.5"
                value="{{ state.system.vehicle_static_stay_sec or 5 }}"
                style="width:110px;background:var(--card);color:var(--text);border:1px solid var(--line);border-radius:8px;padding:8px">
              <span style="color:var(--muted);font-size:13px">seconds</span>
              <button class="control-btn primary" onclick="saveVehicleStaticStay()">Save</button>
            </div>
            <div id="vehicleStaticStayStatus" style="color:var(--muted);font-size:12px;margin-top:8px">
              Current: {{ state.system.vehicle_static_stay_sec or 5 }} sec
            </div>
          </div>
        </div>
        <div class="info-box"><h4>Vehicle Labels</h4><div id="vehicleLabels">{{ ", ".join(state.last_vehicle.labels) if state.last_vehicle.labels else "None" }}</div></div>
        <div class="info-box"><h4>Geofence Overlap</h4><div id="vehicleGeofenceOverlap">{{ state.last_vehicle.geofence_overlap or 0 }}</div></div>
        <div class="info-box"><h4>Image Upload Status</h4><div id="vehicleImageStatus">{{ state.last_vehicle.image_status or "None" }}</div></div>
        <div class="info-box"><h4>Image Uploaded Path</h4><div class="link-box" id="vehicleImagePath">{{ state.last_vehicle.image_uploaded_path or "None" }}</div></div>
      </div>
    </div>
  </div>

  <div id="tab-controls" class="panel">
    <div style="margin-bottom:14px">
      <strong>Dashboard Controls</strong> — control detection, recordings,
      person warning audio, vehicle warning audio, garbage actions, audio queue, power saving, device restart
      and Pi volume directly from dashboard.
    </div>

    <div class="controls-grid">
      <div class="control-card">
        <h4>Detection</h4>
        <div class="control-title">👤 Person Detection</div>
        <div id="ctrlPersonDetectionStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetFeature('person_detection_enabled', true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetFeature('person_detection_enabled', false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Detection</h4>
        <div class="control-title">🚗 Vehicle Detection</div>
        <div id="ctrlVehicleDetectionStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button
            class="control-btn ok"
            onclick="controlSetFeature('vehicle_detection_enabled', true)">
            Enable
          </button>

          <button
            class="control-btn danger"
            onclick="controlSetFeature('vehicle_detection_enabled', false)">
            Disable
          </button>
        </div>
      </div>

      <div class="control-card">
        <h4>Detection</h4>
        <div class="control-title">🗑️ Garbage Detection</div>
        <div id="ctrlGarbageDetectionStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button
            class="control-btn ok"
            onclick="controlSetFeature('garbage_detection_enabled', true)">
            Enable
          </button>

          <button
            class="control-btn danger"
            onclick="controlSetFeature('garbage_detection_enabled', false)">
            Disable
          </button>
        </div>
      </div>

      <div class="control-card">
        <h4>Garbage Mode</h4>
        <div class="control-title">🧠 AI / Normal Mode</div>
        <div id="ctrlGarbageModeStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn primary" onclick="controlSetGarbageMode('ai')">AI Mode</button>
          <button class="control-btn" onclick="controlSetGarbageMode('normal')">Normal Mode</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Video Recording</h4>
        <div class="control-title">🎥 Person Video</div>
        <div id="ctrlPersonVideoStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetFeature('person_video_recording_enabled', true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetFeature('person_video_recording_enabled', false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Video Recording</h4>
        <div class="control-title">🎥 Vehicle Video</div>
        <div id="ctrlVehicleVideoStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetFeature('vehicle_video_recording_enabled', true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetFeature('vehicle_video_recording_enabled', false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Warning Audio</h4>
        <div class="control-title">👤 Person Warning Audio</div>
        <div id="ctrlPersonWarningAudioStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetWarningAudio('person', true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetWarningAudio('person', false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Warning Audio</h4>
        <div class="control-title">🚗 Vehicle Warning Audio</div>
        <div id="ctrlVehicleWarningAudioStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetWarningAudio('vehicle', true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetWarningAudio('vehicle', false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Garbage Action</h4>
        <div class="control-title">🧪 Manual Detect</div>
        <div class="control-status">On Demand</div>
        <div class="control-actions">
          <button class="control-btn primary" onclick="controlManualGarbage()">🧪 Run Detection</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Garbage Action</h4>
        <div class="control-title">📷 Reference Image</div>
        <div class="control-status">Capture / Upload</div>
        <div class="control-actions">
          <button class="control-btn primary" onclick="controlGarbageSample()">📷 Capture Sample</button>
          <input id="garbageReferenceUploadInput" type="file" accept="image/*" style="display:none" onchange="controlGarbageReferenceUpload(this)">
          <button class="control-btn" onclick="controlOpenGarbageReferenceUpload()">⬆️ Upload Reference</button>
        </div>
        <div style="color:var(--muted);font-size:12px;margin-top:8px;line-height:1.5">
          Upload JPG, PNG or mobile gallery image. It replaces the current garbage reference image.
        </div>
      </div>

      <div class="control-card">
        <h4>Audio Queue</h4>
        <div class="control-title">🧹 Clear Queue</div>
        <div id="ctrlAudioQueueStatus" class="control-status">Ready</div>
        <div class="control-actions">
          <button class="control-btn danger" onclick="controlClearAudioQueue()">🧹 Clear Audio Queue</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Power</h4>
        <div class="control-title">⚡ Power Saving</div>
        <div id="ctrlPowerSavingStatus" class="control-status">Loading...</div>
        <div class="control-actions">
          <button class="control-btn ok" onclick="controlSetPowerSaving(true)">Enable</button>
          <button class="control-btn danger" onclick="controlSetPowerSaving(false)">Disable</button>
        </div>
      </div>

      <div class="control-card">
        <h4>Device</h4>
        <div class="control-title">🔄 Device Restart</div>

        <div id="ctrlDeviceRestartStatus" class="control-status">
          READY
        </div>

        <input
          id="ctrlDeviceRestartToken"
          class="control-input"
          type="password"
          autocomplete="off"
          placeholder="Enter MQTT command token">

        <div class="control-actions">
          <button
            id="ctrlDeviceRestartButton"
            class="control-btn danger"
            onclick="controlRestartDevice()">
            🔄 Restart Device
          </button>
        </div>

        <div style="color:var(--muted);font-size:12px;margin-top:8px;line-height:1.5">
          Performs a full Raspberry Pi reboot. The dashboard may be unavailable
          for approximately 30–90 seconds.
        </div>
      </div>

      <div class="control-card control-wide">
        <h4>Volume Control</h4>
        <div class="control-title">🔉 Pi Speaker Volume</div>
        <div id="ctrlVolumeStatus" class="control-status">Loading...</div>

        <div class="volume-row">
          <input id="ctrlVolumeRange" type="range" min="0" max="100" value="70" oninput="controlVolumePreview(this.value)">
          <strong id="ctrlVolumePreview">70%</strong>
          <button class="control-btn primary" onclick="controlSetVolumeFromSlider()">Set Volume</button>
          <button class="control-btn" onclick="controlRefreshVolume()">Refresh</button>
        </div>

        <div class="control-actions">
          <button class="control-btn" onclick="controlSetVolume(10)">10%</button>
          <button class="control-btn" onclick="controlSetVolume(25)">25%</button>
          <button class="control-btn" onclick="controlSetVolume(50)">50%</button>
          <button class="control-btn" onclick="controlSetVolume(75)">75%</button>
          <button class="control-btn" onclick="controlSetVolume(100)">100%</button>
        </div>
      </div>
    </div>

    <div id="controlsStatusLine" class="control-status-line">Controls ready.</div>
  </div>

  <div id="tab-links" class="panel">
    <div class="panel-grid">
      <div class="info">
        <div class="info-box"><h4>Local Dashboard URL</h4><div class="link-box" id="dashLocal">{{ local_dashboard }}</div></div>
        <div class="info-box"><h4>Local Stream URL</h4><div class="link-box" id="streamLocal">{{ local_stream }}</div></div>
        <div class="info-box"><h4>Permanent Live URL</h4><div class="link-box" id="permanentLiveUrl2">{{ state.live_link.url or "Inactive" }}</div></div>
        <div class="info-box"><h4>Camera Config Permanent URL</h4><div class="link-box" id="cameraConfigUrl2">{{ state.camera_config_url or "Unavailable" }}</div></div>
        <div class="info-box"><h4>MQTT Command Listener</h4><div id="commandListener">{{ "Connected" if state.system.command_listener else "Disconnected" }}</div></div>
      </div>
      <div class="info">
        <div class="info-box"><h4>SFTP Base Path</h4><div class="link-box" id="sftpBase">{{ sftp_base_dir }}</div></div>
        <div class="info-box"><h4>SFTP Person Path</h4><div class="link-box" id="sftpPerson">{{ sftp_person_dir }}</div></div>
        <div class="info-box"><h4>SFTP Person Video Path</h4><div class="link-box" id="sftpPersonVideo">{{ sftp_person_video_dir }}</div></div>
        <div class="info-box"><h4>SFTP Garbage Path</h4><div class="link-box" id="sftpGarbage">{{ sftp_garbage_dir }}</div></div>
        <div class="info-box"><h4>SFTP Audio Path</h4><div class="link-box" id="sftpAudio">{{ sftp_audio_dir }}</div></div>
        <div class="info-box"><h4>Command Examples</h4><div class="link-box mono">
{"command":"Live Stream","token":"***"}<br>
{"command":"Garbage Sample Capture","token":"***"}<br>
{"command":"Garbage Detect","token":"***"}<br>
{"command":"Garbage Detection Set to 3hours","token":"***"}<br>
{"command":"Audio File Play","audio_name":"Audio20260321.mp3","token":"***"}<br>
{"command":"Warning Audio Disable","token":"***"}<br>
{"command":"Warning Audio Enable","token":"***"}<br>
{"command":"Person Warning Audio Disable","token":"***"}<br>
{"command":"Person Warning Audio Enable","token":"***"}<br>
{"command":"Vehicle Warning Audio Disable","token":"***"}<br>
{"command":"Vehicle Warning Audio Enable","token":"***"}<br>
{"command":"Scheduled Warning Audio","start_time":"10AM","end_time":"6PM","token":"***"}<br>
{"command":"Scheduled Warning Disabled","token":"***"}<br>
{"command":"Data Status","token":"***"}<br>
{"command":"Playback","start_date":"06-08-2026","start_time":"04:31:00 PM","token":"***"}<br>
{"command":"Device Restart","token":"***"}<br>
{"command":"Cloudflare Restart","token":"***"}<br>
{"command":"Cloudflare Status","token":"***"}<br>
{"command":"Close The Software","token":"***"}<br>
{"command":"Open The Software","token":"***"}<br>
{"command":"Current Pi Volume","token":"***"}<br>
{"command":"Camera Live URL","token":"***"}<br>
{"command":"Person Detection Enable","token":"***"}<br>
{"command":"Person Detection Disable","token":"***"}<br>
{"command":"Vehicle Detection Enable","token":"***"}<br>
{"command":"Vehicle Detection Disable","token":"***"}<br>
{"command":"Garbage Detection Enable","token":"***"}<br>
{"command":"Garbage Detection Disable","token":"***"}<br>
{"command":"Garbage AI Mode","token":"***"}<br>
{"command":"Garbage Normal Mode","token":"***"}<br>
{"command":"Person Video Recording Enable","token":"***"}<br>
{"command":"Person Video Recording Disable","token":"***"}<br>
{"command":"Vehicle Video Recording Enable","token":"***"}<br>
{"command":"Vehicle Video Recording Disable","token":"***"}<br>
{"command":"Pi Volume 10%","token":"***"}<br>
{"command":"Pi Volume 20%","token":"***"}<br>
{"command":"Pi Volume 30%","token":"***"}<br>
{"command":"Pi Volume 40%","token":"***"}<br>
{"command":"Pi Volume 50%","token":"***"}<br>
{"command":"Pi Volume 60%","token":"***"}<br>
{"command":"Pi Volume 70%","token":"***"}<br>
{"command":"Pi Volume 80%","token":"***"}<br>
{"command":"Pi Volume 90%","token":"***"}<br>
{"command":"Pi Volume 100%","token":"***"}<br>
{"command":"Pi Volume 75%","token":"***"}
        </div></div>
      </div>
    </div>
  </div>

  <div id="tab-device" class="panel">
    <div class="panel-grid">
      <div class="info">
        <div class="info-box"><h4>Pi Temperature</h4><div class="big" id="piTemp">{{ state.system.pi_temperature_c or "Unavailable" }}</div></div>
        <div class="info-box"><h4>RAM Usage</h4><div class="big" id="ramUsage">{{ state.system.ram_percent or "Unavailable" }}</div></div>
        <div class="info-box"><h4>RAM Used / Total</h4><div id="ramDetail">{{ state.system.ram_used_mb or "Unavailable" }} / {{ state.system.ram_total_mb or "Unavailable" }}</div></div>
      </div>
      <div class="info">
        <div class="info-box"><h4>Network Status</h4><div id="networkStatus">{{ state.system.network_status or "Unknown" }}</div></div>
        <div class="info-box"><h4>Network Interface</h4><div id="networkIface">{{ state.system.network_iface or "Unknown" }}</div></div>
        <div class="info-box"><h4>Link Speed Mbps</h4><div id="networkLinkSpeed">{{ state.system.network_link_speed_mbps or "Unknown" }}</div></div>
        <div class="info-box"><h4>Last Audio</h4><div class="link-box" id="lastAudio">{{ state.last_audio.file or "None" }}</div></div>
        <div class="info-box"><h4>Last Audio Status</h4><div id="lastAudioStatus">{{ state.last_audio.status or "None" }}</div></div>
      </div>
    </div>
  </div>
  
  <div id="tab-geofence" class="panel">
    <div style="margin-bottom:14px">
      <strong>Draw garbage detection polygon zone</strong> — click points on the image.
      Minimum 3 points, maximum 20 points. The polygon area is the only area where garbage will be detected.
    </div>

    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <div style="position:relative;display:inline-block;border:2px solid var(--accent);border-radius:12px;overflow:hidden">
        <canvas id="geoCanvas" style="display:block;cursor:crosshair;max-width:100%"></canvas>
        <div id="geoMsg" style="position:absolute;top:8px;left:10px;background:rgba(0,0,0,.6);color:#fff;padding:4px 10px;border-radius:8px;font-size:13px;pointer-events:none">
          Loading snapshot...
        </div>
      </div>

      <div style="display:grid;gap:12px;min-width:230px">
        <div class="info-box">
          <h4>Current Polygon Points</h4>
          <div id="geoRoiDisplay" style="font-family:monospace;font-size:13px;white-space:pre-wrap">—</div>
        </div>
        <div class="info-box">
          <h4>Status</h4>
          <div id="geoStatus">—</div>
        </div>
        <button onclick="geoSave()"
          style="background:var(--accent);color:#001421;border:none;border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          ✅ Save Polygon
        </button>
        <button onclick="geoUndo()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          ↩️ Undo Last Point
        </button>
        <button onclick="geoClear()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          🧹 Clear Points
        </button>
        <button onclick="geoReset()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          🔄 Reset to Default
        </button>
        <button onclick="geoRefreshSnapshot()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          📷 Refresh Snapshot
        </button>
        <div style="color:var(--muted);font-size:12px;line-height:1.6">
          Click multiple points around the required garbage area.<br>
          The final point automatically connects to the first point.<br>
          Supports 3 to 20 points.
        </div>
      </div>
    </div>
  </div>

  <div id="tab-person_geofence" class="panel">
    <div style="margin-bottom:14px">
      <strong>Draw person detection polygon zone</strong> — click points on the image.
      Only persons whose foot point falls inside this polygon will trigger detection.
    </div>

    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <div style="position:relative;display:inline-block;border:2px solid var(--accent);border-radius:12px;overflow:hidden">
        <canvas id="personGeoCanvas" style="display:block;cursor:crosshair;max-width:100%"></canvas>
        <div id="personGeoMsg" style="position:absolute;top:8px;left:10px;background:rgba(0,0,0,.6);color:#fff;padding:4px 10px;border-radius:8px;font-size:13px;pointer-events:none">
          Loading snapshot...
        </div>
      </div>

      <div style="display:grid;gap:12px;min-width:230px">
        <div class="info-box">
          <h4>Current Polygon Points</h4>
          <div id="personGeoRoiDisplay" style="font-family:monospace;font-size:13px;white-space:pre-wrap">—</div>
        </div>
        <div class="info-box">
          <h4>Status</h4>
          <div id="personGeoStatus">—</div>
        </div>
        <button onclick="personGeoSave()"
          style="background:var(--accent);color:#001421;border:none;border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          ✅ Save Polygon
        </button>
        <button onclick="personGeoUndo()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          ↩️ Undo Last Point
        </button>
        <button onclick="personGeoClear()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          🧹 Clear Points
        </button>
        <button onclick="personGeoReset()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          🔄 Reset to Default
        </button>
        <button onclick="personGeoRefreshSnapshot()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          📷 Refresh Snapshot
        </button>
        <div style="color:var(--muted);font-size:12px;line-height:1.6">
          Click multiple points around the required person area.<br>
          The final point automatically connects to the first point.<br>
          Supports 3 to 20 points.
        </div>
      </div>
    </div>
  </div>

  <div id="tab-vehicle_geofence" class="panel">
    <div style="margin-bottom:14px">
      <strong>Draw vehicle detection polygon zone</strong> — click points on the image.
      Vehicle detection triggers only when enough of the full vehicle box overlaps this polygon.
      This avoids wrong detection when only tyres or road-split bottom parts enter the zone.
    </div>

    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <div style="position:relative;display:inline-block;border:2px solid var(--accent);border-radius:12px;overflow:hidden">
        <canvas id="vehicleGeoCanvas" style="display:block;cursor:crosshair;max-width:100%"></canvas>
        <div id="vehicleGeoMsg" style="position:absolute;top:8px;left:10px;background:rgba(0,0,0,.6);color:#fff;padding:4px 10px;border-radius:8px;font-size:13px;pointer-events:none">
          Loading snapshot...
        </div>
      </div>

      <div style="display:grid;gap:12px;min-width:230px">
        <div class="info-box">
          <h4>Current Polygon Points</h4>
          <div id="vehicleGeoRoiDisplay" style="font-family:monospace;font-size:13px;white-space:pre-wrap">—</div>
        </div>
        <div class="info-box">
          <h4>Status</h4>
          <div id="vehicleGeoStatus">—</div>
        </div>
        <button onclick="vehicleGeoSave()"
          style="background:var(--accent);color:#001421;border:none;border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          ✅ Save Polygon
        </button>
        <button onclick="vehicleGeoUndo()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          ↩️ Undo Last Point
        </button>
        <button onclick="vehicleGeoClear()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          🧹 Clear Points
        </button>
        <button onclick="vehicleGeoReset()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:12px 18px;font-weight:700;cursor:pointer;font-size:15px">
          🔄 Reset to Default
        </button>
        <button onclick="vehicleGeoRefreshSnapshot()"
          style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px">
          📷 Refresh Snapshot
        </button>
        <div style="color:var(--muted);font-size:12px;line-height:1.6">
          Vehicle validation uses bounding-box overlap, not only bottom/tyre point.<br>
          Default required overlap: 35%.<br>
          Supports 3 to 20 points.
        </div>
      </div>
    </div>
  </div>



  <div class="footer-note">
    Local dashboard: <strong>{{ local_dashboard }}</strong><br>
    Local stream: <strong>{{ local_stream }}</strong><br>
    Permanent live: <strong>{{ state.live_link.url or "Inactive" }}</strong><br>
    Camera config: <strong>{{ state.camera_config_url or "Unavailable" }}</strong>
  </div>
</div>

<script>
// ============ POLYGON GEOFENCE EDITOR ============
function createPolygonEditor(options) {
  const canvas = document.getElementById(options.canvasId);
  const ctx = canvas.getContext('2d');
  const messageEl = document.getElementById(options.messageId);
  const displayEl = document.getElementById(options.displayId);
  const statusEl = document.getElementById(options.statusId);

  let image = new Image();
  let points = [];
  let maxPoints = 20;
  let minPoints = 3;

  function canvasPos(e) {
    const r = canvas.getBoundingClientRect();
    const scaleX = canvas.width / r.width;
    const scaleY = canvas.height / r.height;

    return {
      x: (e.clientX - r.left) * scaleX,
      y: (e.clientY - r.top) * scaleY
    };
  }

  function polygonFromBox(box) {
    if (!box || box.length !== 4) return [];
    return [
      [box[0], box[1]],
      [box[2], box[1]],
      [box[2], box[3]],
      [box[0], box[3]]
    ];
  }

  function draw() {
    if (!image || !image.complete || !canvas.width || !canvas.height) {
      return;
    }

    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

    if (points.length > 0) {
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = options.lineColor;
      ctx.fillStyle = options.fillColor;

      ctx.beginPath();
      points.forEach((point, idx) => {
        const x = point[0] * canvas.width;
        const y = point[1] * canvas.height;

        if (idx === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      if (points.length >= 3) {
        ctx.closePath();
        ctx.fill();
      }

      ctx.stroke();

      points.forEach((point, idx) => {
        const x = point[0] * canvas.width;
        const y = point[1] * canvas.height;

        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fillStyle = options.pointColor;
        ctx.fill();

        ctx.font = 'bold 12px Arial';
        ctx.fillStyle = options.textColor;
        ctx.fillText(String(idx + 1), x + 7, y - 7);
      });

      ctx.font = 'bold 13px Arial';
      ctx.fillStyle = options.textColor;
      ctx.fillText(options.label, 10, 22);
    }

    displayEl.textContent = points.length
      ? points.map((p, i) => `${i + 1}: x=${p[0].toFixed(4)}, y=${p[1].toFixed(4)}`).join('\n')
      : 'No points selected';
  }

  canvas.addEventListener('pointerdown', e => {
    e.preventDefault();

    if (!canvas.width || !canvas.height) {
      statusEl.textContent = '⚠️ Snapshot not loaded yet';
      return;
    }

    if (points.length >= maxPoints) {
      statusEl.textContent = `⚠️ Maximum ${maxPoints} points allowed`;
      return;
    }

    const pos = canvasPos(e);
    const xRatio = Math.max(0, Math.min(1, pos.x / canvas.width));
    const yRatio = Math.max(0, Math.min(1, pos.y / canvas.height));

    points.push([xRatio, yRatio]);
    statusEl.textContent = `Point ${points.length} added`;
    draw();
  });

  async function refreshSnapshot() {
    messageEl.textContent = 'Loading snapshot...';
    statusEl.textContent = 'Loading saved polygon...';

    image = new Image();

    image.onload = async () => {
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      ctx.drawImage(image, 0, 0);
      messageEl.textContent = 'Click points to draw polygon';

      try {
        const resp = await fetch(options.getUrl + '?t=' + Date.now());
        const data = await resp.json();

        minPoints = data.min_points || 3;
        maxPoints = data.max_points || 20;

        const serverPolygon = data[options.polygonKey];
        const fallbackBox = data[options.roiKey];

        if (serverPolygon && serverPolygon.length >= minPoints) {
          points = serverPolygon;
        } else {
          points = polygonFromBox(fallbackBox);
        }

        statusEl.textContent = `Loaded ${points.length} points`;
        draw();
      } catch (e) {
        points = [];
        statusEl.textContent = '⚠️ Could not load saved polygon';
        draw();
      }
    };

    image.onerror = () => {
      messageEl.textContent = 'No frame available — camera connecting?';
      statusEl.textContent = '❌ Snapshot unavailable';
    };

    image.src = '/api/snapshot?t=' + Date.now();
  }

  async function save() {
    if (points.length < minPoints) {
      statusEl.textContent = `⚠️ Add at least ${minPoints} points`;
      return;
    }

    if (points.length > maxPoints) {
      statusEl.textContent = `⚠️ Maximum ${maxPoints} points allowed`;
      return;
    }

    statusEl.textContent = 'Saving polygon...';

    try {
      const payload = {};
      payload[options.polygonKey] = points;

      const resp = await fetch(options.postUrl, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
      });

      const data = await resp.json();

      if (data.ok) {
        points = data[options.polygonKey] || points;
        statusEl.textContent = `✅ Saved ${points.length}-point polygon. Applied immediately.`;
        draw();
      } else {
        statusEl.textContent = '❌ Error: ' + (data.error || 'Unknown error');
      }
    } catch (e) {
      statusEl.textContent = '❌ Network error while saving';
    }
  }

  async function reset() {
    statusEl.textContent = 'Resetting polygon...';

    try {
      const resp = await fetch(options.resetUrl, {method: 'POST'});
      const data = await resp.json();

      if (data.ok) {
        points = data[options.polygonKey] || [];
        statusEl.textContent = `✅ Reset to default ${points.length}-point polygon`;
        draw();
      } else {
        statusEl.textContent = '❌ Reset failed';
      }
    } catch (e) {
      statusEl.textContent = '❌ Network error while resetting';
    }
  }

  function undo() {
    if (points.length === 0) {
      statusEl.textContent = 'No points to undo';
      return;
    }

    points.pop();
    statusEl.textContent = `Removed last point. Current points: ${points.length}`;
    draw();
  }

  function clear() {
    points = [];
    statusEl.textContent = 'Cleared all points';
    draw();
  }

  return {
    refreshSnapshot,
    save,
    reset,
    undo,
    clear
  };
}

const garbagePolygonEditor = createPolygonEditor({
  canvasId: 'geoCanvas',
  messageId: 'geoMsg',
  displayId: 'geoRoiDisplay',
  statusId: 'geoStatus',
  getUrl: '/api/geofence',
  postUrl: '/api/geofence',
  resetUrl: '/api/geofence/reset',
  polygonKey: 'garbage_polygon',
  roiKey: 'garbage_roi',
  label: 'Garbage Polygon Zone',
  lineColor: '#39c6ff',
  fillColor: 'rgba(57,198,255,0.00)',
  pointColor: '#39c6ff',
  textColor: '#ffffff'
});

const personPolygonEditor = createPolygonEditor({
  canvasId: 'personGeoCanvas',
  messageId: 'personGeoMsg',
  displayId: 'personGeoRoiDisplay',
  statusId: 'personGeoStatus',
  getUrl: '/api/person_geofence',
  postUrl: '/api/person_geofence',
  resetUrl: '/api/person_geofence/reset',
  polygonKey: 'person_polygon',
  roiKey: 'person_roi',
  label: 'Person Polygon Zone',
  lineColor: '#22c55e',
  fillColor: 'rgba(34,197,94,0.00)',
  pointColor: '#22c55e',
  textColor: '#ffffff'
});

const vehiclePolygonEditor = createPolygonEditor({
  canvasId: 'vehicleGeoCanvas',
  messageId: 'vehicleGeoMsg',
  displayId: 'vehicleGeoRoiDisplay',
  statusId: 'vehicleGeoStatus',
  getUrl: '/api/vehicle_geofence',
  postUrl: '/api/vehicle_geofence',
  resetUrl: '/api/vehicle_geofence/reset',
  polygonKey: 'vehicle_polygon',
  roiKey: 'vehicle_roi',
  label: 'Vehicle Polygon Zone',
  lineColor: '#ffc857',
  fillColor: 'rgba(255,200,87,0.00)',
  pointColor: '#ffc857',
  textColor: '#ffffff'
});

function geoRefreshSnapshot() {
  garbagePolygonEditor.refreshSnapshot();
}

function geoSave() {
  garbagePolygonEditor.save();
}

function geoReset() {
  garbagePolygonEditor.reset();
}

function geoUndo() {
  garbagePolygonEditor.undo();
}

function geoClear() {
  garbagePolygonEditor.clear();
}

function personGeoRefreshSnapshot() {
  personPolygonEditor.refreshSnapshot();
}

function personGeoSave() {
  personPolygonEditor.save();
}

function personGeoReset() {
  personPolygonEditor.reset();
}

function personGeoUndo() {
  personPolygonEditor.undo();
}

function personGeoClear() {
  personPolygonEditor.clear();
}

function vehicleGeoRefreshSnapshot() {
  vehiclePolygonEditor.refreshSnapshot();
}

function vehicleGeoSave() {
  vehiclePolygonEditor.save();
}

function vehicleGeoReset() {
  vehiclePolygonEditor.reset();
}

function vehicleGeoUndo() {
  vehiclePolygonEditor.undo();
}

function vehicleGeoClear() {
  vehiclePolygonEditor.clear();
}

let currentVehicleDetectionMode = "{{ state.system.vehicle_detection_mode or state.last_vehicle.mode or 'static' }}";

function updateVehicleModeUi(mode, threshold, staticStaySec) {
  currentVehicleDetectionMode = (mode || 'static').toLowerCase();

  const modeEl = document.getElementById('vehicleDetectionMode');
  const toggleEl = document.getElementById('vehicleModeToggle');

  if (modeEl) {
    modeEl.textContent = currentVehicleDetectionMode.toUpperCase();
  }

  if (toggleEl) {
    if (currentVehicleDetectionMode === 'moving') {
      toggleEl.textContent = '🚗 Switch to Static Detection';
    } else {
      toggleEl.textContent = '🏃 Switch to Moving Detection';
    }
  }

  const overlapEl = document.getElementById('vehicleGeofenceOverlap');

  if (overlapEl && threshold != null) {
    const currentText = overlapEl.textContent || '0';

    if (currentText === '0' || currentText === '0.0') {
      overlapEl.textContent = 'Threshold: ' + Math.round(Number(threshold) * 100) + '%';
    }
  }

  if (staticStaySec !== undefined && staticStaySec !== null) {
    updateVehicleStaticStayUi(staticStaySec);
  }
}


function updatePersonStaticStayUi(seconds) {
  const value = Number(seconds || 5);
  const input = document.getElementById('personStaticStayInput');
  const status = document.getElementById('personStaticStayStatus');

  // Do not overwrite while user is typing. The dashboard refreshes /api/state
  // every 2 seconds, so updating input.value here resets manual edits.
  if (input && document.activeElement !== input) {
    input.value = value;
  }

  if (status) {
    status.textContent = 'Current: ' + value + ' sec';
  }
}


async function savePersonStaticStay() {
  const input = document.getElementById('personStaticStayInput');
  const value = input ? Number(input.value || 5) : 5;

  try {
    const resp = await fetch('/api/person_static_stay', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({seconds: value})
    });

    const data = await resp.json();

    if (!resp.ok || !data.ok) {
      alert('Person stay update failed: ' + (data.error || 'Unknown error'));
      return;
    }

    updatePersonStaticStayUi(data.person_static_stay_sec);
  } catch (e) {
    alert('Network error while saving person stay time');
  }
}


function updateVehicleStaticStayUi(seconds) {
  const value = Number(seconds || 5);
  const input = document.getElementById('vehicleStaticStayInput');
  const status = document.getElementById('vehicleStaticStayStatus');

  // Do not overwrite while user is typing. The dashboard refreshes /api/state
  // every 2 seconds, so updating input.value here resets manual edits.
  if (input && document.activeElement !== input) {
    input.value = value;
  }

  if (status) {
    status.textContent = 'Current: ' + value + ' sec';
  }
}


async function saveVehicleStaticStay() {
  const input = document.getElementById('vehicleStaticStayInput');
  const value = input ? Number(input.value || 5) : 5;

  try {
    const resp = await fetch('/api/vehicle_static_stay', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({seconds: value})
    });

    const data = await resp.json();

    if (!resp.ok || !data.ok) {
      alert('Static stay update failed: ' + (data.error || 'Unknown error'));
      return;
    }

    updateVehicleStaticStayUi(data.vehicle_static_stay_sec);
    updateVehicleModeUi(
      data.vehicle_detection_mode,
      data.vehicle_geofence_overlap_threshold,
      data.vehicle_static_stay_sec
    );
  } catch (e) {
    alert('Network error while saving static stay time');
  }
}

async function setVehicleDetectionMode(mode) {
  try {
    const resp = await fetch('/api/vehicle_detection_mode', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({mode})
    });

    const data = await resp.json();

    if (!resp.ok || !data.ok) {
      alert('Vehicle mode change failed: ' + (data.error || 'Unknown error'));
      return;
    }

    updateVehicleModeUi(
      data.vehicle_detection_mode,
      data.vehicle_geofence_overlap_threshold,
      data.vehicle_static_stay_sec
    );
  } catch (e) {
    alert('Network error while changing vehicle mode');
  }
}

function toggleVehicleDetectionMode() {
  const nextMode = currentVehicleDetectionMode === 'moving' ? 'static' : 'moving';
  setVehicleDetectionMode(nextMode);
}

// ============ DASHBOARD CONTROLS ============

const CONTROL_DEVICE_ID = {{ state.device_id | tojson }};

const CONTROL_STATUS_IDS = {
  person_detection_enabled: 'ctrlPersonDetectionStatus',
  vehicle_detection_enabled: 'ctrlVehicleDetectionStatus',
  garbage_detection_enabled: 'ctrlGarbageDetectionStatus',
  person_video_recording_enabled: 'ctrlPersonVideoStatus',
  vehicle_video_recording_enabled: 'ctrlVehicleVideoStatus'
};

function controlSetText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function controlSetStatusPill(id, enabled, onText = 'ENABLED', offText = 'DISABLED') {
  const el = document.getElementById(id);
  if (!el) return;

  el.textContent = enabled ? onText : offText;
  el.classList.remove('on', 'off');
  el.classList.add(enabled ? 'on' : 'off');
}

function prettyGarbageMode(mode) {
  const normalized = String(mode || 'ai').trim().toLowerCase();
  return normalized === 'normal' ? 'Normal Mode' : 'AI Mode';
}

function controlSetGarbageModePill(mode) {
  const el = document.getElementById('ctrlGarbageModeStatus');
  if (!el) return;

  const normalized = String(mode || 'ai').trim().toLowerCase();
  el.textContent = prettyGarbageMode(normalized).toUpperCase();
  el.classList.remove('on', 'off');

  if (normalized === 'ai') {
    el.classList.add('on');
  }
}

function controlStatus(message, good = true) {
  const el = document.getElementById('controlsStatusLine');
  if (!el) return;

  el.textContent = message;
  el.style.color = good ? 'var(--muted)' : '#ff9b9b';
}

function controlVolumePreview(value) {
  controlSetText('ctrlVolumePreview', String(value) + '%');
}

function updateControlsFromState(s) {
  if (!s) return;

  const flags = s.feature_flags || {};
  Object.keys(CONTROL_STATUS_IDS).forEach(flagName => {
    if (flags[flagName] !== undefined) {
      controlSetStatusPill(CONTROL_STATUS_IDS[flagName], !!flags[flagName]);
    }
  });

  const garbageMode =
    s.garbage_detection_mode ||
    (s.system && s.system.garbage_detection_mode) ||
    'ai';

  controlSetGarbageModePill(garbageMode);

  if (s.warning_audio) {
    const globalWarningEnabled = s.warning_audio.enabled !== undefined
      ? !!s.warning_audio.enabled
      : true;

    const personWarningEnabled = s.warning_audio.person_enabled !== undefined
      ? !!s.warning_audio.person_enabled
      : globalWarningEnabled;

    const vehicleWarningEnabled = s.warning_audio.vehicle_enabled !== undefined
      ? !!s.warning_audio.vehicle_enabled
      : globalWarningEnabled;

    controlSetStatusPill(
      'ctrlPersonWarningAudioStatus',
      personWarningEnabled,
      s.warning_audio.schedule_enabled ? 'SCHEDULED' : 'ENABLED',
      'DISABLED'
    );

    controlSetStatusPill(
      'ctrlVehicleWarningAudioStatus',
      vehicleWarningEnabled,
      s.warning_audio.schedule_enabled ? 'SCHEDULED' : 'ENABLED',
      'DISABLED'
    );
  }

  const powerSavingEnabled =
    (s.power_saving && s.power_saving.enabled !== undefined)
      ? !!s.power_saving.enabled
      : !!(s.power_saving_enabled || (s.system && s.system.power_saving_active));

  controlSetStatusPill('ctrlPowerSavingStatus', powerSavingEnabled, 'ENABLED', 'DISABLED');

  if (s.audio_queue_size !== undefined && s.audio_queue_size !== null) {
    controlSetText('ctrlAudioQueueStatus', 'Queue: ' + s.audio_queue_size);
  }

  const personStay =
    s.person_static_stay_sec ||
    (s.system && s.system.person_static_stay_sec) ||
    null;

  if (personStay !== null) {
    updatePersonStaticStayUi(personStay);
  }
  
    const vehicleStay =
    s.vehicle_static_stay_sec ||
    (s.system && s.system.vehicle_static_stay_sec) ||
    null;

  if (vehicleStay !== null) {
    updateVehicleStaticStayUi(vehicleStay);
  }

  const vehicleMode =
    s.vehicle_detection_mode ||
    (s.system && s.system.vehicle_detection_mode) ||
    currentVehicleDetectionMode ||
    'static';

  updateVehicleModeUi(
    vehicleMode,
    s.vehicle_geofence_overlap_threshold ||
      (s.system && s.system.vehicle_geofence_overlap_threshold),
    vehicleStay
  );
  
}

function updateControlsPanel(data) {
  updateControlsFromState(data);

  if (data && data.volume) {
    if (data.volume.ok) {
      const volume = Number(data.volume.volume_percent || 0);
      const slider = document.getElementById('ctrlVolumeRange');

      if (slider) slider.value = volume;

      controlVolumePreview(volume);
      controlSetStatusPill('ctrlVolumeStatus', true, 'CURRENT: ' + volume + '%', 'VOLUME ERROR');
    } else {
      controlSetText('ctrlVolumeStatus', 'Volume Error');
      const el = document.getElementById('ctrlVolumeStatus');
      if (el) {
        el.classList.remove('on');
        el.classList.add('off');
      }
    }
  }
}

async function controlFetchJson(url, options = {}) {
  const resp = await fetch(url, options);
  const data = await resp.json().catch(() => ({}));

  if (!resp.ok || data.ok === false) {
    throw new Error(data.error || data.message || ('HTTP ' + resp.status));
  }

  return data;
}

async function loadControlsState() {
  try {
    const data = await controlFetchJson('/api/controls/state?t=' + Date.now());
    updateControlsPanel(data);
    controlStatus('Controls refreshed.');
  } catch (e) {
    controlStatus('Controls refresh failed: ' + e.message, false);
  }
}

async function controlSetFeature(flag, enabled) {
  try {
    controlStatus('Updating control...');
    const data = await controlFetchJson('/api/controls/feature', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({flag, enabled})
    });

    updateControlsPanel(data);
    controlStatus(flag + ' set to ' + (enabled ? 'enabled' : 'disabled') + '.');
  } catch (e) {
    controlStatus('Feature update failed: ' + e.message, false);
  }
}

async function controlSetGarbageMode(mode) {
  try {
    const normalized = String(mode || 'ai').trim().toLowerCase();
    controlStatus('Changing garbage mode to ' + prettyGarbageMode(normalized) + '...');

    const data = await controlFetchJson('/api/controls/garbage/mode', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({mode: normalized})
    });

    updateControlsPanel(data);
    controlStatus('Garbage mode changed to ' + prettyGarbageMode(data.garbage_detection_mode) + '.');
    refreshState();
  } catch (e) {
    controlStatus('Garbage mode update failed: ' + e.message, false);
  }
}

async function controlSetWarningAudio(target, enabled) {
  try {
    const normalizedTarget = String(target || '').trim().toLowerCase();
    const prettyTarget = normalizedTarget === 'vehicle' ? 'Vehicle' : 'Person';

    controlStatus('Updating ' + prettyTarget.toLowerCase() + ' warning audio...');

    const data = await controlFetchJson('/api/controls/warning_audio', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({target: normalizedTarget, enabled})
    });

    updateControlsPanel(data);
    controlStatus(prettyTarget + ' warning audio ' + (enabled ? 'enabled' : 'disabled') + '.');
  } catch (e) {
    controlStatus('Warning audio update failed: ' + e.message, false);
  }
}


async function controlManualGarbage() {
  try {
    controlStatus('Running manual garbage detection. Please wait...');
    const data = await controlFetchJson('/api/controls/garbage/manual_detect', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({})
    });

    updateControlsPanel(data);
    controlStatus('Manual garbage detection completed.');
    refreshState();
  } catch (e) {
    controlStatus('Manual garbage detection failed: ' + e.message, false);
  }
}

async function controlGarbageSample() {
  try {
    controlStatus('Capturing garbage sample/reference...');
    const data = await controlFetchJson('/api/controls/garbage/sample_capture', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({})
    });

    updateControlsPanel(data);
    controlStatus('Garbage sample captured successfully.');
    refreshState();
  } catch (e) {
    controlStatus('Garbage sample capture failed: ' + e.message, false);
  }
}

function controlOpenGarbageReferenceUpload() {
  const input = document.getElementById('garbageReferenceUploadInput');
  if (!input) {
    controlStatus('Reference upload input not found.', false);
    return;
  }

  input.click();
}

async function controlGarbageReferenceUpload(input) {
  const file = input && input.files && input.files.length ? input.files[0] : null;

  if (!file) {
    return;
  }

  const maxBytes = 12 * 1024 * 1024;

  if (file.size > maxBytes) {
    controlStatus('Reference upload failed: image is larger than 12 MB.', false);
    input.value = '';
    return;
  }

  try {
    controlStatus('Uploading garbage reference image...');

    const formData = new FormData();
    formData.append('reference_image', file);

    const data = await controlFetchJson('/api/controls/garbage/reference_upload', {
      method: 'POST',
      body: formData
    });

    updateControlsPanel(data);
    controlStatus('Garbage reference image uploaded successfully.');
    refreshState();
  } catch (e) {
    controlStatus('Garbage reference upload failed: ' + e.message, false);
  } finally {
    input.value = '';
  }
}

async function controlClearAudioQueue() {
  try {
    controlStatus('Clearing audio queue...');
    const data = await controlFetchJson('/api/controls/audio/clear_queue', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({})
    });

    updateControlsPanel(data);
    controlStatus('Audio queue cleared. Cleared count: ' + (data.cleared_count ?? 0));
    refreshState();
  } catch (e) {
    controlStatus('Clear audio queue failed: ' + e.message, false);
  }
}

async function controlSetPowerSaving(enabled) {
  try {
    controlStatus('Updating power saving mode...');
    const data = await controlFetchJson('/api/controls/power_saving', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({enabled})
    });

    updateControlsPanel(data);
    controlStatus('Power saving ' + (enabled ? 'enabled' : 'disabled') + '.');
    refreshState();
  } catch (e) {
    controlStatus('Power saving update failed: ' + e.message, false);
  }
}

function controlSetRestartStatus(text, restarting = false) {
  const statusEl = document.getElementById('ctrlDeviceRestartStatus');

  if (!statusEl) {
    return;
  }

  statusEl.textContent = text;
  statusEl.classList.remove('on', 'off');

  if (restarting) {
    statusEl.classList.add('off');
  }
}

function controlWaitForDeviceAfterRestart() {
  const button = document.getElementById('ctrlDeviceRestartButton');

  let attempts = 0;
  let sawDeviceOffline = false;

  const maxAttempts = 36;
  const initialDelayMs = 5000;
  const pollingIntervalMs = 5000;

  setTimeout(() => {
    const timer = setInterval(async () => {
      attempts += 1;

      try {
        const response = await fetch(
          '/api/controls/state?t=' + Date.now(),
          {
            method: 'GET',
            cache: 'no-store'
          }
        );

        if (response.ok && sawDeviceOffline) {
          clearInterval(timer);
          controlSetRestartStatus('ONLINE');
          controlStatus('Device restarted successfully. Reloading...');
          window.location.reload();
          return;
        }

        if (response.ok && !sawDeviceOffline) {
          controlStatus(
            'Restart request accepted. Waiting for device shutdown...'
          );
        }
      } catch (error) {
        sawDeviceOffline = true;

        controlStatus(
          'Device is offline and rebooting... Attempt ' +
          attempts +
          ' of ' +
          maxAttempts +
          '.'
        );
      }

      if (attempts >= maxAttempts) {
        clearInterval(timer);

        if (button) {
          button.disabled = false;
        }

        controlSetRestartStatus('CHECK DEVICE', true);

        controlStatus(
          sawDeviceOffline
            ? 'The device went offline but has not returned yet.'
            : 'The dashboard never detected the device going offline.',
          false
        );
      }
    }, pollingIntervalMs);
  }, initialDelayMs);
}

async function controlRestartDevice() {
  const tokenInput = document.getElementById('ctrlDeviceRestartToken');
  const button = document.getElementById('ctrlDeviceRestartButton');

  const token = tokenInput ? tokenInput.value.trim() : '';

  if (!token) {
    controlStatus('Enter the MQTT command token first.', false);

    if (tokenInput) {
      tokenInput.focus();
    }

    return;
  }

  const typedDeviceId = window.prompt(
    'This will fully reboot the Raspberry Pi.\n\n' +
    'Type the device ID exactly to continue:\n' +
    CONTROL_DEVICE_ID
  );


  if (typedDeviceId === null) {
    controlStatus('Device restart cancelled.');
    return;
  }

  if (typedDeviceId.trim() !== CONTROL_DEVICE_ID) {
    controlStatus(
      'Device restart cancelled: the device ID did not match.',
      false
    );
    return;
  }

  const confirmed = window.confirm(
    'Restart device ' +
    CONTROL_DEVICE_ID +
    ' now?\n\n' +
    'The live feed and dashboard will be temporarily unavailable.'
  );

  if (!confirmed) {
    controlStatus('Device restart cancelled.');
    return;
  }

  try {
    if (button) {
      button.disabled = true;
    }

    controlSetRestartStatus('REQUESTING...', true);
    controlStatus('Sending device restart request...');

    const data = await controlFetchJson(
      '/api/controls/device/restart',
      {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          token,
          confirm_device_id: typedDeviceId.trim()
        })
      }
    );

    if (tokenInput) {
      tokenInput.value = '';
    }

    controlSetRestartStatus('RESTARTING', true);
    controlStatus(
      data.message ||
      'Device restart accepted. Waiting for the dashboard to return...'
    );

    controlWaitForDeviceAfterRestart();
  } catch (e) {
    if (button) {
      button.disabled = false;
    }

    controlSetRestartStatus('FAILED', true);
    controlStatus('Device restart failed: ' + e.message, false);
  }
}

async function controlRefreshVolume() {
  try {
    controlStatus('Reading current Pi volume...');
    const data = await controlFetchJson('/api/controls/volume?t=' + Date.now());
    updateControlsPanel({volume: data});
    controlStatus('Current Pi volume: ' + data.volume_percent + '%.');
  } catch (e) {
    controlStatus('Volume read failed: ' + e.message, false);
  }
}

async function controlSetVolume(percent) {
  try {
    percent = Math.max(0, Math.min(100, Number(percent || 0)));
    controlStatus('Setting Pi volume to ' + percent + '%...');

    const data = await controlFetchJson('/api/controls/volume', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({volume_percent: percent})
    });

    updateControlsPanel({volume: data});
    controlStatus('Pi volume set to ' + data.volume_percent + '%.');
    refreshState();
  } catch (e) {
    controlStatus('Volume set failed: ' + e.message, false);
  }
}

function controlSetVolumeFromSlider() {
  const slider = document.getElementById('ctrlVolumeRange');
  controlSetVolume(slider ? slider.value : 70);
}

// ============ END DASHBOARD CONTROLS ============
// ============ END POLYGON GEOFENCE EDITOR ============


function showTab(name, btn){
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));

  const panel = document.getElementById('tab-' + name);
  if (panel) {
    panel.classList.add('active');
  }

  if (btn) {
    btn.classList.add('active');
  } else {
    document.querySelectorAll('.tab-btn').forEach(button => {
      const clickAttr = button.getAttribute('onclick') || '';
      if (clickAttr.includes("'" + name + "'") || clickAttr.includes('"' + name + '"')) {
        button.classList.add('active');
      }
    });
  }

  if (name === 'geofence') geoRefreshSnapshot();
  if (name === 'person_geofence') personGeoRefreshSnapshot();
  if (name === 'vehicle_geofence') vehicleGeoRefreshSnapshot();
  if (name === 'controls') loadControlsState();
}

document.addEventListener('DOMContentLoaded', () => {
  const initialTab = "{{ initial_tab | default('live') }}";

  if (initialTab === "geofence") {
    showTab("geofence", null);
  } else if (initialTab === "person_geofence") {
    showTab("person_geofence", null);
  } else if (initialTab === "vehicle_geofence") {
    showTab("vehicle_geofence", null);
  } else if (initialTab === "controls") {
    showTab("controls", null);
  } else {
    showTab("live", null);
  }

  updateVehicleModeUi(currentVehicleDetectionMode, null);
});

function severityBadge(sev){
  if(sev === 'HIGH') return '<span class="badge high">HIGH</span>';
  if(sev === 'MEDIUM') return '<span class="badge medium">MEDIUM</span>';
  if(sev === 'LOW') return '<span class="badge low">LOW</span>';
  return '<span class="badge none">NONE</span>';
}
function uiGet(id) {
  return document.getElementById(id);
}

function uiText(id, value) {
  const el = uiGet(id);
  if (el) el.textContent = value;
}

function uiHtml(id, value) {
  const el = uiGet(id);
  if (el) el.innerHTML = value;
}

function uiSrc(id, value) {
  const el = uiGet(id);
  if (el) el.src = value;
}

function personMediaName(person) {
  if (!person) return '';
  return person.image || person.image_file || '';
}

function personStatusText(person) {
  if (!person) return 'No recent detection';
  if (person.detected && personMediaName(person)) return 'Detected now';
  if (person.detected) return 'Detected now, preparing image...';
  if ((person.count || 0) > 0) {
    const stableSec = Number(person.stable_inside_sec || 0);
    const requiredSec = Number(person.stable_required_sec || 0);
    if (requiredSec > 0 && stableSec < requiredSec) {
      return 'Person seen, waiting stay time... ' + stableSec.toFixed(1) + '/' + requiredSec + ' sec';
    }
    return 'Detected, confirming image...';
  }
  if (personMediaName(person)) return 'Last detection saved';
  return 'No recent detection';
}

function vehicleStatusText(vehicle) {
  if (!vehicle) return 'No recent detection';

  const imageName = vehicle.image || vehicle.image_file || '';

  if (vehicle.detected && imageName) {
    return 'Detected now';
  }

  if (vehicle.detected) {
    return 'Detected now, preparing image...';
  }

  if ((vehicle.count || 0) > 0) {
    const stableSec = Number(vehicle.stable_inside_sec || 0);
    const requiredSec = Number(vehicle.stable_required_sec || 0);
    const hitCount = Number(vehicle.stable_hit_count || 0);
    const stableCount = Number(vehicle.stable_vehicle_count || 0);

    if (requiredSec > 0) {
      return (
        'Vehicle seen, waiting stable time... ' +
        stableSec.toFixed(1) + '/' + requiredSec + ' sec' +
        ' | hits: ' + hitCount +
        ' | stable vehicles: ' + stableCount
      );
    }

    return 'Vehicle seen, confirming...';
  }

  if (imageName) return 'Last detection saved';

  return 'No recent detection';
}

async function refreshState(){
  try{
    const r = await fetch('/api/state?t=' + Date.now(), {cache: 'no-store'});
    const s = await r.json();

    const counts = s.counts || {};
    const system = s.system || {};
    const links = s.links || {};
    const liveLink = s.live_link || {};
    const lastPerson = s.last_person || {};
    const lastVehicle = s.last_vehicle || {};
    const lastGarbage = s.last_garbage || {};

    uiText('highCount', counts.HIGH ?? 0);
    uiText('mediumCount', counts.MEDIUM ?? 0);
    uiText('lowCount', counts.LOW ?? 0);

    uiText('cameraStatus', system.camera_connected ? 'Connected' : 'Disconnected');
    uiText('lastError', system.last_error || 'None');

    const currentGarbageMode =
      s.garbage_detection_mode ||
      system.garbage_detection_mode ||
      'ai';

    // Safe updates: garbage/audio panels are removed in this build, so every DOM write is guarded.
    uiText('garbageMode', prettyGarbageMode(currentGarbageMode));
    uiHtml('garbageSeverity', severityBadge(lastGarbage.severity || 'NONE'));

    uiText('permanentLiveUrl', liveLink.url || 'Inactive');
    uiText('permanentLiveStatus', liveLink.expires_at || 'Inactive');
    uiText('cameraConfigUrl', s.camera_config_url || 'Unavailable');

    uiText('garbageTime', lastGarbage.time || 'Waiting...');
    uiText('garbageTriggeredBy', lastGarbage.triggered_by || 'N/A');
    uiText('garbageSeverityText', lastGarbage.severity || 'NONE');
    uiText('garbageCount', lastGarbage.blob_count ?? 0);
    uiText('garbageDiffRatio', lastGarbage.diff_ratio ?? 0);
    uiText('garbageEdgeRatio', lastGarbage.edge_ratio ?? 0);
    uiText('garbageBlobAreaRatio', lastGarbage.blob_area_ratio ?? 0);

    uiText('personTime', lastPerson.time || 'Waiting...');
    uiText('personCount', lastPerson.count ?? 0);
    uiText('personStatus', personStatusText(lastPerson));
    uiText('personBestConfidence', lastPerson.best_confidence ?? 0);
    uiText('personImageStatus', lastPerson.image_status || 'None');
    uiText('personImagePath', lastPerson.image_uploaded_path || 'None');

    const personStay = s.person_static_stay_sec || system.person_static_stay_sec || null;
    if (personStay !== null) {
      updatePersonStaticStayUi(personStay);
    }
    const personImageName = personMediaName(lastPerson);
    if (personImageName) {
      uiSrc('personImg', '/media/' + encodeURI(personImageName) + '?t=' + Date.now());
    }

    uiText('vehicleTime', lastVehicle.time || 'Waiting...');
    uiText('vehicleCount', lastVehicle.count ?? 0);
    uiText('vehicleStatus', vehicleStatusText(lastVehicle));
    uiText('vehicleBestConfidence', lastVehicle.best_confidence ?? 0);

    const vehicleMode = s.vehicle_detection_mode || system.vehicle_detection_mode || lastVehicle.mode || 'static';
    updateVehicleModeUi(vehicleMode, s.vehicle_geofence_overlap_threshold || system.vehicle_geofence_overlap_threshold);

    uiText('vehicleLabels', (lastVehicle.labels && lastVehicle.labels.length) ? lastVehicle.labels.join(', ') : 'None');

    const vehicleOverlap = Number(lastVehicle.geofence_overlap || 0);
    uiText(
      'vehicleGeofenceOverlap',
      vehicleOverlap > 0
        ? (Math.round(vehicleOverlap * 100) + '% inside polygon')
        : ('Threshold: ' + Math.round(Number(s.vehicle_geofence_overlap_threshold || system.vehicle_geofence_overlap_threshold || 0.35) * 100) + '%')
    );

    uiText('vehicleImageStatus', lastVehicle.image_status || 'None');
    uiText('vehicleImagePath', lastVehicle.image_uploaded_path || 'None');
    if (lastVehicle.image) {
      uiSrc('vehicleImg', '/media/' + lastVehicle.image + '?t=' + Date.now());
    }

    uiText('dashLocal', links.dashboard_local || 'Unavailable');
    uiText('streamLocal', links.stream_local || 'Unavailable');
    uiText('permanentLiveUrl2', liveLink.url || 'Inactive');
    uiText('cameraConfigUrl2', s.camera_config_url || 'Unavailable');
    uiText('sftpBase', s.sftp_base_dir || '');
    uiText('sftpPerson', s.sftp_person_dir || '');
    uiText('sftpPersonVideo', s.sftp_person_video_dir || '');
    uiText('sftpGarbage', s.sftp_garbage_dir || '');
    uiText('sftpAudio', s.sftp_audio_dir || '');
    uiText('commandListener', system.command_listener ? 'Connected' : 'Disconnected');

    uiText('piTemp', system.pi_temperature_c || 'Unavailable');
    uiText('ramUsage', system.ram_percent != null ? (system.ram_percent + ' %') : 'Unavailable');
    uiText(
      'ramDetail',
      ((system.ram_used_mb != null ? system.ram_used_mb + ' MB' : 'Unavailable') + ' / ' +
      (system.ram_total_mb != null ? system.ram_total_mb + ' MB' : 'Unavailable'))
    );
    uiText('networkStatus', system.network_status || 'Unknown');
    uiText('networkIface', system.network_iface || 'Unknown');
    uiText('networkLinkSpeed', system.network_link_speed_mbps ?? 'Unknown');
    uiText('lastAudio', (s.last_audio && s.last_audio.file) ? s.last_audio.file : 'None');
    uiText('lastAudioStatus', (s.last_audio && s.last_audio.status) ? s.last_audio.status : 'None');

    updateControlsFromState(s);

    if (lastGarbage.image) {
      uiSrc('garbageImg', '/media/' + lastGarbage.image + '?t=' + Date.now());
    }
  } catch(e) {
    console.log('Dashboard refresh failed:', e);
  }
}
refreshState();
setInterval(refreshState, 2000);
</script>

<script>
let dashboardSnapshotTimer = null;

function dashboardUseSnapshot() {
  const img = document.getElementById('liveFeedImg');
  if (!img) return;

  const snapshotSrc = img.getAttribute('data-snapshot-src') || '/snapshot.jpg';
  img.setAttribute('data-mode', 'snapshot');
  img.src = snapshotSrc + '?t=' + Date.now();

  if (dashboardSnapshotTimer) {
    clearInterval(dashboardSnapshotTimer);
  }

  dashboardSnapshotTimer = setInterval(function () {
    const currentImg = document.getElementById('liveFeedImg');
    if (!currentImg || currentImg.getAttribute('data-mode') !== 'snapshot') return;
    currentImg.src = snapshotSrc + '?t=' + Date.now();
  }, 2000);
}

function dashboardStartLive() {
  const img = document.getElementById('liveFeedImg');
  if (!img) return;

  if (dashboardSnapshotTimer) {
    clearInterval(dashboardSnapshotTimer);
    dashboardSnapshotTimer = null;
  }

  const streamSrc = img.getAttribute('data-stream-src') || '/video_feed';
  img.setAttribute('data-mode', 'stream');
  img.src = streamSrc + '?t=' + Date.now();
}

document.addEventListener('DOMContentLoaded', function () {
  const img = document.getElementById('liveFeedImg');
  if (img && img.getAttribute('data-mode') === 'snapshot') {
    dashboardUseSnapshot();
  }
});
</script>

<script>
// Person + Vehicle only build: hide removed Garbage and Live/Upload Audio UI without changing old person/vehicle output layout.
document.addEventListener('DOMContentLoaded', function () {
  const removedTabNames = ['garbage', 'geofence'];
  document.querySelectorAll('.tab-btn').forEach(btn => {
    const onclick = String(btn.getAttribute('onclick') || '').toLowerCase();
    const text = String(btn.textContent || '').toLowerCase();
    if (removedTabNames.some(name => onclick.includes(`'${name}'`)) || text.includes('garbage')) {
      btn.remove();
    }
  });
  ['tab-garbage', 'tab-geofence'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  document.querySelectorAll('.control-card').forEach(card => {
    const text = String(card.textContent || '').toLowerCase();
    if (
      text.includes('garbage detection') ||
      text.includes('garbage mode') ||
      text.includes('manual detect') ||
      text.includes('reference image') ||
      text.includes('clear audio queue') ||
      text.includes('audio queue')
    ) {
      card.style.display = 'none';
    }
  });
});
</script>

</body>
</html>
HTML

echo "[15/17] Write app.py..."
cat > "$APP_DIR/app.py" <<'PY'
import atexit
import datetime as dt
import ipaddress
import json
import queue
import re
import shlex
import shutil
import signal
import socket
import subprocess
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2

try:
    cv2.setNumThreads(2)
    cv2.ocl.setUseOpenCL(False)
except Exception:
    pass

import numpy as np
import paho.mqtt.client as mqtt
import paramiko
import psutil
import requests


from flask import Flask, Response, jsonify, make_response, render_template, send_from_directory, request, stream_with_context
from waitress import serve

APP_DIR = Path("/opt/gcam")
DATA_DIR = APP_DIR / "data"
MODEL_DIR = APP_DIR / "models"
ASSET_DIR = APP_DIR / "assets"
FILES_DIR = APP_DIR / "files"
GARBAGE_DIR = FILES_DIR / "garbage"
AUDIO_DIR = FILES_DIR / "audio"
DEFAULT_AUDIO_DIR = FILES_DIR / "default_audio"
VIDEO_DIR = FILES_DIR / "video"
RECORDING_DIR = FILES_DIR / "recordings"
LOG_DIR = APP_DIR / "logs"
TMP_DIR = APP_DIR / "tmp"
TEMPLATE_DIR = APP_DIR / "templates"

CONFIG_FILE = DATA_DIR / "config.json"
STATE_FILE = DATA_DIR / "state.json"
SFTP_RETRY_QUEUE_FILE = DATA_DIR / "sftp_retry_queue.json"
GARBAGE_REF_FILE = DATA_DIR / "garbage_reference.jpg"
GARBAGE_REF_UPLOAD_MAX_BYTES = 12 * 1024 * 1024

HOST = "0.0.0.0"
PORT = 8080

# ─────────────────────────────────────────────────────────────
# Pi 5 stream split resolution pipeline
# ─────────────────────────────────────────────────────────────
# IMPORTANT:
# AI detection and live view use the camera SUB stream.
# SFTP image/video uploads use the camera MAIN stream.
#
# PROCESS_FRAME_WIDTH stays 640 to preserve old detection behaviour,
# thresholds, MQTT output, SFTP output, event logic and dashboard values.
#
# LIVE_FRAME_WIDTH is only for sub-stream dashboard live view.
# EVENT_FRAME_WIDTH is only for main-stream video upload buffer.
#
# Recommended safe values for Raspberry Pi 5 4GB:
#   PROCESS_FRAME_WIDTH = 640   -> old stable detection behaviour
#   LIVE_FRAME_WIDTH    = 1280  -> better dashboard live view
#   EVENT_FRAME_WIDTH   = 1280  -> better event video buffer
#
# After stable testing, you may try:
#   LIVE_FRAME_WIDTH  = 1920
#   EVENT_FRAME_WIDTH = 1280
#
# Do NOT increase PROCESS_FRAME_WIDTH first if you want old output unchanged.

PROCESS_FRAME_WIDTH = 640

# Local dashboard live.
LIVE_FRAME_WIDTH = 960

# High-quality MAIN-stream event video buffer.
# 1920 keeps SFTP video high quality without processing full 2880px on Pi 5 1GB.
EVENT_FRAME_WIDTH = 1280

# Public Cloudflare live quality.
# Keep this conservative for Cloudflare + Raspberry Pi 5 1GB.
# The public dashboard uses snapshot mode by default to avoid browser buffering.
CLOUDFLARE_LIVE_FRAME_WIDTH = 640

# JPEG quality.
# Lower public JPEG quality reduces Cloudflare buffering and Pi CPU/network load.
MJPEG_QUALITY = 60
CLOUDFLARE_MJPEG_QUALITY = 45

# Stream FPS.
LIVE_STREAM_TARGET_FPS = 10.0
CLOUDFLARE_STREAM_TARGET_FPS = 3.0

# Reader optimization.
LIVE_FRAME_UPDATE_FPS = 10.0

# Compatibility alias.
FRAME_WIDTH = PROCESS_FRAME_WIDTH

# Smooth event-buffer settings.
ROLLING_BUFFER_TARGET_FPS = 6.0
PERSON_FULL_SCAN_INTERVAL_SEC = 1.25

ROUTER_REBOOT_GPIO = 17
ROUTER_REBOOT_GPIOCHIP = "gpiochip0"
ROUTER_REBOOT_ACTIVE_VALUE = 1
ROUTER_REBOOT_INACTIVE_VALUE = 0
ROUTER_REBOOT_PULSE_SEC = 1
ROUTER_REBOOT_STAGE_GAP_SEC = 5
ROUTER_REBOOT_COMMAND = "trigger router reboot"

# SFTP retry queue for temporary network failures.
SFTP_RETRY_INTERVAL_SEC = 30
SFTP_RETRY_MAX_AGE_SEC = 7 * 24 * 60 * 60
SFTP_RETRY_MAX_ATTEMPTS = 9999

# ── Person detection tuning ──────────────────────────────────────────
# Pi 1GB balanced working settings.
# IMPORTANT: Keep PERSON_DETECT_EVERY_N_FRAMES = 1.
# Changing it to 2 can break confirmation/detection in this script flow.
PERSON_CONF = 0.60
PERSON_COOLDOWN_SEC = 4

# Warning repeat cooldown.
# Old value 3 can overlap/interrupt audio.
# 8 means warning can repeat every 8 seconds while person is still present.
AUDIO_COOLDOWN_SEC = 8

PERSON_CONFIRMATION_FRAMES = 1

# Editable person stay time before event image/video and warning audio trigger.
# Same behaviour as vehicle static stay time: person must remain inside person polygon.
DEFAULT_PERSON_STATIC_STAY_SEC = 5.0
PERSON_STATIC_STAY_MIN_SEC = 1.0
PERSON_STATIC_STAY_MAX_SEC = 120.0

EVENT_PRE_RECORD_SEC = 6
EVENT_POST_RECORD_SEC = 8
EVENT_CLIP_DURATION_SEC = EVENT_PRE_RECORD_SEC + EVENT_POST_RECORD_SEC

# Lag-fix event buffer settings.
# Output format stays same. Only internal buffer pressure is reduced.
EVENT_ROLLING_BUFFER_SEC = 18
EVENT_BUFFER_JPEG_QUALITY = 68
EVENT_MIN_FPS = 4.0
EVENT_MAX_FPS = 6.0
EVENT_DEFAULT_FPS = 5.0
EVENT_TEMP_VIDEO_EXTENSION = "avi"

# Uploaded still images stay at MAIN-stream full resolution.
# Video is compressed separately by EVENT_FRAME_WIDTH + H.264 CRF.
FULL_RES_IMAGE_JPEG_QUALITY = 95

# Never upload SUB/D1 frames as event still images.
# If the MAIN stream is temporarily stale, wait for it and then try one
# direct MAIN snapshot before cancelling the still-image upload.
EVENT_IMAGE_REQUIRE_MAIN_STREAM = True
EVENT_IMAGE_MAIN_WAIT_SEC = 4.0
EVENT_IMAGE_MAIN_MAX_AGE_SEC = 5.0
EVENT_IMAGE_DIRECT_CAPTURE_TIMEOUT_SEC = 3.0
EVENT_IMAGE_DIRECT_CAPTURE_WARMUP_FRAMES = 4

EVENT_VIDEO_H264_CRF = 30
EVENT_VIDEO_H264_PRESET = "veryfast"

PERSON_VIDEO_DURATION_SEC = EVENT_CLIP_DURATION_SEC
PERSON_VIDEO_SUFFIX = "Straps"
PERSON_VIDEO_EXTENSION = "mp4"
PERSON_DETECT_EVERY_N_FRAMES = 1
PERSON_UPSCALE_FACTOR = 1.12
PERSON_NMS_THRESHOLD = 0.24
PERSON_LOST_TIMEOUT_SEC = 1.2
PERSON_MIN_AREA = 1800
PERSON_TILE_STEP_RATIO = 0.34
PERSON_TILE_MIN_CONF = 0.58
PERSON_HOG_ENABLE = False
PERSON_ALLOWED_ROI = (0.01, 0.03, 0.99, 0.995)
DEFAULT_PERSON_ROI = (0.01, 0.03, 0.99, 0.995)

PERSON_MIN_BOX_HEIGHT_RATIO = 0.11
PERSON_MIN_BOX_WIDTH_RATIO = 0.025
PERSON_MIN_ASPECT_RATIO = 1.20
PERSON_MAX_ASPECT_RATIO = 4.50
PERSON_MAX_BOX_WIDTH_RATIO = 0.38

# Extra anti-pole / anti-stone / anti-tree filters.
PERSON_POLE_MAX_WIDTH_RATIO = 0.075
PERSON_POLE_ASPECT_RATIO = 2.85
PERSON_MIN_EDGE_DENSITY = 0.018
PERSON_MAX_EDGE_DENSITY = 0.24
PERSON_MIN_TEXTURE_VARIANCE = 38.0
PERSON_EXCLUSION_ZONES: List[Tuple[float, float, float, float]] = []

# Extra person false-positive suppression.
# MobileNetSSD can occasionally label a bright whiteboard/window panel as a
# high-confidence person. These thresholds reject bright, low-saturation,
# rectangular patches whose top band has no human head/hair/skin detail.
PERSON_FALSE_POSITIVE_ANIMAL_CLASSES = {"bird", "cat", "cow", "dog", "horse", "sheep"}
PERSON_ANIMAL_SUPPRESSION_CONF = 0.35
PERSON_ANIMAL_SUPPRESSION_IOU = 0.10
PERSON_ANIMAL_SUPPRESSION_PERSON_OVERLAP = 0.18
PERSON_WHITEBOARD_MIN_CONF = 0.85
PERSON_WHITEBOARD_FULL_BRIGHT_LOW_SAT_RATIO = 0.56
PERSON_WHITEBOARD_TOP_BRIGHT_LOW_SAT_RATIO = 0.86
PERSON_WHITEBOARD_TOP_DARK_RATIO_MAX = 0.035
PERSON_WHITEBOARD_FULL_DARK_RATIO_MAX = 0.18
PERSON_WHITEBOARD_TOP_SAT_MEAN_MAX = 22.0

# Vehicle detection using MobileNetSSD vehicle classes.
# Static mode detects parked/stopped vehicles.
# Moving mode is still available from dashboard/API/MQTT.
# Vehicle geofence uses bbox-vs-polygon overlap, not only tyre/bottom point.
# "bicycle" is included because this model often classifies CCTV motorbikes
# and small side-view two-wheelers as bicycle.
VEHICLE_CLASSES = {"car", "bus", "motorbike", "bicycle"}
VEHICLE_CLASS_LABELS = {
    "car": "Car",
    "bus": "Bus",
    "motorbike": "Motorbike",
    "bicycle": "Two-Wheeler",
}

# Vehicle detection tuning.
# Lowered for high-angle CCTV and two-wheelers that often score around 0.45–0.65.
VEHICLE_CONF = 0.50
VEHICLE_NMS_THRESHOLD = 0.30

# Run every processed frame so motorbikes/two-wheelers are not missed.
VEHICLE_DETECT_EVERY_N_FRAMES = 1

# High-mounted camera needs smaller boxes accepted.
VEHICLE_MIN_AREA = 900
VEHICLE_MIN_BOX_HEIGHT_RATIO = 0.030
VEHICLE_MIN_BOX_WIDTH_RATIO = 0.030
VEHICLE_MAX_BOX_WIDTH_RATIO = 0.90
VEHICLE_MAX_BOX_HEIGHT_RATIO = 0.90

# Legacy cooldown kept for compatibility; the geofence state machine below
# controls the first/second vehicle events for each marked-area visit.
VEHICLE_COOLDOWN_SEC = 20

# Fixed delay after Event 1 before Event 2 is fired while vehicle still stays inside.
VEHICLE_SECOND_EVENT_DELAY_SEC = 13.0

# Kept for compatibility, but event confirmation is now time-based.
VEHICLE_CONFIRMATION_FRAMES = 1

# Vehicle must disappear/outside marking for this time before next vehicle can trigger.
VEHICLE_LOST_TIMEOUT_SEC = 2.0

# Default static stay time. Dashboard/API can edit this.
DEFAULT_VEHICLE_STATIC_STAY_SEC = 5.0
VEHICLE_STATIC_STAY_MIN_SEC = 1.0
VEHICLE_STATIC_STAY_MAX_SEC = 120.0

# Backward compatibility name.
VEHICLE_STABLE_INSIDE_SEC = DEFAULT_VEHICLE_STATIC_STAY_SEC

# Allows short vehicle detection flicker without resetting the stay timer.
# CCTV/RTSP streams may miss a few frames even when the vehicle is still parked.
VEHICLE_STABLE_GRACE_SEC = 2.50

# Minimum good detections during the static stay window.
# Keep this low because the time gate already confirms the vehicle is stable.
VEHICLE_MIN_STABLE_HITS = 1

# Event capture needs this confidence or higher.
VEHICLE_EVENT_MIN_CONF = 0.50

# Moving detection motion tuning.
# Previous moving mode was too strict for CCTV + vehicle body movement.
VEHICLE_MOTION_THRESHOLD = 14
VEHICLE_MOTION_MIN_PIXELS = 35
VEHICLE_MOTION_MIN_RATIO = 0.004
VEHICLE_MOTION_DILATE_ITER = 3

# Moving mode also uses bbox displacement, not only frame-diff mask.
VEHICLE_MOVING_MIN_CENTER_SHIFT_PX = 5.0
VEHICLE_MOVING_TRACK_TTL_SEC = 2.0
VEHICLE_MOVING_RECENT_SEC = 1.2

vehicle_motion_track_lock = threading.Lock()
vehicle_motion_tracks: List[Dict[str, Any]] = []

VEHICLE_VIDEO_DURATION_SEC = EVENT_CLIP_DURATION_SEC
VEHICLE_VIDEO_EXTENSION = "mp4"
VEHICLE_VIDEO_SUFFIX = "Vehicle"

DEFAULT_GARBAGE_DETECTION_MODE = "ai"
GARBAGE_DETECTION_MODES = {"ai", "normal"}

DEFAULT_VEHICLE_DETECTION_MODE = "static"
VEHICLE_DETECTION_MODES = {"static", "moving"}

DEFAULT_VEHICLE_ROI = (0.00, 0.08, 1.00, 1.00)
DEFAULT_VEHICLE_POLYGON = (
    (DEFAULT_VEHICLE_ROI[0], DEFAULT_VEHICLE_ROI[1]),
    (DEFAULT_VEHICLE_ROI[2], DEFAULT_VEHICLE_ROI[1]),
    (DEFAULT_VEHICLE_ROI[2], DEFAULT_VEHICLE_ROI[3]),
    (DEFAULT_VEHICLE_ROI[0], DEFAULT_VEHICLE_ROI[3]),
)

# Default vehicle overlap threshold. Config/dashboard value overrides this.
# 0.35 works better for partial CCTV motorbike/two-wheeler views.
VEHICLE_GEOFENCE_MIN_OVERLAP_RATIO = 0.35

VEHICLE_EXCLUSION_ZONES: List[Tuple[float, float, float, float]] = []
VEHICLE_MOTION_THRESHOLD = 24
VEHICLE_MOTION_MIN_PIXELS = 90
VEHICLE_MOTION_MIN_RATIO = 0.020
VEHICLE_MOTION_DILATE_ITER = 2

# ── Garbage object detection constants ───────────────────────────────
GARBAGE_EXCLUSION_ZONES: List[Tuple[float, float, float, float]] = []

GARBAGE_CAPTURE_SAMPLES = 3
GARBAGE_SAMPLE_GAP_SEC = 1.2
DEFAULT_GARBAGE_INTERVAL_SEC = 3600
GARBAGE_INTERVAL_SEC = DEFAULT_GARBAGE_INTERVAL_SEC
GARBAGE_START_DELAY_SEC = 12
REFERENCE_UPDATE_STABLE_COUNT = 5

COUNT_LOW_MIN = 1
COUNT_MEDIUM_MIN = 3
COUNT_HIGH_MIN = 6

# Garbage AI settings.
# Keep 320 for old output compatibility.
# Increasing this to 416 can detect smaller objects, but may change old results.
GARBAGE_OBJ_INPUT_SIZE = 320
GARBAGE_OBJ_CONF = 0.28
GARBAGE_OBJ_NMS = 0.45

GARBAGE_MIN_BOX_AREA_PX = 900
GARBAGE_MIN_BOX_AREA_RATIO = 0.0015
GARBAGE_MIN_BOX_WIDTH_RATIO = 0.030
GARBAGE_MIN_BOX_HEIGHT_RATIO = 0.030
GARBAGE_MAX_BOX_AREA_RATIO = 0.50

# Reference-difference garbage boxes.
# Keep old large-box style, but allow smaller scattered garbage to enter detection.
GARBAGE_CHANGE_MIN_AREA_PX = 260
GARBAGE_CHANGE_MIN_AREA_RATIO = 0.00045
GARBAGE_CHANGE_MIN_WIDTH_RATIO = 0.012
GARBAGE_CHANGE_MIN_HEIGHT_RATIO = 0.012
GARBAGE_CHANGE_MERGE_GAP_RATIO = 0.030

GARBAGE_MIN_TEXTURE_VARIANCE = 18.0
GARBAGE_MIN_SATURATION_MEAN = 8.0

# Uploaded AI-cleaned reference validation/normalization.
GARBAGE_REFERENCE_ASPECT_TOLERANCE = 0.12

# Extra static/corner garbage fallback.
# This is only an add-on. It does not replace old large reference-diff boxes.
GARBAGE_STATIC_TILE_SIZE_RATIO = 0.070
GARBAGE_STATIC_TILE_STEP_RATIO = 0.035
GARBAGE_STATIC_MIN_OBJECT_RATIO = 0.045
GARBAGE_STATIC_MIN_EDGE_RATIO = 0.016
GARBAGE_STATIC_MAX_GREEN_RATIO = 0.58
GARBAGE_STATIC_MAX_SOIL_RATIO = 0.86
GARBAGE_STATIC_MAX_BOXES = 35

GARBAGE_TARGET_LABELS = {
    "bottle",
    "cup",
    "bowl",
    "book",
    "handbag",
    "backpack",
    "teddy bear"
}

GARBAGE_LABEL_ALIAS = {
    "bottle": "Bottle",
    "cup": "Cup",
    "bowl": "Container",
    "book": "Notebook",
    "handbag": "Bag",
    "backpack": "Bag",
    "teddy bear": "Cloth"
}

RETENTION_SECONDS = 86400
CLEANUP_INTERVAL_SEC = 3600

# Dynamic polygon geofence support.
# Old rectangle ROI is still supported for backward compatibility.
DEFAULT_GARBAGE_ROI = (0.08, 0.28, 0.92, 0.90)
DEFAULT_GARBAGE_POLYGON = (
    (0.08, 0.28),
    (0.92, 0.28),
    (0.92, 0.90),
    (0.08, 0.90),
)

DEFAULT_PERSON_POLYGON = (
    (DEFAULT_PERSON_ROI[0], DEFAULT_PERSON_ROI[1]),
    (DEFAULT_PERSON_ROI[2], DEFAULT_PERSON_ROI[1]),
    (DEFAULT_PERSON_ROI[2], DEFAULT_PERSON_ROI[3]),
    (DEFAULT_PERSON_ROI[0], DEFAULT_PERSON_ROI[3]),
)

POLYGON_MIN_POINTS = 3
POLYGON_MAX_POINTS = 20
POLYGON_MIN_AREA_RATIO = 0.0001


def ratio_box_to_polygon(box: Tuple[float, float, float, float]) -> List[Tuple[float, float]]:
    x1, y1, x2, y2 = box
    return [
        (float(x1), float(y1)),
        (float(x2), float(y1)),
        (float(x2), float(y2)),
        (float(x1), float(y2)),
    ]


def ratio_polygon_to_box(points: List[Tuple[float, float]]) -> Tuple[float, float, float, float]:
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (
        max(0.0, min(xs)),
        max(0.0, min(ys)),
        min(1.0, max(xs)),
        min(1.0, max(ys)),
    )


def ratio_polygon_area(points: List[Tuple[float, float]]) -> float:
    if len(points) < 3:
        return 0.0

    area = 0.0
    total = len(points)

    for idx in range(total):
        x1, y1 = points[idx]
        x2, y2 = points[(idx + 1) % total]
        area += (x1 * y2) - (x2 * y1)

    return abs(area) / 2.0


def sanitize_ratio_polygon(value: Any) -> Optional[List[Tuple[float, float]]]:
    try:
        if not isinstance(value, list):
            return None

        if len(value) < POLYGON_MIN_POINTS:
            return None

        if len(value) > POLYGON_MAX_POINTS:
            return None

        points: List[Tuple[float, float]] = []

        for point in value:
            if not isinstance(point, (list, tuple)) or len(point) != 2:
                return None

            x = float(point[0])
            y = float(point[1])

            if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
                return None

            points.append((x, y))

        if ratio_polygon_area(points) < POLYGON_MIN_AREA_RATIO:
            return None

        return points

    except Exception:
        return None


def round_ratio_polygon(points: List[Tuple[float, float]]) -> List[List[float]]:
    return [[round(float(x), 4), round(float(y), 4)] for x, y in points]


def _valid_ratio_box(value: Any) -> Optional[Tuple[float, float, float, float]]:
    try:
        if not value or len(value) != 4:
            return None

        x1, y1, x2, y2 = [float(v) for v in value]

        if 0.0 <= x1 < x2 <= 1.0 and 0.0 <= y1 < y2 <= 1.0:
            return (x1, y1, x2, y2)

    except Exception:
        pass

    return None


def load_ratio_polygon_from_config(
    polygon_key: str,
    roi_key: str,
    default_polygon: Tuple[Tuple[float, float], ...]
) -> List[Tuple[float, float]]:
    try:
        cfg = load_config()

        polygon = sanitize_ratio_polygon(cfg.get(polygon_key))
        if polygon is not None:
            return polygon

        old_box = _valid_ratio_box(cfg.get(roi_key))
        if old_box is not None:
            return ratio_box_to_polygon(old_box)

    except Exception:
        pass

    return [(float(x), float(y)) for x, y in default_polygon]


def load_garbage_polygon() -> List[Tuple[float, float]]:
    return load_ratio_polygon_from_config(
        "garbage_polygon",
        "garbage_roi",
        DEFAULT_GARBAGE_POLYGON
    )


def load_person_polygon() -> List[Tuple[float, float]]:
    return load_ratio_polygon_from_config(
        "person_polygon",
        "person_roi",
        DEFAULT_PERSON_POLYGON
    )


def load_vehicle_polygon() -> List[Tuple[float, float]]:
    return load_ratio_polygon_from_config(
        "vehicle_polygon",
        "vehicle_roi",
        DEFAULT_VEHICLE_POLYGON
    )


def ratio_polygon_to_pixels(
    frame: np.ndarray,
    points: List[Tuple[float, float]]
) -> List[Tuple[int, int]]:
    h, w = frame.shape[:2]

    pixel_points: List[Tuple[int, int]] = []

    for x_ratio, y_ratio in points:
        x = int(round(float(x_ratio) * float(max(w - 1, 1))))
        y = int(round(float(y_ratio) * float(max(h - 1, 1))))

        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))

        pixel_points.append((x, y))

    return pixel_points


def polygon_pixels_to_box(
    points: List[Tuple[int, int]],
    frame: np.ndarray
) -> Tuple[int, int, int, int]:
    h, w = frame.shape[:2]

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]

    x1 = max(0, min(xs))
    y1 = max(0, min(ys))
    x2 = min(w, max(xs) + 1)
    y2 = min(h, max(ys) + 1)

    if x2 <= x1:
        x2 = min(w, x1 + 1)

    if y2 <= y1:
        y2 = min(h, y1 + 1)

    return (x1, y1, x2, y2)


def make_polygon_masked_crop(
    frame: np.ndarray,
    points_px: List[Tuple[int, int]]
) -> Tuple[np.ndarray, Tuple[int, int, int, int]]:
    roi_box = polygon_pixels_to_box(points_px, frame)
    x1, y1, x2, y2 = roi_box

    crop = frame[y1:y2, x1:x2].copy()

    if len(points_px) < 3:
        return crop, roi_box

    mask = np.zeros(crop.shape[:2], dtype=np.uint8)
    relative_points = np.array(
        [[x - x1, y - y1] for x, y in points_px],
        dtype=np.int32
    )

    cv2.fillPoly(mask, [relative_points], 255)

    masked_crop = cv2.bitwise_and(crop, crop, mask=mask)
    return masked_crop, roi_box


def get_garbage_polygon_pixels(frame: np.ndarray) -> List[Tuple[int, int]]:
    return ratio_polygon_to_pixels(frame, load_garbage_polygon())


def get_person_polygon_pixels(frame: np.ndarray) -> List[Tuple[int, int]]:
    return ratio_polygon_to_pixels(frame, load_person_polygon())


def get_garbage_roi(frame: np.ndarray) -> Tuple[np.ndarray, Tuple[int, int, int, int]]:
    points_px = get_garbage_polygon_pixels(frame)
    return make_polygon_masked_crop(frame, points_px)


def load_garbage_roi() -> Tuple[float, float, float, float]:
    return ratio_polygon_to_box(load_garbage_polygon())


def load_person_roi() -> Tuple[float, float, float, float]:
    return ratio_polygon_to_box(load_person_polygon())


def get_person_roi_pixels(frame: np.ndarray) -> Tuple[int, int, int, int]:
    points_px = get_person_polygon_pixels(frame)
    return polygon_pixels_to_box(points_px, frame)


def point_inside_person_polygon(frame: np.ndarray, x: int, y: int) -> bool:
    points_px = get_person_polygon_pixels(frame)

    if len(points_px) < 3:
        return False

    polygon_np = np.array(points_px, dtype=np.int32)
    return cv2.pointPolygonTest(polygon_np, (float(x), float(y)), False) >= 0


def draw_polygon_outline(
    image: np.ndarray,
    points_px: List[Tuple[int, int]],
    label: str,
    color: Tuple[int, int, int],
    alpha: float = 0.0
) -> None:
    if len(points_px) < 3:
        return

    polygon_np = np.array(points_px, dtype=np.int32)

    # Transparent inside ROI:
    # Do not fill polygon. Only draw border and label.
    cv2.polylines(image, [polygon_np], True, color, 2, cv2.LINE_AA)

    x_label = max(8, min(p[0] for p in points_px) + 6)
    y_label = max(22, min(p[1] for p in points_px) - 8)

    cv2.putText(
        image,
        label,
        (x_label, y_label),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        color,
        2,
        cv2.LINE_AA
    )


def load_ratio_boxes_from_config(
    key: str,
    fallback: Optional[List[Tuple[float, float, float, float]]] = None
) -> List[Tuple[float, float, float, float]]:
    boxes: List[Tuple[float, float, float, float]] = []

    try:
        cfg = load_config()
        raw_boxes = cfg.get(key, [])
        if isinstance(raw_boxes, list):
            for item in raw_boxes:
                box = _valid_ratio_box(item)
                if box is not None:
                    boxes.append(box)
    except Exception:
        pass

    if not boxes and fallback:
        boxes.extend(fallback)

    return boxes


def get_vehicle_polygon_pixels(frame: np.ndarray) -> List[Tuple[int, int]]:
    return ratio_polygon_to_pixels(frame, load_vehicle_polygon())


def load_vehicle_roi() -> Tuple[float, float, float, float]:
    return ratio_polygon_to_box(load_vehicle_polygon())


def get_vehicle_roi_pixels(frame: np.ndarray) -> Tuple[int, int, int, int]:
    points_px = get_vehicle_polygon_pixels(frame)
    return polygon_pixels_to_box(points_px, frame)


def vehicle_box_geofence_overlap_ratio(
    frame: np.ndarray,
    box: Tuple[int, int, int, int]
) -> float:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box

    x1 = max(0, min(w - 1, int(x1)))
    y1 = max(0, min(h - 1, int(y1)))
    x2 = max(0, min(w, int(x2)))
    y2 = max(0, min(h, int(y2)))

    if x2 <= x1 or y2 <= y1:
        return 0.0

    polygon_points = get_vehicle_polygon_pixels(frame)
    if len(polygon_points) < 3:
        return 0.0

    crop_h = y2 - y1
    crop_w = x2 - x1
    mask = np.zeros((crop_h, crop_w), dtype=np.uint8)

    relative_points = np.array(
        [[px - x1, py - y1] for px, py in polygon_points],
        dtype=np.int32
    )

    cv2.fillPoly(mask, [relative_points], 255)

    inside_pixels = int(np.count_nonzero(mask))
    total_pixels = int(max(crop_h * crop_w, 1))
    return float(inside_pixels) / float(total_pixels)


def vehicle_box_inside_geofence(
    frame: np.ndarray,
    box: Tuple[int, int, int, int]
) -> Tuple[bool, float]:
    overlap_ratio = vehicle_box_geofence_overlap_ratio(frame, box)
    threshold = load_vehicle_geofence_overlap_threshold()
    return overlap_ratio >= threshold, overlap_ratio


def point_inside_box(px: int, py: int, box: Tuple[int, int, int, int]) -> bool:
    x1, y1, x2, y2 = box
    return x1 <= px <= x2 and y1 <= py <= y2


def ratio_box_to_pixels(
    ratio_box: Tuple[float, float, float, float],
    frame: np.ndarray
) -> Tuple[int, int, int, int]:
    h, w = frame.shape[:2]
    rx1, ry1, rx2, ry2 = ratio_box
    return (
        int(w * rx1),
        int(h * ry1),
        int(w * rx2),
        int(h * ry2),
    )


def point_inside_any_ratio_box(
    px: int,
    py: int,
    frame: np.ndarray,
    ratio_boxes: List[Tuple[float, float, float, float]]
) -> bool:
    for ratio_box in ratio_boxes:
        if point_inside_box(px, py, ratio_box_to_pixels(ratio_box, frame)):
            return True
    return False


LIVE_LINK_DURATION_SEC = 180
LIVE_LINK_COMMAND = "live stream"
MANUAL_GARBAGE_COMMAND = "garbage detect"
GARBAGE_SAMPLE_CAPTURE_COMMAND = "garbage sample capture"
GARBAGE_AI_MODE_COMMAND = "garbage ai mode"
GARBAGE_NORMAL_MODE_COMMAND = "garbage normal mode"

AUDIO_PLAY_COMMAND = "audio file play"
IMPORT_DEFAULT_AUDIO_COMMAND = "import default audio"
ERASE_DEFAULT_AUDIO_IN_PI_COMMAND = "erase default audio in pi"
PLAY_DEFAULT_AUDIO_COMMAND_PREFIX = "play default audio - "
DATA_STATUS_COMMAND = "data status"
STORAGE_STATUS_COMMAND = "storage status"
PLAYBACK_URL_COMMAND = "playback"
SOFTWARE_VERSION_COMMAND = "software version"
DEVICE_RESTART_COMMAND = "device restart"
CLOUDFLARE_RESTART_COMMAND = "cloudflare restart"
CLOUDFLARE_STATUS_COMMAND = "cloudflare status"
WARNING_AUDIO_DISABLE_COMMAND = "warning audio disable"
WARNING_AUDIO_ENABLE_COMMAND = "warning audio enable"
PERSON_WARNING_AUDIO_DISABLE_COMMAND = "person warning audio disable"
PERSON_WARNING_AUDIO_ENABLE_COMMAND = "person warning audio enable"
VEHICLE_WARNING_AUDIO_DISABLE_COMMAND = "vehicle warning audio disable"
VEHICLE_WARNING_AUDIO_ENABLE_COMMAND = "vehicle warning audio enable"
WARNING_AUDIO_SCHEDULE_COMMAND = "scheduled warning audio"
WARNING_AUDIO_SCHEDULE_DISABLE_COMMAND = "scheduled warning disabled"
QUEUE_CLEAR_COMMAND = "queue clear"

PERSON_DETECTION_ENABLE_COMMAND = "person detection enable"
PERSON_DETECTION_DISABLE_COMMAND = "person detection disable"
VEHICLE_DETECTION_ENABLE_COMMAND = "vehicle detection enable"
VEHICLE_DETECTION_DISABLE_COMMAND = "vehicle detection disable"
GARBAGE_DETECTION_ENABLE_COMMAND = "garbage detection enable"
GARBAGE_DETECTION_DISABLE_COMMAND = "garbage detection disable"

PERSON_VIDEO_RECORDING_ENABLE_COMMAND = "person video recording enable"
PERSON_VIDEO_RECORDING_DISABLE_COMMAND = "person video recording disable"
VEHICLE_VIDEO_RECORDING_ENABLE_COMMAND = "vehicle video recording enable"
VEHICLE_VIDEO_RECORDING_DISABLE_COMMAND = "vehicle video recording disable"


GARBAGE_MODE_COMMANDS = {
    GARBAGE_AI_MODE_COMMAND,
    GARBAGE_NORMAL_MODE_COMMAND,
}

FEATURE_TOGGLE_COMMANDS = {
    PERSON_DETECTION_ENABLE_COMMAND,
    PERSON_DETECTION_DISABLE_COMMAND,
    VEHICLE_DETECTION_ENABLE_COMMAND,
    VEHICLE_DETECTION_DISABLE_COMMAND,
    GARBAGE_DETECTION_ENABLE_COMMAND,
    GARBAGE_DETECTION_DISABLE_COMMAND,
    PERSON_VIDEO_RECORDING_ENABLE_COMMAND,
    PERSON_VIDEO_RECORDING_DISABLE_COMMAND,
    VEHICLE_VIDEO_RECORDING_ENABLE_COMMAND,
    VEHICLE_VIDEO_RECORDING_DISABLE_COMMAND,

}

POWER_SAVING_ENABLE_COMMAND = "power saving enable"
POWER_SAVING_DISABLE_COMMAND = "power saving disable"
POWER_SAVING_STATUS_COMMAND = "power saving status"
POWER_SAVING_SCHEDULE_COMMAND = "scheduled power saving"
POWER_SAVING_SCHEDULE_DISABLE_COMMAND = "scheduled power saving disabled"

POWER_SAVING_ALLOWED_WHEN_ACTIVE = {
    DATA_STATUS_COMMAND,
    STORAGE_STATUS_COMMAND,
    PLAYBACK_URL_COMMAND,
    POWER_SAVING_ENABLE_COMMAND,
    POWER_SAVING_DISABLE_COMMAND,
    POWER_SAVING_STATUS_COMMAND,
    POWER_SAVING_SCHEDULE_COMMAND,
    POWER_SAVING_SCHEDULE_DISABLE_COMMAND,
    CLOUDFLARE_RESTART_COMMAND,
    CLOUDFLARE_STATUS_COMMAND,
    *FEATURE_TOGGLE_COMMANDS,
    *GARBAGE_MODE_COMMANDS,
}

POWER_SAVING_SCHEDULE_CHECK_SEC = 15

CLOUDFLARED_BIN = "/usr/bin/cloudflared"

STATE_FLUSH_INTERVAL_SEC = 10
HEARTBEAT_INTERVAL_SEC = 20

PUBLIC_IP_CACHE: Optional[str] = None
LAST_PUBLIC_IP_CHECK_TS = 0.0

GEO_LOCATION_CACHE: Optional[str] = None
LAST_GEO_CHECK_TS = 0.0

last_net_rx: Optional[int] = None
last_net_tx: Optional[int] = None
last_net_ts: Optional[float] = None

NETWORK_AUDIO_CHECK_INTERVAL_SEC = 3
NETWORK_AUDIO_TCP_TIMEOUT_SEC = 3
NETWORK_AUDIO_DEFAULT_RESTORE_VOLUME_PERCENT = 70

# Real internet test targets.
# Do not depend only on router/default route.
# If router is alive but WAN internet is down, these checks will fail and audio will mute.
NETWORK_AUDIO_INTERNET_TEST_TARGETS = (
    ("1.1.1.1", 443),   # Cloudflare HTTPS
    ("8.8.8.8", 53),    # Google DNS TCP
    ("9.9.9.9", 53),    # Quad9 DNS TCP
)

network_audio_last_online: Optional[bool] = None
network_audio_restore_volume: Optional[int] = None

LIVE_TALK_DIR = TMP_DIR / "live_talk"

LIVE_TALK_CHUNK_SECONDS = 0.75
LIVE_TALK_MAX_QUEUE_SIZE = 80
LIVE_TALK_MAX_CHUNK_BYTES = 2 * 1024 * 1024
LIVE_TALK_STOP_TIMEOUT_SEC = 4
LIVE_TALK_GRACEFUL_DRAIN_TIMEOUT_SEC = 8
LIVE_TALK_GRACEFUL_IDLE_DELAY_SEC = 2.0
LIVE_TALK_VOLUME_FILTER = "volume=3.0,alimiter=limit=0.95"

live_talk_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=LIVE_TALK_MAX_QUEUE_SIZE)
live_talk_active = False
live_talk_stopping = False
live_talk_lock = threading.Lock()
live_talk_ffmpeg_process: Optional[subprocess.Popen] = None
live_talk_aplay_process: Optional[subprocess.Popen] = None

MOBILENET_CLASSES = [
    "background", "aeroplane", "bicycle", "bird", "boat",
    "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
    "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
    "sofa", "train", "tvmonitor"
]

GARBAGE_REFERENCE_ITEMS = [
    "Dust", "Bags", "Covers", "Carry bags", "Box",
    "Leaf", "Slippers", "Shoes", "Paper", "Notebooks",
    "Cloths", "Dress"
]

app = Flask(__name__, template_folder=str(TEMPLATE_DIR))


@app.after_request
def add_dashboard_no_cache_headers(response):
    """Prevent browser/Cloudflare from serving stale dashboard HTML/JS.

    This keeps dashboard control layout changes, such as separate person and
    vehicle warning-audio cards, visible immediately after service restart.
    """
    try:
        path = request.path or ""
        if (
            path == "/"
            or path.endswith("_geofencing")
            or path.startswith("/api/")
            or path.startswith("/snapshot")
        ):
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
    except Exception:
        pass
    return response


state_lock = threading.RLock()
sftp_retry_lock = threading.RLock()
frame_lock = threading.Lock()
audio_lock = threading.Lock()
person_dnn_lock = threading.Lock()
garbage_detection_lock = threading.Lock()
stop_event = threading.Event()

# latest_frame:
#   Detection/process frame. Kept at PROCESS_FRAME_WIDTH for old behaviour.
#
# latest_live_frame:
#   Dashboard/live stream frame. Can be higher resolution on Pi 5 4GB.
#
# latest_frame_ts:
#   Shared timestamp for the current camera frame.
latest_frame: Optional[np.ndarray] = None
latest_live_frame: Optional[np.ndarray] = None
latest_frame_ts: float = 0.0

# Latest high-quality MAIN-stream frame used for SFTP still-image uploads.
# AI detection never uses this frame, so CPU-heavy detection remains on sub stream.
latest_main_frame: Optional[np.ndarray] = None
latest_main_frame_ts: float = 0.0

rolling_video_lock = threading.Lock()
rolling_video_buffer = deque()

person_net = None
hog_detector = None

garbage_net = None
garbage_output_names: List[str] = []
garbage_clean_streak = 0


state_cache: Optional[Dict[str, Any]] = None
state_dirty = False
last_state_flush_ts = 0.0

cloudflare_lock = threading.Lock()
cloudflare_proc: Optional[subprocess.Popen] = None
cloudflare_url: Optional[str] = None
cloudflare_expiry_ts: float = 0.0
cloudflare_stop_timer: Optional[threading.Timer] = None

current_audio_proc: Optional[subprocess.Popen] = None
audio_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue()

router_reboot_lock = threading.Lock()
device_restart_lock = threading.Lock()
recording_process_lock = threading.Lock()
recording_process: Optional[subprocess.Popen] = None
recording_process_date: Optional[str] = None
recording_process_started_at: Optional[float] = None

last_router_reboot_schedule_key: Optional[str] = None

vehicle_event_lock = threading.Lock()
vehicle_event_results: Dict[str, Dict[str, Any]] = {}


def now_dt() -> dt.datetime:
    return dt.datetime.now()


def now_str() -> str:
    return now_dt().strftime("%Y-%m-%d %H:%M:%S")


def safe_write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    tmp.replace(path)


def load_config() -> Dict[str, Any]:
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


CONFIG = load_config()
GARBAGE_INTERVAL_SEC = max(60, int(CONFIG.get("garbage_interval_sec", DEFAULT_GARBAGE_INTERVAL_SEC)))


def normalize_garbage_detection_mode(raw: Any = None) -> str:
    mode = str(raw or DEFAULT_GARBAGE_DETECTION_MODE).strip().lower()

    if mode in {"ai", "ai mode", "aimode"}:
        return "ai"

    if mode in {"normal", "normal mode", "normalmode"}:
        return "normal"

    if mode not in GARBAGE_DETECTION_MODES:
        return DEFAULT_GARBAGE_DETECTION_MODE

    return mode


def garbage_detection_mode_label(mode: Any = None) -> str:
    normalized_mode = normalize_garbage_detection_mode(mode)
    return "AI Mode" if normalized_mode == "ai" else "Normal Mode"


def load_garbage_detection_mode() -> str:
    try:
        cfg = load_config()
        return normalize_garbage_detection_mode(cfg.get("garbage_detection_mode"))
    except Exception:
        return normalize_garbage_detection_mode(CONFIG.get("garbage_detection_mode"))


def set_garbage_detection_mode(mode: str, source: str = "dashboard") -> Dict[str, Any]:
    global CONFIG

    normalized_mode = normalize_garbage_detection_mode(mode)

    cfg = load_config()
    cfg["garbage_detection_mode"] = normalized_mode
    safe_write_json(CONFIG_FILE, cfg)
    CONFIG = cfg

    changed_at = now_str()
    label = garbage_detection_mode_label(normalized_mode)

    def mutate(state):
        state.setdefault("system", {})
        state["system"]["garbage_detection_mode"] = normalized_mode
        state["system"]["garbage_mode"] = label
        state["system"]["garbage_detection_mode_changed_at"] = changed_at
        state["system"]["garbage_detection_mode_changed_by"] = source

        state.setdefault("last_garbage", {})
        state["last_garbage"]["mode"] = normalized_mode

    update_state(mutate, force_flush=True)

    add_event("garbage_detection_mode_changed", {
        "mode": normalized_mode,
        "label": label,
        "source": source,
    })

    return {
        "garbage_detection_mode": normalized_mode,
        "garbage_detection_mode_label": label,
        "changed_at": changed_at,
    }


def garbage_detection_mode_payload() -> Dict[str, Any]:
    mode = load_garbage_detection_mode()
    return {
        "garbage_detection_mode": mode,
        "garbage_detection_mode_label": garbage_detection_mode_label(mode),
        "garbage_detection_modes": sorted(GARBAGE_DETECTION_MODES),
    }


def normalize_person_static_stay_sec(raw: Any = None) -> float:
    try:
        value = float(raw)
    except Exception:
        value = DEFAULT_PERSON_STATIC_STAY_SEC

    return max(
        PERSON_STATIC_STAY_MIN_SEC,
        min(PERSON_STATIC_STAY_MAX_SEC, value)
    )


def load_person_static_stay_sec() -> float:
    try:
        cfg = load_config()
        return normalize_person_static_stay_sec(
            cfg.get("person_static_stay_sec", DEFAULT_PERSON_STATIC_STAY_SEC)
        )
    except Exception:
        return normalize_person_static_stay_sec(
            CONFIG.get("person_static_stay_sec", DEFAULT_PERSON_STATIC_STAY_SEC)
        )


def set_person_static_stay_sec(seconds: Any, source: str = "dashboard") -> Dict[str, Any]:
    global CONFIG

    value = normalize_person_static_stay_sec(seconds)

    cfg = load_config()
    cfg["person_static_stay_sec"] = value
    safe_write_json(CONFIG_FILE, cfg)
    CONFIG = cfg

    changed_at = now_str()

    def mutate(state):
        state.setdefault("system", {})
        state["system"]["person_static_stay_sec"] = value
        state["system"]["person_static_stay_changed_at"] = changed_at
        state["system"]["person_static_stay_changed_by"] = source

        state.setdefault("last_person", {})
        state["last_person"]["stable_required_sec"] = value
        state["last_person"]["stable_inside_sec"] = 0.0
        state["last_person"]["detected"] = False

    update_state(mutate, force_flush=True)

    add_event("person_static_stay_changed", {
        "person_static_stay_sec": value,
        "source": source,
    })

    return {
        "person_static_stay_sec": value,
        "changed_at": changed_at,
    }


def person_static_stay_payload() -> Dict[str, Any]:
    return {
        "person_static_stay_sec": load_person_static_stay_sec(),
        "person_static_stay_min_sec": PERSON_STATIC_STAY_MIN_SEC,
        "person_static_stay_max_sec": PERSON_STATIC_STAY_MAX_SEC,
    }


def normalize_vehicle_detection_mode(raw: Any = None) -> str:
    mode = str(raw or DEFAULT_VEHICLE_DETECTION_MODE).strip().lower()
    if mode not in VEHICLE_DETECTION_MODES:
        return DEFAULT_VEHICLE_DETECTION_MODE
    return mode


def load_vehicle_detection_mode() -> str:
    try:
        cfg = load_config()
        return normalize_vehicle_detection_mode(cfg.get("vehicle_detection_mode"))
    except Exception:
        return normalize_vehicle_detection_mode(CONFIG.get("vehicle_detection_mode"))


def normalize_vehicle_static_stay_sec(raw: Any = None) -> float:
    try:
        value = float(raw)
    except Exception:
        value = DEFAULT_VEHICLE_STATIC_STAY_SEC

    return max(
        VEHICLE_STATIC_STAY_MIN_SEC,
        min(VEHICLE_STATIC_STAY_MAX_SEC, value)
    )


def load_vehicle_static_stay_sec() -> float:
    try:
        cfg = load_config()
        return normalize_vehicle_static_stay_sec(
            cfg.get("vehicle_static_stay_sec", DEFAULT_VEHICLE_STATIC_STAY_SEC)
        )
    except Exception:
        return normalize_vehicle_static_stay_sec(
            CONFIG.get("vehicle_static_stay_sec", DEFAULT_VEHICLE_STATIC_STAY_SEC)
        )


def set_vehicle_static_stay_sec(seconds: Any, source: str = "dashboard") -> Dict[str, Any]:
    global CONFIG

    value = normalize_vehicle_static_stay_sec(seconds)

    cfg = load_config()
    cfg["vehicle_static_stay_sec"] = value
    safe_write_json(CONFIG_FILE, cfg)
    CONFIG = cfg

    changed_at = now_str()

    def mutate(state):
        state.setdefault("system", {})
        state["system"]["vehicle_static_stay_sec"] = value
        state["system"]["vehicle_static_stay_changed_at"] = changed_at
        state["system"]["vehicle_static_stay_changed_by"] = source

        state.setdefault("last_vehicle", {})
        state["last_vehicle"]["stable_required_sec"] = value

    update_state(mutate, force_flush=True)

    add_event("vehicle_static_stay_changed", {
        "vehicle_static_stay_sec": value,
        "source": source,
    })

    return {
        "vehicle_static_stay_sec": value,
        "changed_at": changed_at,
    }


def load_vehicle_geofence_overlap_threshold() -> float:
    try:
        cfg = load_config()
        value = float(cfg.get("vehicle_geofence_overlap_threshold", VEHICLE_GEOFENCE_MIN_OVERLAP_RATIO))
    except Exception:
        try:
            value = float(CONFIG.get("vehicle_geofence_overlap_threshold", VEHICLE_GEOFENCE_MIN_OVERLAP_RATIO))
        except Exception:
            value = VEHICLE_GEOFENCE_MIN_OVERLAP_RATIO

    return max(0.05, min(0.95, value))


def set_vehicle_detection_mode(mode: str, source: str = "dashboard") -> Dict[str, Any]:
    global CONFIG

    normalized_mode = normalize_vehicle_detection_mode(mode)
    cfg = load_config()
    cfg["vehicle_detection_mode"] = normalized_mode
    safe_write_json(CONFIG_FILE, cfg)
    CONFIG = cfg

    changed_at = now_str()

    def mutate(state):
        state.setdefault("system", {})
        state["system"]["vehicle_detection_mode"] = normalized_mode
        state["system"]["vehicle_detection_mode_changed_at"] = changed_at
        state["system"]["vehicle_detection_mode_changed_by"] = source
        state.setdefault("last_vehicle", {})
        state["last_vehicle"]["mode"] = normalized_mode
        state["last_vehicle"]["detected"] = False

    update_state(mutate, force_flush=True)

    add_event("vehicle_detection_mode_changed", {
        "mode": normalized_mode,
        "source": source,
    })

    return {
        "vehicle_detection_mode": normalized_mode,
        "vehicle_geofence_overlap_threshold": load_vehicle_geofence_overlap_threshold(),
        "changed_at": changed_at,
    }


def vehicle_detection_mode_payload() -> Dict[str, Any]:
    return {
        "vehicle_detection_mode": load_vehicle_detection_mode(),
        "vehicle_detection_modes": sorted(VEHICLE_DETECTION_MODES),
        "vehicle_static_stay_sec": load_vehicle_static_stay_sec(),
        "vehicle_static_stay_min_sec": VEHICLE_STATIC_STAY_MIN_SEC,
        "vehicle_static_stay_max_sec": VEHICLE_STATIC_STAY_MAX_SEC,
        "vehicle_geofence_overlap_threshold": load_vehicle_geofence_overlap_threshold(),
    }


DEFAULT_FEATURE_FLAGS: Dict[str, bool] = {
    "person_detection_enabled": True,
    "vehicle_detection_enabled": True,
    "garbage_detection_enabled": True,
    "person_video_recording_enabled": True,
    "vehicle_video_recording_enabled": True,
}


def normalize_feature_flags(raw: Any = None) -> Dict[str, bool]:
    flags = dict(DEFAULT_FEATURE_FLAGS)

    if isinstance(raw, dict):
        for key in DEFAULT_FEATURE_FLAGS:
            if key in raw:
                flags[key] = bool(raw[key])

    return flags


def load_feature_flags() -> Dict[str, bool]:
    try:
        cfg = load_config()
        return normalize_feature_flags(cfg.get("feature_flags", {}))
    except Exception:
        return normalize_feature_flags(CONFIG.get("feature_flags", {}))


def is_feature_enabled(flag_name: str) -> bool:
    return bool(load_feature_flags().get(flag_name, True))


def feature_flags_payload() -> Dict[str, Any]:
    flags = load_feature_flags()
    return {
        "feature_flags": flags,
        **flags,
    }


def set_feature_flag(flag_name: str, enabled: bool, source: str = "mqtt command") -> Dict[str, bool]:
    global CONFIG

    if flag_name not in DEFAULT_FEATURE_FLAGS:
        raise ValueError(f"unknown feature flag: {flag_name}")

    cfg = load_config()
    flags = normalize_feature_flags(cfg.get("feature_flags", {}))
    flags[flag_name] = bool(enabled)

    cfg["feature_flags"] = flags
    safe_write_json(CONFIG_FILE, cfg)
    CONFIG = cfg

    changed_at = now_str()

    def mutate(state):
        state["feature_flags"] = flags
        state.setdefault("system", {})
        state["system"]["feature_flags_last_changed_at"] = changed_at
        state["system"]["feature_flags_last_changed_by"] = source

        if flag_name == "person_detection_enabled" and not enabled and "last_person" in state:
            state["last_person"]["detected"] = False

        if flag_name == "vehicle_detection_enabled" and not enabled and "last_vehicle" in state:
            state["last_vehicle"]["detected"] = False


    update_state(mutate, force_flush=True)

    add_event("feature_flag_changed", {
        "flag": flag_name,
        "enabled": bool(enabled),
        "source": source,
    })

    return flags


# Stream split:
#   MAIN_RTSP_URL      -> high-quality still image and event video upload buffer.
#   DETECTION_RTSP_URL -> lightweight AI detection and dashboard/live stream.
MAIN_RTSP_URL = CONFIG["rtsp_url"]
DETECTION_RTSP_URL = CONFIG.get("cloudflare_live_rtsp_url", MAIN_RTSP_URL)
CLOUDFLARE_LIVE_RTSP_URL = DETECTION_RTSP_URL

# Compatibility alias. Existing state/API fields still expose rtsp_url as the main stream.
RTSP_URL = MAIN_RTSP_URL
PI_IP = CONFIG["pi_ip"]
ROUTER_IP = CONFIG["router_ip"]
CAMERA_IP = CONFIG["camera_ip"]
CAMERA_NAME = CONFIG["camera_name"]
DEVICE_ID = CONFIG["device_id"]
CAMERA_CONFIG_TARGET_URL = str(CONFIG.get("camera_config_url", f"https://{CAMERA_IP}:443")).strip().rstrip("/")
CAMERA_CONFIG_URL = CAMERA_CONFIG_TARGET_URL

ROUTER_REBOOT_SCHEDULE = CONFIG.get("router_reboot_schedule", {})
ROUTER_REBOOT_TIME_1 = str(ROUTER_REBOOT_SCHEDULE.get("time_1", "03:25")).strip()
ROUTER_REBOOT_TIME_2 = str(ROUTER_REBOOT_SCHEDULE.get("time_2", "15:25")).strip()

def is_valid_hhmm(value: str) -> bool:
    return bool(re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", value))

ROUTER_REBOOT_SCHEDULE_TIMES = {
    t for t in {ROUTER_REBOOT_TIME_1, ROUTER_REBOOT_TIME_2}
    if t and is_valid_hhmm(t)
}

SUBDOMAIN_NAME = str(CONFIG.get("subdomain_name", "")).strip().lower()
BASE_DOMAIN = str(CONFIG.get("base_domain", "")).strip().lower()
PERMANENT_LIVE_BASE_URL = str(CONFIG.get("permanent_live_base_url", "")).strip().rstrip("/")

if not PERMANENT_LIVE_BASE_URL and SUBDOMAIN_NAME and BASE_DOMAIN:
    PERMANENT_LIVE_BASE_URL = f"https://{SUBDOMAIN_NAME}.{BASE_DOMAIN}"

PERMANENT_LIVE_URL = f"{PERMANENT_LIVE_BASE_URL}/live" if PERMANENT_LIVE_BASE_URL else None
PERMANENT_DASHBOARD_URL = PERMANENT_LIVE_BASE_URL if PERMANENT_LIVE_BASE_URL else None
PERMANENT_CAMERA_CONFIG_URL = str(CONFIG.get("permanent_camera_config_url", "")).strip().rstrip("/")
if not PERMANENT_CAMERA_CONFIG_URL and PERMANENT_LIVE_BASE_URL:
    PERMANENT_CAMERA_CONFIG_URL = f"{PERMANENT_LIVE_BASE_URL}/camera"
if not PERMANENT_CAMERA_CONFIG_URL:
    PERMANENT_CAMERA_CONFIG_URL = CAMERA_CONFIG_TARGET_URL

SOFTWARE_VERSION = str(CONFIG.get("software_version", "Version 6.19")).strip()
SOFTWARE_FEATURES = str(
    CONFIG.get(
        "software_features",
                "Tiruppur Requirement Only + Live Backup Interface"
    )
).strip()
TAILSCALE_MAIL_ID = str(CONFIG.get("tailscale_mail_id", "")).strip()

MQTT_HOST = CONFIG["mqtt"]["host"]
MQTT_PORT = int(CONFIG["mqtt"]["port"])
MQTT_USERNAME = CONFIG["mqtt"]["username"]
MQTT_PASSWORD = CONFIG["mqtt"]["password"]
MQTT_GARBAGE_TOPIC = CONFIG["mqtt"]["garbage_topic"]
MQTT_CAMERA_EVENT_TOPIC = CONFIG["mqtt"]["camera_event_topic"]
MQTT_COMMAND_TOPIC = CONFIG["mqtt"].get("command_topic", "G-Cam-RnD/command")
MQTT_RESPONSE_TOPIC = CONFIG["mqtt"].get("response_topic", f"{DEVICE_ID}/device_response")
MQTT_COMMAND_TOKEN = CONFIG["mqtt"].get("command_token", "")

SFTP_HOST = CONFIG["sftp"]["host"]
SFTP_PORT = int(CONFIG["sftp"].get("port", 20222))
SFTP_USERNAME = CONFIG["sftp"]["username"]
SFTP_PASSWORD = CONFIG["sftp"]["password"]
SFTP_BASE_DIR = CONFIG["sftp"]["base_dir"]
SFTP_PERSON_DIR = CONFIG["sftp"].get("person_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Person")
SFTP_PERSON_VIDEO_DIR = CONFIG["sftp"].get("person_video_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Video/Person_Video")
SFTP_VEHICLE_DIR = CONFIG["sftp"].get("vehicle_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Vehicle")
SFTP_VEHICLE_VIDEO_DIR = CONFIG["sftp"].get("vehicle_video_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Video/Vehicle_Video")
SFTP_GARBAGE_DIR = CONFIG["sftp"].get("garbage_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Garbage")
SFTP_AUDIO_DIR = CONFIG["sftp"].get("audio_dir", f"{SFTP_BASE_DIR.rstrip('/')}/Audio")
SFTP_DEFAULT_AUDIO_DIR = CONFIG["sftp"].get("default_audio_dir", "/home/ftpuser/ftp/files/Default_Audio")
BATTERY_MODE = str(CONFIG.get("battery", {}).get("mode", "disabled")).strip().lower()
BATTERY_SYSFS_PATH = str(CONFIG.get("battery", {}).get("sysfs_path", "")).strip()
BATTERY_COMMAND = str(CONFIG.get("battery", {}).get("command", "")).strip()
BATTERY_DIVIDER_RATIO = float(CONFIG.get("battery", {}).get("divider_ratio", 1.0))

RECORDING_CONFIG = CONFIG.get("recording", {}) if isinstance(CONFIG.get("recording", {}), dict) else {}
RECORDING_ENABLED = bool(RECORDING_CONFIG.get("enabled", True))
RECORDING_RTSP_URL = str(RECORDING_CONFIG.get("rtsp_url", DETECTION_RTSP_URL)).strip() or DETECTION_RTSP_URL
RECORDING_SEGMENT_SEC = max(5, int(RECORDING_CONFIG.get("segment_sec", 10)))
RECORDING_RESERVE_GB = min(5.0, max(3.0, float(RECORDING_CONFIG.get("reserve_gb", 3.0))))
RECORDING_RESERVE_BYTES = int(RECORDING_RESERVE_GB * 1024 * 1024 * 1024)
RECORDING_CLEANUP_HEADROOM_BYTES = 256 * 1024 * 1024
RECORDING_START_GRACE_SEC = 30.0
RECORDING_STALL_TIMEOUT_SEC = 45.0
RECORDING_FFMPEG_LOG = LOG_DIR / "recording_ffmpeg.log"

# Playback recording intentionally reuses the application's already-open SUB stream
# through the local MJPEG endpoint. This avoids opening a second RTSP session to the
# camera, which can be rejected/stalled by cameras that limit simultaneous RTSP clients.
RECORDING_SOURCE_URL = f"http://127.0.0.1:{PORT}/video_feed"
RECORDING_OUTPUT_FPS = 10
RECORDING_OUTPUT_WIDTH = 640
PERMANENT_PLAYBACK_URL = f"{PERMANENT_LIVE_BASE_URL}/playback" if PERMANENT_LIVE_BASE_URL else None
PERMANENT_PLAYBACK_LIVE_URL = f"{PERMANENT_LIVE_BASE_URL}/playback/live" if PERMANENT_LIVE_BASE_URL else None


def detect_local_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip and ip != "127.0.0.1":
            return ip
    except Exception:
        pass
    return PI_IP


def detect_public_ip(force: bool = False) -> Optional[str]:
    global PUBLIC_IP_CACHE, LAST_PUBLIC_IP_CHECK_TS

    if not force and PUBLIC_IP_CACHE and (time.time() - LAST_PUBLIC_IP_CHECK_TS) < 900:
        return PUBLIC_IP_CACHE

    for url in ["https://api.ipify.org", "https://checkip.amazonaws.com"]:
        try:
            r = requests.get(url, timeout=3)
            ip = r.text.strip()
            ipaddress.ip_address(ip)
            PUBLIC_IP_CACHE = ip
            LAST_PUBLIC_IP_CHECK_TS = time.time()
            return ip
        except Exception:
            continue

    LAST_PUBLIC_IP_CHECK_TS = time.time()
    return PUBLIC_IP_CACHE


def detect_geo_location(force: bool = False) -> Optional[str]:
    global GEO_LOCATION_CACHE, LAST_GEO_CHECK_TS

    if not force and GEO_LOCATION_CACHE and (time.time() - LAST_GEO_CHECK_TS) < 1800:
        return GEO_LOCATION_CACHE

    try:
        r = requests.get("https://ipapi.co/json/", timeout=4)
        data = r.json()
        city = str(data.get("city", "")).strip()
        region = str(data.get("region", "")).strip()
        country = str(data.get("country_name", "")).strip()
        lat = data.get("latitude")
        lon = data.get("longitude")
        parts = [p for p in [city, region, country] if p]
        location = ", ".join(parts)
        if lat is not None and lon is not None:
            location = f"{location} ({lat}, {lon})" if location else f"{lat}, {lon}"
        GEO_LOCATION_CACHE = location or None
        LAST_GEO_CHECK_TS = time.time()
        return GEO_LOCATION_CACHE
    except Exception:
        LAST_GEO_CHECK_TS = time.time()
        return GEO_LOCATION_CACHE


def local_dashboard_url() -> str:
    return f"http://{detect_local_ip()}:{PORT}"


def local_stream_url() -> str:
    return f"{local_dashboard_url()}/video_feed"


def default_state() -> Dict[str, Any]:
    return {
        "app_name": 'G-Cam "RealTech Systems"',
        "started_at": now_str(),
        "camera_ip": CAMERA_IP,
        "router_ip": ROUTER_IP,
        "raspberry_ip": detect_local_ip(),
        "device_id": DEVICE_ID,
        "camera_name": CAMERA_NAME,
        "camera_config_url": PERMANENT_CAMERA_CONFIG_URL,
        "public_ip": detect_public_ip(),
        "system": {
            "camera_connected": False,
            "last_frame_at": None,
            "last_error": None,
            "sftp_last_ok": None,
            "sftp_last_error": None,
            "mqtt_last_ok": None,
            "mqtt_last_error": None,
            "command_listener": False,
            "garbage_mode": garbage_detection_mode_label(load_garbage_detection_mode()),
            "garbage_detection_mode": load_garbage_detection_mode(),
            "garbage_detection_mode_changed_at": None,
            "garbage_detection_mode_changed_by": None,
            "pi_temperature_c": None,
            "network_status": None,
            "network_iface": None,
            "network_link_speed_mbps": None,
            "network_rx_bps": 0,
            "network_tx_bps": 0,
            "network_audio_muted": False,
            "network_audio_mute_reason": None,
            "network_audio_last_changed_at": None,
            "network_audio_last_check_at": None,
            "network_audio_iface": None,
            "network_audio_saved_volume": None,
            "live_talk_active": False,
            "live_talk_draining": False,
            "live_talk_last_started_at": None,
            "live_talk_last_stopped_at": None,
            "live_talk_last_stop_requested_at": None,
            "live_talk_last_chunk_at": None,
            "live_talk_last_error": None,
            "live_talk_queue_size": 0,
            "battery_voltage": None,
            "battery_current_a": None,
            "battery_current_ma": None,
            "battery_status": None,
            "ram_total_mb": None,
            "ram_used_mb": None,
            "ram_percent": None,
            "geo_location": None,
            "last_restart_request_at": None,
            "garbage_interval_sec": GARBAGE_INTERVAL_SEC,
            "power_saving_active": False,
            "power_saving_source": None,
            "power_saving_reason": None,
            "power_saving_last_changed_at": None,
            "feature_flags_last_changed_at": None,
            "feature_flags_last_changed_by": None,
            "person_static_stay_sec": load_person_static_stay_sec(),
            "person_static_stay_changed_at": None,
            "person_static_stay_changed_by": None,
            "vehicle_detection_mode": load_vehicle_detection_mode(),
            "vehicle_geofence_overlap_threshold": load_vehicle_geofence_overlap_threshold(),
            "vehicle_detection_mode_changed_at": None,
            "vehicle_detection_mode_changed_by": None,
            "recording_enabled": RECORDING_ENABLED,
            "recording_active": False,
            "recording_last_error": None,
            "recording_storage_mode": "capacity_based_ring_buffer",
            "recording_reserve_gb": RECORDING_RESERVE_GB,
            "recording_segment_sec": RECORDING_SEGMENT_SEC,
            "recording_playback_url": PERMANENT_PLAYBACK_URL
        },
        "links": {
            "dashboard_local": local_dashboard_url(),
            "stream_local": local_stream_url()
        },
        "live_link": {
            "active": False,
            "url": None,
            "expires_at": None
        },
        "counts": {"HIGH": 0, "MEDIUM": 0, "LOW": 0},
        "feature_flags": load_feature_flags(),
        "last_person": {
            "detected": False,
            "time": None,
            "image": None,
            "image_file": None,
            "image_status": None,
            "image_uploaded_path": None,
            "count": 0,
            "best_confidence": 0.0,
            "stable_inside_sec": 0.0,
            "stable_required_sec": load_person_static_stay_sec(),
            "stable_hit_count": 0
        },
        "last_garbage": {
            "detected": False,
            "time": None,
            "image": None,
            "severity": None,
            "diff_ratio": 0.0,
            "edge_ratio": 0.0,
            "blob_area_ratio": 0.0,
            "blob_count": 0,
            "triggered_by": None,
            "reference_items": [],
            "mode": load_garbage_detection_mode()
        },
        "last_audio": {
            "file": None,
            "source_path": None,
            "time": None,
            "status": None
        },
        "warning_audio": {
            "enabled": True,
            "person_enabled": True,
            "vehicle_enabled": True,
            "schedule_enabled": False,
            "start_time": "10:00",
            "end_time": "18:00",
            "last_status": None,
            "last_person_status": None,
            "last_vehicle_status": None
        },
        "power_saving": {
            "enabled": False,
            "source": None,
            "reason": None,
            "last_changed_at": None,
            "schedule_enabled": False,
            "start_time": "22:00",
            "end_time": "06:00",
            "last_schedule_check": None
        },
        "last_video": {
            "file": None,
            "time": None,
            "status": None,
            "duration_sec": 0,
            "person_count": 0,
            "best_confidence": 0.0
        },
        "last_vehicle": {
            "detected": False,
            "time": None,
            "image": None,
            "count": 0,
            "best_confidence": 0.0,
            "labels": [],
            "image_status": None,
            "image_file": None,
            "image_uploaded_path": None,
            "mode": load_vehicle_detection_mode(),
            "geofence_overlap": 0.0,
            "stable_inside_sec": 0.0,
            "stable_required_sec": load_vehicle_static_stay_sec(),
            "stable_hit_count": 0,
            "stable_vehicle_count": 0,
            "first_event_fired": False,
            "second_event_fired": False,
            "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
            "first_event_elapsed_sec": 0.0
        },
        "last_vehicle_video": {
            "file": None,
            "time": None,
            "status": None,
            "duration_sec": 0,
            "vehicle_count": 0,
            "best_confidence": 0.0,
            "labels": []
        },
        "events": []
    }


def flush_state(force: bool = False) -> None:
    global state_dirty, last_state_flush_ts
    with state_lock:
        if state_cache is None:
            return
        now_ts = time.time()
        if not force and not state_dirty:
            return
        if not force and (now_ts - last_state_flush_ts) < STATE_FLUSH_INTERVAL_SEC:
            return
        safe_write_json(STATE_FILE, state_cache)
        state_dirty = False
        last_state_flush_ts = now_ts


def load_state() -> Dict[str, Any]:
    global state_cache, last_state_flush_ts
    with state_lock:
        if state_cache is not None:
            return json.loads(json.dumps(state_cache))

        if not STATE_FILE.exists():
            state_cache = default_state()
            safe_write_json(STATE_FILE, state_cache)
            last_state_flush_ts = time.time()
            return json.loads(json.dumps(state_cache))

        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                raw = f.read().strip()
            state_cache = json.loads(raw) if raw else default_state()
        except Exception:
            state_cache = default_state()
            safe_write_json(STATE_FILE, state_cache)

        if "system" not in state_cache:
            state_cache = default_state()

        state_cache["system"].setdefault("ram_total_mb", None)
        state_cache["system"].setdefault("ram_used_mb", None)
        state_cache["system"].setdefault("ram_percent", None)

        current_garbage_mode = load_garbage_detection_mode()
        state_cache["system"]["garbage_detection_mode"] = current_garbage_mode
        state_cache["system"]["garbage_mode"] = garbage_detection_mode_label(current_garbage_mode)
        state_cache["system"].setdefault("garbage_detection_mode_changed_at", None)
        state_cache["system"].setdefault("garbage_detection_mode_changed_by", None)

        if "last_garbage" not in state_cache:
            state_cache["last_garbage"] = default_state()["last_garbage"]
        state_cache["last_garbage"].setdefault("reference_items", [])
        state_cache["last_garbage"].setdefault("mode", current_garbage_mode)

        if "warning_audio" not in state_cache:
            state_cache["warning_audio"] = default_state()["warning_audio"]
        legacy_warning_enabled = bool(state_cache["warning_audio"].get("enabled", True))
        state_cache["warning_audio"].setdefault("enabled", legacy_warning_enabled)
        state_cache["warning_audio"].setdefault("person_enabled", legacy_warning_enabled)
        state_cache["warning_audio"].setdefault("vehicle_enabled", legacy_warning_enabled)
        state_cache["warning_audio"].setdefault("schedule_enabled", False)
        state_cache["warning_audio"].setdefault("start_time", "10:00")
        state_cache["warning_audio"].setdefault("end_time", "18:00")
        state_cache["warning_audio"].setdefault("last_status", None)
        state_cache["warning_audio"].setdefault("last_person_status", None)
        state_cache["warning_audio"].setdefault("last_vehicle_status", None)

        if "power_saving" not in state_cache:
            state_cache["power_saving"] = default_state()["power_saving"]

        state_cache["power_saving"].setdefault("enabled", False)
        state_cache["power_saving"].setdefault("source", None)
        state_cache["power_saving"].setdefault("reason", None)
        state_cache["power_saving"].setdefault("last_changed_at", None)
        state_cache["power_saving"].setdefault("schedule_enabled", False)
        state_cache["power_saving"].setdefault("start_time", "22:00")
        state_cache["power_saving"].setdefault("end_time", "06:00")
        state_cache["power_saving"].setdefault("last_schedule_check", None)

        state_cache["system"].setdefault("power_saving_active", False)
        state_cache["system"].setdefault("power_saving_source", None)
        state_cache["system"].setdefault("power_saving_reason", None)
        state_cache["system"].setdefault("power_saving_last_changed_at", None)

        state_cache["system"]["power_saving_active"] = bool(state_cache["power_saving"].get("enabled", False))
        state_cache["system"]["power_saving_source"] = state_cache["power_saving"].get("source")
        state_cache["system"]["power_saving_reason"] = state_cache["power_saving"].get("reason")
        state_cache["system"]["power_saving_last_changed_at"] = state_cache["power_saving"].get("last_changed_at")

        state_cache["system"].setdefault("network_audio_muted", False)
        state_cache["system"].setdefault("network_audio_mute_reason", None)
        state_cache["system"].setdefault("network_audio_last_changed_at", None)
        state_cache["system"].setdefault("network_audio_last_check_at", None)
        state_cache["system"].setdefault("network_audio_iface", None)
        state_cache["system"].setdefault("network_audio_saved_volume", None)
        state_cache["system"].setdefault("live_talk_active", False)
        state_cache["system"].setdefault("live_talk_draining", False)
        state_cache["system"].setdefault("live_talk_last_started_at", None)
        state_cache["system"].setdefault("live_talk_last_stopped_at", None)
        state_cache["system"].setdefault("live_talk_last_stop_requested_at", None)
        state_cache["system"].setdefault("live_talk_last_chunk_at", None)
        state_cache["system"].setdefault("live_talk_last_error", None)
        state_cache["system"].setdefault("live_talk_queue_size", 0)

        state_cache["system"].setdefault("feature_flags_last_changed_at", None)
        state_cache["system"].setdefault("feature_flags_last_changed_by", None)
        state_cache["system"]["vehicle_detection_mode"] = load_vehicle_detection_mode()
        state_cache["system"]["vehicle_geofence_overlap_threshold"] = load_vehicle_geofence_overlap_threshold()
        state_cache["system"].setdefault("vehicle_detection_mode_changed_at", None)
        state_cache["system"].setdefault("vehicle_detection_mode_changed_by", None)
        state_cache["feature_flags"] = load_feature_flags()

        if "last_vehicle" not in state_cache:
            state_cache["last_vehicle"] = default_state()["last_vehicle"]
        state_cache["last_vehicle"].setdefault("detected", False)
        state_cache["last_vehicle"].setdefault("time", None)
        state_cache["last_vehicle"].setdefault("image", None)
        state_cache["last_vehicle"].setdefault("count", 0)
        state_cache["last_vehicle"].setdefault("best_confidence", 0.0)
        state_cache["last_vehicle"].setdefault("mode", load_vehicle_detection_mode())
        state_cache["last_vehicle"].setdefault("geofence_overlap", 0.0)
        state_cache["last_vehicle"].setdefault("labels", [])
        state_cache["last_vehicle"].setdefault("image_status", None)
        state_cache["last_vehicle"].setdefault("image_file", None)
        state_cache["last_vehicle"].setdefault("image_uploaded_path", None)
        state_cache["last_vehicle"].setdefault("stable_inside_sec", 0.0)
        state_cache["last_vehicle"].setdefault("stable_required_sec", load_vehicle_static_stay_sec())
        state_cache["last_vehicle"].setdefault("stable_hit_count", 0)
        state_cache["last_vehicle"].setdefault("stable_vehicle_count", 0)
        state_cache["last_vehicle"].setdefault("first_event_fired", False)
        state_cache["last_vehicle"].setdefault("second_event_fired", False)
        state_cache["last_vehicle"].setdefault("second_event_delay_sec", VEHICLE_SECOND_EVENT_DELAY_SEC)
        state_cache["last_vehicle"].setdefault("first_event_elapsed_sec", 0.0)

        if "last_vehicle_video" not in state_cache:
            state_cache["last_vehicle_video"] = default_state()["last_vehicle_video"]
        state_cache["last_vehicle_video"].setdefault("file", None)
        state_cache["last_vehicle_video"].setdefault("time", None)
        state_cache["last_vehicle_video"].setdefault("status", None)
        state_cache["last_vehicle_video"].setdefault("duration_sec", 0)
        state_cache["last_vehicle_video"].setdefault("vehicle_count", 0)
        state_cache["last_vehicle_video"].setdefault("best_confidence", 0.0)
        state_cache["last_vehicle_video"].setdefault("labels", [])

        last_state_flush_ts = time.time()
        return json.loads(json.dumps(state_cache))


def update_state(mutator, force_flush: bool = False) -> None:
    global state_cache, state_dirty
    with state_lock:
        if state_cache is None:
            state_cache = default_state()
        mutator(state_cache)
        state_dirty = True
    flush_state(force=force_flush)


def add_event(event_type: str, details: Dict[str, Any]) -> None:
    def mutate(state):
        state["events"].insert(0, {"type": event_type, "time": now_str(), **details})
        state["events"] = state["events"][:120]
    update_state(mutate)


def is_power_saving_active() -> bool:
    try:
        state = load_state()
        return bool(state.get("power_saving", {}).get("enabled", False))
    except Exception:
        return False


def clear_latest_frame() -> None:
    global latest_frame, latest_live_frame, latest_frame_ts
    global latest_main_frame, latest_main_frame_ts

    with frame_lock:
        latest_frame = None
        latest_live_frame = None
        latest_frame_ts = 0.0
        latest_main_frame = None
        latest_main_frame_ts = 0.0


def resize_frame_to_width(frame: np.ndarray, target_width: int) -> np.ndarray:
    if frame is None or frame.size == 0:
        return frame

    if target_width <= 0:
        return frame

    h, w = frame.shape[:2]

    if w <= target_width:
        return frame

    new_h = int(h * (target_width / float(w)))

    return cv2.resize(
        frame,
        (target_width, new_h),
        interpolation=cv2.INTER_AREA
    )


def power_saving_status_payload() -> Dict[str, Any]:
    state = load_state()
    ps = state.get("power_saving", {})

    return {
        "power_saving_enabled": bool(ps.get("enabled", False)),
        "power_saving_source": ps.get("source"),
        "power_saving_reason": ps.get("reason"),
        "power_saving_last_changed_at": ps.get("last_changed_at"),
        "power_saving_schedule_enabled": bool(ps.get("schedule_enabled", False)),
        "power_saving_schedule_start_time": ps.get("start_time"),
        "power_saving_schedule_end_time": ps.get("end_time"),
        "power_saving_last_schedule_check": ps.get("last_schedule_check")
    }


def set_power_saving_enabled(
    enabled: bool,
    reason: str,
    source: str,
    disable_schedule: bool = False
) -> Dict[str, Any]:
    changed_at = now_str()

    def mutate(state):
        state.setdefault("power_saving", default_state()["power_saving"])
        state["power_saving"]["enabled"] = bool(enabled)
        state["power_saving"]["source"] = source
        state["power_saving"]["reason"] = reason
        state["power_saving"]["last_changed_at"] = changed_at

        if disable_schedule:
            state["power_saving"]["schedule_enabled"] = False

        state["system"]["power_saving_active"] = bool(enabled)
        state["system"]["power_saving_source"] = source
        state["system"]["power_saving_reason"] = reason
        state["system"]["power_saving_last_changed_at"] = changed_at

        if enabled:
            state["system"]["camera_connected"] = False
            state["system"]["last_error"] = "Power saving mode active"
            state["last_person"]["detected"] = False
            state["last_vehicle"]["detected"] = False
            state["live_link"] = {
                "active": False,
                "url": None,
                "expires_at": None
            }
            state["last_audio"] = {
                "file": None,
                "source_path": None,
                "time": changed_at,
                "status": "stopped_power_saving"
            }
        else:
            state["system"]["last_error"] = None

    update_state(mutate, force_flush=True)

    if enabled:
        clear_latest_frame()

        try:
            stop_current_audio_process()
        except Exception:
            pass

        try:
            clear_audio_queue()
        except Exception:
            pass

        try:
            stop_live_tunnel()
        except Exception:
            pass

    add_event("power_saving_changed", {
        "enabled": bool(enabled),
        "source": source,
        "reason": reason
    })

    return power_saving_status_payload()


def is_time_inside_range(now_time: dt.time, start_time: dt.time, end_time: dt.time) -> bool:
    if start_time == end_time:
        return True

    if start_time < end_time:
        return start_time <= now_time < end_time

    return now_time >= start_time or now_time < end_time


def parse_power_saving_schedule(payload: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    start_raw = (
        payload.get("start_time")
        or payload.get("start")
        or payload.get("from")
        or payload.get("startTime")
    )
    end_raw = (
        payload.get("end_time")
        or payload.get("end")
        or payload.get("to")
        or payload.get("endTime")
    )

    return (
        str(start_raw).strip() if start_raw is not None else None,
        str(end_raw).strip() if end_raw is not None else None
    )


def build_power_saving_blocked_response(cmd: str) -> Dict[str, Any]:
    return {
        "device_id": DEVICE_ID,
        "event": "command_blocked_power_saving",
        "command": cmd,
        "status": "blocked",
        "reason": "Power saving mode active. Only Data Status and Power Saving commands are allowed.",
        **power_saving_status_payload(),
        "time": now_str()
    }


def power_saving_command_allowed(cmd: str) -> bool:
    return cmd in POWER_SAVING_ALLOWED_WHEN_ACTIVE


def refresh_runtime_links_in_state() -> None:
    def mutate(state):
        state["raspberry_ip"] = detect_local_ip()
        state["public_ip"] = detect_public_ip()
        state["links"]["dashboard_local"] = local_dashboard_url()
        state["links"]["stream_local"] = local_stream_url()
        state["camera_config_url"] = PERMANENT_CAMERA_CONFIG_URL
        state["camera_config_target_url"] = CAMERA_CONFIG_TARGET_URL
    update_state(mutate)


def init_models() -> None:
    global person_net, hog_detector, garbage_net, garbage_output_names

    # Person model (unchanged)
    proto = MODEL_DIR / "MobileNetSSD_deploy.prototxt"
    model = MODEL_DIR / "MobileNetSSD_deploy.caffemodel"

    if not proto.exists():
        raise FileNotFoundError(f"Missing model file: {proto}")
    if not model.exists():
        raise FileNotFoundError(f"Missing model file: {model}")

    person_net = cv2.dnn.readNetFromCaffe(str(proto), str(model))

    hog_detector = cv2.HOGDescriptor()
    hog_detector.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    # Garbage detector removed in Person + Vehicle only build.
    garbage_net = None
    garbage_output_names = []

def get_frame_copy() -> Optional[np.ndarray]:
    # Detection/process frame.
    # Kept at PROCESS_FRAME_WIDTH to preserve old detection behaviour.
    with frame_lock:
        if latest_frame is None:
            return None
        return latest_frame.copy()


def get_frame_copy_with_ts() -> Tuple[Optional[np.ndarray], float]:
    # Detection/process frame with timestamp.
    with frame_lock:
        if latest_frame is None:
            return None, 0.0
        return latest_frame.copy(), latest_frame_ts


def get_live_frame_copy() -> Optional[np.ndarray]:
    """

    Preference:
      1. latest_live_frame
      2. latest_frame
      3. None
    """
    with frame_lock:
        if latest_live_frame is not None:
            return latest_live_frame.copy()

        if latest_frame is not None:
            return latest_frame.copy()

        return None


def get_main_frame_copy_with_ts(max_age_sec: float = 10.0) -> Tuple[Optional[np.ndarray], float]:
    """
    High-quality MAIN-stream frame for SFTP image upload only.
    Falls back safely when the main stream is temporarily unavailable.
    """
    with frame_lock:
        if latest_main_frame is None:
            return None, 0.0

        age = time.time() - latest_main_frame_ts
        if age > max(float(max_age_sec), 0.5):
            return None, latest_main_frame_ts

        return latest_main_frame.copy(), latest_main_frame_ts


def scale_detections_to_frame(
    detections: List[Dict[str, Any]],
    source_frame: np.ndarray,
    target_frame: np.ndarray
) -> List[Dict[str, Any]]:
    """Scale detection boxes from sub-stream frame coordinates to main-stream frame coordinates."""
    if not detections or source_frame is None or target_frame is None:
        return []

    src_h, src_w = source_frame.shape[:2]
    dst_h, dst_w = target_frame.shape[:2]

    if src_w <= 0 or src_h <= 0 or dst_w <= 0 or dst_h <= 0:
        return []

    sx = dst_w / float(src_w)
    sy = dst_h / float(src_h)

    scaled: List[Dict[str, Any]] = []
    for item in detections:
        cloned = dict(item)
        box = item.get("box")
        if box is not None and len(box) == 4:
            x1, y1, x2, y2 = box
            cloned["box"] = (
                max(0, min(dst_w - 1, int(round(float(x1) * sx)))),
                max(0, min(dst_h - 1, int(round(float(y1) * sy)))),
                max(0, min(dst_w - 1, int(round(float(x2) * sx)))),
                max(0, min(dst_h - 1, int(round(float(y2) * sy)))),
            )
        scaled.append(cloned)

    return scaled


def capture_fresh_main_frame_direct(
    timeout_sec: float = EVENT_IMAGE_DIRECT_CAPTURE_TIMEOUT_SEC
) -> Tuple[Optional[np.ndarray], str]:
    """
    Emergency MAIN-stream snapshot used only when the buffered MAIN frame is stale.

    This keeps event still-image uploads high quality. It intentionally does not
    use DETECTION_RTSP_URL / SUB stream.
    """
    cap: Optional[cv2.VideoCapture] = None
    deadline = time.time() + max(0.5, float(timeout_sec))
    warmup_frames = max(1, int(EVENT_IMAGE_DIRECT_CAPTURE_WARMUP_FRAMES))
    frame_count = 0
    last_good_frame: Optional[np.ndarray] = None

    try:
        cap = open_main_rtsp()

        if cap is None or not cap.isOpened():
            return None, "direct_main_open_failed"

        while time.time() < deadline and not stop_event.is_set():
            ok, frame = cap.read()

            if ok and frame is not None and frame.size > 0:
                last_good_frame = frame.copy()
                frame_count += 1

                # Skip a few frames so we avoid an old RTSP buffered frame.
                if frame_count >= warmup_frames:
                    return last_good_frame, "direct_main"

            time.sleep(0.03)

        if last_good_frame is not None and last_good_frame.size > 0:
            return last_good_frame, "direct_main_last_good"

        return None, "direct_main_read_failed"

    except Exception as exc:
        return None, f"direct_main_error: {exc}"

    finally:
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass


def annotate_main_event_image(
    main_frame: np.ndarray,
    main_source: str,
    detection_frame: np.ndarray,
    detections: List[Dict[str, Any]],
    draw_fn,
    refine_fn=None,
    strict_refine: bool = False,
) -> Tuple[np.ndarray, List[Dict[str, Any]], str]:
    """Draw event annotations on a MAIN-stream frame without using SUB fallback."""
    if callable(refine_fn):
        try:
            refined = refine_fn(main_frame)
        except Exception as exc:
            print(f"[EVENT IMAGE REFINE ERROR] {exc}", flush=True)
            refined = []

        if refined:
            return draw_fn(main_frame, refined), refined, f"{main_source}_redetect"

        if strict_refine and not detections:
            return main_frame.copy(), [], f"{main_source}_redetect_none"

        # Old code saved SUB/D1 here when MAIN re-detect failed.
        # New behavior: keep the MAIN image and scale the already-confirmed
        # SUB detections onto it. Image quality remains MAIN-stream quality.
        scaled_after_refine = scale_detections_to_frame(
            detections,
            detection_frame,
            main_frame,
        )
        return (
            draw_fn(main_frame, scaled_after_refine),
            scaled_after_refine,
            f"{main_source}_scaled_after_redetect_none",
        )

    scaled = scale_detections_to_frame(detections, detection_frame, main_frame)
    return draw_fn(main_frame, scaled), scaled, f"{main_source}_scaled"


def build_high_quality_event_image(
    detection_frame: np.ndarray,
    detections: List[Dict[str, Any]],
    draw_fn,
    refine_fn=None,
    strict_refine: bool = False,
    require_main_stream: bool = EVENT_IMAGE_REQUIRE_MAIN_STREAM,
) -> Tuple[Optional[np.ndarray], List[Dict[str, Any]], str]:
    """
    Build a still image for SFTP upload from the MAIN stream only.

    AI detection stays on the SUB stream. Event still-image upload waits for a
    fresh MAIN frame and, if needed, tries a direct MAIN snapshot. When
    require_main_stream=True, this function cancels the still image instead of
    uploading a low-quality SUB/D1 image.
    """
    deadline = time.time() + max(0.5, float(EVENT_IMAGE_MAIN_WAIT_SEC))
    last_stale_ts = 0.0

    while time.time() < deadline and not stop_event.is_set():
        main_frame, main_ts = get_main_frame_copy_with_ts(
            max_age_sec=EVENT_IMAGE_MAIN_MAX_AGE_SEC
        )

        if main_frame is not None and main_frame.size > 0:
            return annotate_main_event_image(
                main_frame=main_frame,
                main_source="main_buffer",
                detection_frame=detection_frame,
                detections=detections,
                draw_fn=draw_fn,
                refine_fn=refine_fn,
                strict_refine=strict_refine,
            )

        last_stale_ts = main_ts
        time.sleep(0.05)

    direct_main_frame, direct_status = capture_fresh_main_frame_direct(
        EVENT_IMAGE_DIRECT_CAPTURE_TIMEOUT_SEC
    )

    if direct_main_frame is not None and direct_main_frame.size > 0:
        return annotate_main_event_image(
            main_frame=direct_main_frame,
            main_source=direct_status,
            detection_frame=detection_frame,
            detections=detections,
            draw_fn=draw_fn,
            refine_fn=refine_fn,
            strict_refine=strict_refine,
        )

    update_state(lambda s: s["system"].update({
        "main_stream_last_error": (
            "MAIN stream unavailable for event image; "
            f"direct_status={direct_status}; last_main_ts={last_stale_ts}"
        )
    }))

    if require_main_stream:
        return None, [], "main_unavailable_no_sub_upload"

    fallback = detection_frame.copy()
    return draw_fn(fallback, detections), detections, "sub_fallback_allowed"


def wait_for_live_frame(timeout_sec: float = 8.0) -> Tuple[bool, str]:
    deadline = time.time() + max(0.5, float(timeout_sec))

    while time.time() < deadline and not stop_event.is_set():
        if is_power_saving_active():
            return False, "Power saving mode is active."

        frame = get_frame_copy()
        if frame is not None and frame.size > 0:
            return True, "Live frame ready."

        time.sleep(0.25)

    try:
        state = load_state()
        last_error = state.get("system", {}).get("last_error")
    except Exception:
        last_error = None

    if last_error:
        return False, f"No live frame available. Camera status: {last_error}"

    return False, "No live frame available. Check RTSP, camera connection, and power saving."


def run_garbage_detection_guarded(
    triggered_by: str = "manual",
    create_live_link: bool = True,
    wait_for_frame_sec: float = 0.0,
    wait_for_lock_sec: float = 0.0
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    lock_acquired = False

    try:
        if wait_for_lock_sec > 0:
            lock_acquired = garbage_detection_lock.acquire(timeout=wait_for_lock_sec)
        else:
            lock_acquired = garbage_detection_lock.acquire(blocking=False)

        if not lock_acquired:
            return None, "Garbage detection is already running. Try again after a few seconds."

        if wait_for_frame_sec > 0:
            frame_ok, frame_message = wait_for_live_frame(wait_for_frame_sec)
            if not frame_ok:
                return None, frame_message

        result = run_garbage_detection(
            triggered_by=triggered_by,
            create_live_link=create_live_link
        )

        if result is None:
            return None, "Garbage detection failed. No frame/result available."

        return result, None

    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"

        try:
            update_state(
                lambda s: s["system"].update({
                    "last_error": f"Garbage detection failed: {error}"
                }),
                force_flush=True
            )
        except Exception:
            pass

        try:
            add_event("garbage_detection_failed", {
                "triggered_by": triggered_by,
                "error": error
            })
        except Exception:
            pass

        return None, error

    finally:
        if lock_acquired:
            try:
                garbage_detection_lock.release()
            except Exception:
                pass


def get_garbage_label_display(label: str) -> str:
    label = str(label or "").strip().lower()
    if not label:
        return "Object"
    return GARBAGE_LABEL_ALIAS.get(label, label.title())


def box_iou_xyxy(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    iw = max(0, inter_x2 - inter_x1)
    ih = max(0, inter_y2 - inter_y1)
    inter = iw * ih

    if inter <= 0:
        return 0.0

    area_a = max(1, (ax2 - ax1) * (ay2 - ay1))
    area_b = max(1, (bx2 - bx1) * (by2 - by1))
    union = area_a + area_b - inter
    return float(inter) / float(max(union, 1))


def dedupe_garbage_detections(
    detections: List[Dict[str, Any]],
    iou_threshold: float = 0.45
) -> List[Dict[str, Any]]:
    if not detections:
        return []

    detections = sorted(detections, key=lambda x: x["confidence"], reverse=True)
    kept: List[Dict[str, Any]] = []

    for det in detections:
        should_keep = True
        for prev in kept:
            if det["label"] == prev["label"] and box_iou_xyxy(det["box"], prev["box"]) >= iou_threshold:
                should_keep = False
                break
        if should_keep:
            kept.append(det)

    return kept


def _normalize_yolo_output(raw_outputs: Any) -> np.ndarray:
    """
    Normalize YOLO ONNX outputs to shape: (N, C).

    Supports common layouts:
      YOLOv8:
        (1, 84, N) -> (N, 84)
        (1, 5, N)  -> (N, 5)   single-class export
      YOLOv5:
        (1, N, 85) -> (N, 85)
        (N, 85)    -> unchanged
        (1, 5, N), (5, N), (N, 5)
    """
    if isinstance(raw_outputs, (list, tuple)):
        if len(raw_outputs) == 1:
            raw_outputs = raw_outputs[0]
        else:
            parts = []

            for out in raw_outputs:
                arr = np.asarray(out)

                if arr.ndim == 3 and arr.shape[0] == 1:
                    arr = arr[0]

                if arr.ndim != 2:
                    continue

                # Transpose channel-first outputs: C x N -> N x C.
                if arr.shape[0] < arr.shape[1] and arr.shape[0] <= 100:
                    arr = arr.T

                parts.append(arr)

            if not parts:
                return np.empty((0, 0), dtype=np.float32)

            return np.concatenate(parts, axis=0)

    arr = np.asarray(raw_outputs)

    if arr.ndim == 3 and arr.shape[0] == 1:
        arr = arr[0]

    if arr.ndim != 2:
        return np.empty((0, 0), dtype=np.float32)

    # YOLOv8 commonly gives C x N.
    # This also fixes single-class plate models that output 5 x N.
    if arr.shape[0] < arr.shape[1] and arr.shape[0] <= 100:
        arr = arr.T

    return arr


def detect_garbage_objects(roi: np.ndarray) -> List[Dict[str, Any]]:
    if garbage_net is None or roi is None or roi.size == 0:
        return []

    roi_h, roi_w = roi.shape[:2]
    roi_area = float(max(roi_h * roi_w, 1))

    min_box_area = max(
        int(GARBAGE_MIN_BOX_AREA_PX),
        int(roi_area * GARBAGE_MIN_BOX_AREA_RATIO)
    )
    min_box_w = max(18, int(roi_w * GARBAGE_MIN_BOX_WIDTH_RATIO))
    min_box_h = max(18, int(roi_h * GARBAGE_MIN_BOX_HEIGHT_RATIO))

    blob = cv2.dnn.blobFromImage(
        roi,
        scalefactor=1.0 / 255.0,
        size=(GARBAGE_OBJ_INPUT_SIZE, GARBAGE_OBJ_INPUT_SIZE),
        swapRB=True,
        crop=False
    )

    garbage_net.setInput(blob)

    if garbage_output_names:
        raw_outputs = garbage_net.forward(garbage_output_names)
    else:
        raw_outputs = garbage_net.forward()

    data = _normalize_yolo_output(raw_outputs)
    if data.size == 0:
        return []

    boxes_xywh: List[List[int]] = []
    confidences: List[float] = []
    class_ids: List[int] = []

    for row in data:
        row = np.asarray(row).reshape(-1)

        if row.shape[0] < 6:
            continue

        if row.shape[0] == 84:
            class_scores = row[4:]
            if class_scores.size == 0:
                continue

            class_id = int(np.argmax(class_scores))
            conf = float(class_scores[class_id])
        else:
            obj_conf = float(row[4])
            class_scores = row[5:]
            if class_scores.size == 0:
                continue

            class_id = int(np.argmax(class_scores))
            class_conf = float(class_scores[class_id])
            conf = obj_conf * class_conf

        if conf < GARBAGE_OBJ_CONF:
            continue

        cx = float(row[0])
        cy = float(row[1])
        bw = float(row[2])
        bh = float(row[3])

        if 0.0 <= cx <= 1.5 and 0.0 <= cy <= 1.5 and 0.0 <= bw <= 1.5 and 0.0 <= bh <= 1.5:
            cx *= roi_w
            cy *= roi_h
            bw *= roi_w
            bh *= roi_h

        x = int(cx - (bw / 2.0))
        y = int(cy - (bh / 2.0))
        w = int(bw)
        h = int(bh)

        x = max(0, x)
        y = max(0, y)
        w = min(w, roi_w - x)
        h = min(h, roi_h - y)

        if w <= 0 or h <= 0:
            continue

        box_area = w * h
        if box_area < min_box_area:
            continue
        if w < min_box_w or h < min_box_h:
            continue
        if (box_area / roi_area) > GARBAGE_MAX_BOX_AREA_RATIO:
            continue

        cx_box = x + (w // 2)
        cy_box = y + (h // 2)
        excluded = False
        for rx1, ry1, rx2, ry2 in GARBAGE_EXCLUSION_ZONES:
            ex1 = int(roi_w * rx1)
            ey1 = int(roi_h * ry1)
            ex2 = int(roi_w * rx2)
            ey2 = int(roi_h * ry2)
            if ex1 <= cx_box <= ex2 and ey1 <= cy_box <= ey2:
                excluded = True
                break
        if excluded:
            continue

        boxes_xywh.append([x, y, w, h])
        confidences.append(conf)
        class_ids.append(class_id)

    if not boxes_xywh:
        return []

    idxs = cv2.dnn.NMSBoxes(
        boxes_xywh,
        confidences,
        GARBAGE_OBJ_CONF,
        GARBAGE_OBJ_NMS
    )
    if idxs is None or len(idxs) == 0:
        return []

    coco_labels = [
        "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
        "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
        "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
        "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
        "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
        "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
        "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
        "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"
    ]

    detections: List[Dict[str, Any]] = []

    for idx in np.array(idxs).reshape(-1):
        class_id = int(class_ids[idx])
        if class_id < 0 or class_id >= len(coco_labels):
            continue

        label = coco_labels[class_id]
        if label not in GARBAGE_TARGET_LABELS:
            continue

        x, y, w, h = boxes_xywh[idx]
        detections.append({
            "label": label,
            "display_label": get_garbage_label_display(label),
            "confidence": round(float(confidences[idx]), 4),
            "box": (x, y, x + w, y + h)
        })

    return dedupe_garbage_detections(detections, iou_threshold=0.40)


def save_capture(frame: np.ndarray, filename: str, garbage: bool = False) -> Tuple[str, Path]:
    folder = GARBAGE_DIR if garbage else FILES_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / filename

    if frame is None or frame.size == 0:
        raise RuntimeError(f"Cannot save empty frame: {filename}")

    jpeg_quality = FULL_RES_IMAGE_JPEG_QUALITY if not garbage else 90
    ok = cv2.imwrite(str(path), frame, [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality])
    if not ok:
        raise RuntimeError(f"Failed to save image: {path}")

    if not path.exists():
        raise RuntimeError(f"Saved image missing after write: {path}")

    size = path.stat().st_size
    if size <= 1024:
        raise RuntimeError(f"Saved image is too small/empty: {path}, size={size}")

    verify_img = cv2.imread(str(path))
    if verify_img is None or verify_img.size == 0:
        raise RuntimeError(f"Saved image cannot be read back: {path}, size={size}")

    rel = f"garbage/{filename}" if garbage else filename
    return rel, path


def sanitize_filename_part(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", str(value).strip())
    cleaned = re.sub(r"-{2,}", "-", cleaned).strip("-")
    return cleaned or "NA"


def build_person_video_name(event_time: dt.datetime) -> str:
    device_part = sanitize_filename_part(DEVICE_ID)
    suffix_part = sanitize_filename_part(PERSON_VIDEO_SUFFIX)
    return (
        f"{device_part}-Person_"
        f"{event_time.strftime('%Y%m%d_%H%M%S')}_"
        f"{suffix_part}.{PERSON_VIDEO_EXTENSION}"
    )


last_rolling_buffer_ts = 0.0


def add_frame_to_rolling_buffer(frame: np.ndarray, frame_ts: float) -> None:
    global last_rolling_buffer_ts

    if frame is None or frame.size == 0:
        return

    min_gap = 1.0 / max(ROLLING_BUFFER_TARGET_FPS, 1.0)
    if (frame_ts - last_rolling_buffer_ts) < min_gap:
        return

    last_rolling_buffer_ts = frame_ts

    # Keep event buffer at EVENT_FRAME_WIDTH.
    # This improves person/vehicle video quality on 4GB Pi 5.
    # Detection remains unchanged because detector_loop still uses latest_frame.
    event_frame = resize_frame_to_width(frame, EVENT_FRAME_WIDTH)

    ok, jpg = cv2.imencode(
        ".jpg",
        event_frame,
        [int(cv2.IMWRITE_JPEG_QUALITY), EVENT_BUFFER_JPEG_QUALITY]
    )
    if not ok:
        return

    jpg_bytes = jpg.tobytes()

    with rolling_video_lock:
        rolling_video_buffer.append((frame_ts, jpg_bytes))

        cutoff_ts = frame_ts - EVENT_ROLLING_BUFFER_SEC
        while rolling_video_buffer and rolling_video_buffer[0][0] < cutoff_ts:
            rolling_video_buffer.popleft()


def get_buffered_clip_items(start_ts: float, end_ts: float) -> List[Tuple[float, bytes]]:
    with rolling_video_lock:
        return [
            (ts, jpg_bytes)
            for ts, jpg_bytes in rolling_video_buffer
            if start_ts <= ts <= end_ts
        ]


def estimate_clip_fps(items: List[Tuple[float, bytes]]) -> float:
    if len(items) < 2:
        return EVENT_DEFAULT_FPS

    duration = items[-1][0] - items[0][0]
    if duration <= 0:
        return EVENT_DEFAULT_FPS

    fps = len(items) / duration
    fps = max(EVENT_MIN_FPS, min(EVENT_MAX_FPS, fps))
    return float(fps)


def transcode_video_to_h264_mp4(input_path: Path, output_path: Path, fps: float) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-i", str(input_path),
        "-an",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-preset", EVENT_VIDEO_H264_PRESET,
        "-crf", str(EVENT_VIDEO_H264_CRF),
        "-movflags", "+faststart",
        "-r", f"{fps:.3f}",
        str(output_path),
    ]

    proc = subprocess.run(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        timeout=180
    )

    if proc.returncode != 0:
        raise RuntimeError(f"FFmpeg H.264 transcode failed: {proc.stderr.strip()[:800]}")

    if not output_path.exists() or output_path.stat().st_size <= 0:
        raise RuntimeError("H.264 output file missing or empty after transcode")


def write_buffered_event_video(
    output_path: Path,
    event_ts: float,
    pre_sec: int = EVENT_PRE_RECORD_SEC,
    post_sec: int = EVENT_POST_RECORD_SEC
) -> float:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    clip_start_ts = event_ts - pre_sec
    clip_end_ts = event_ts + post_sec

    wait_sec = clip_end_ts - time.time()
    if wait_sec > 0:
        time.sleep(wait_sec)

    items = get_buffered_clip_items(clip_start_ts, clip_end_ts)
    if len(items) < 2:
        raise RuntimeError("Not enough buffered frames available for event clip")

    first_frame = cv2.imdecode(
        np.frombuffer(items[0][1], dtype=np.uint8),
        cv2.IMREAD_COLOR
    )
    if first_frame is None:
        raise RuntimeError("Failed to decode first buffered frame")

    height, width = first_frame.shape[:2]
    fps = estimate_clip_fps(items)

    temp_output_path = output_path.with_suffix(f".{EVENT_TEMP_VIDEO_EXTENSION}")
    if temp_output_path.exists():
        temp_output_path.unlink()

    if output_path.exists():
        output_path.unlink()

    fourcc = cv2.VideoWriter_fourcc(*"MJPG")
    writer = cv2.VideoWriter(str(temp_output_path), fourcc, fps, (width, height))
    if not writer.isOpened():
        raise RuntimeError(f"Failed to open temporary video writer for {temp_output_path}")

    written = 0
    try:
        for _, jpg_bytes in items:
            frame = cv2.imdecode(
                np.frombuffer(jpg_bytes, dtype=np.uint8),
                cv2.IMREAD_COLOR
            )
            if frame is None:
                continue

            if frame.shape[1] != width or frame.shape[0] != height:
                frame = cv2.resize(frame, (width, height))

            writer.write(frame)
            written += 1
    finally:
        writer.release()

    if written < 2 or not temp_output_path.exists() or temp_output_path.stat().st_size <= 0:
        if temp_output_path.exists():
            temp_output_path.unlink()
        raise RuntimeError("Temporary buffered event video write failed")

    try:
        transcode_video_to_h264_mp4(temp_output_path, output_path, fps)
    finally:
        if temp_output_path.exists():
            temp_output_path.unlink()

    if not output_path.exists() or output_path.stat().st_size <= 0:
        raise RuntimeError("Final H.264 MP4 file missing or empty")

    return round(max(0.0, items[-1][0] - items[0][0]), 2)


def async_upload_person_video(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    event_time: dt.datetime,
    person_count: int,
    best_confidence: float,
    image_file: str,
    image_path: str
) -> None:
    def worker():
        remote_path = f"{remote_dir.rstrip('/')}/{remote_name}"
        response_payload = {
            "date": event_time.strftime("%Y-%m-%d"),
            "time": event_time.strftime("%H:%M:%S"),
            "event": "person_detected",
            "device_id": DEVICE_ID,
            "image_file": image_file,
            "video_file": remote_name,
            "image_path": image_path,
            "video_path": remote_path,
            "camera_name": CAMERA_NAME,
            "duration_sec": PERSON_VIDEO_DURATION_SEC,
            "person_count": person_count,
            "video_status": "success",
            "video_message": "Video Uploaded Successfully",
            "best_confidence": best_confidence,
            "video_uploaded_at": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
            **build_common_links_payload(),
        }

        try:
            sftp_upload(local_path, remote_dir, remote_name)

            deleted_local = False
            delete_error = None
            try:
                if local_path.exists():
                    local_path.unlink()
                    deleted_local = True
            except Exception as exc:
                delete_error = str(exc)

            response_payload.update({
                "local_deleted": deleted_local,
                "local_delete_error": delete_error,
            })

            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None,
            }))
            update_state(lambda s: s.update({
                "last_video": {
                    "file": remote_name,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "status": "uploaded_deleted_local" if deleted_local else "uploaded_delete_failed",
                    "duration_sec": PERSON_VIDEO_DURATION_SEC,
                    "person_count": person_count,
                    "best_confidence": best_confidence,
                }
            }))
            add_event("person_video_uploaded", {
                "file": remote_name,
                "image_file": image_file,
                "image_path": image_path,
                "duration_sec": PERSON_VIDEO_DURATION_SEC,
                "person_count": person_count,
                "best_confidence": best_confidence,
                "local_deleted": deleted_local,
                "local_delete_error": delete_error,
            })

            time.sleep(1)
            mqtt_publish(MQTT_CAMERA_EVENT_TOPIC, response_payload)
            update_state(lambda s: s["system"].update({
                "mqtt_last_ok": now_str(),
                "mqtt_last_error": None,
            }))

        except Exception as exc:
            error_text = str(exc).strip() or repr(exc)

            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="person_video",
                delete_local_on_success=True,
                mqtt_topic=MQTT_CAMERA_EVENT_TOPIC,
                mqtt_payload=response_payload,
                metadata={
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "duration_sec": PERSON_VIDEO_DURATION_SEC,
                    "person_count": person_count,
                    "best_confidence": best_confidence,
                    "image_file": image_file,
                    "image_path": image_path,
                },
            )

            update_state(lambda s: s["system"].update({
                "sftp_last_error": error_text,
            }))
            update_state(lambda s: s.update({
                "last_video": {
                    "file": remote_name,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "status": f"upload_failed_queued_retry: {error_text}",
                    "duration_sec": PERSON_VIDEO_DURATION_SEC,
                    "person_count": person_count,
                    "best_confidence": best_confidence,
                }
            }))
            add_event("person_video_upload_failed_queued", {
                "file": remote_name,
                "video_path": remote_path,
                "error": error_text,
            })

    threading.Thread(target=worker, daemon=True).start()

VOLUME_COMMAND_PREFIX = "pi volume"
CURRENT_VOLUME_COMMAND = "current pi volume"

# Preferred playback controls in order
VOLUME_CONTROL_CANDIDATES = (
    "Speaker",
    "Master",
    "Headphone",
    "PCM",
    "Digital",
)

# Optional manual override. Set to an int like 0 if you want to force a card.
USB_AUDIO_CARD_INDEX: Optional[int] = None


def extract_volume_percent(command_text: str) -> Optional[int]:
    raw = str(command_text or "").strip()
    match = re.fullmatch(r"pi\s+volume\s+(\d{1,3})\s*%", raw, flags=re.IGNORECASE)
    if not match:
        return None

    value = int(match.group(1))
    if value < 0 or value > 100:
        return None

    return value


def extract_current_volume_percent(amixer_output: str) -> Optional[int]:
    """
    Parse amixer output like:
      Front Left: Playback 48 [75%] [-16.50dB] [on]
    and return 75
    """
    if not amixer_output:
        return None

    match = re.search(r"\[(\d{1,3})%\]", amixer_output)
    if not match:
        return None

    value = int(match.group(1))
    return max(0, min(100, value))


def run_amixer(args: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["amixer", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )


def list_alsa_cards() -> List[Tuple[int, str]]:
    """
    Parse `aplay -l` and return [(card_index, card_name), ...]
    Example line:
      card 0: Device [USB PnP Sound Device], device 0: USB Audio [USB Audio]
    """
    try:
        proc = subprocess.run(
            ["aplay", "-l"],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
    except Exception:
        return []

    cards: List[Tuple[int, str]] = []
    for line in proc.stdout.splitlines():
        match = re.search(r"card\s+(\d+):\s*([^\[]+)", line, flags=re.IGNORECASE)
        if match:
            card_index = int(match.group(1))
            card_name = match.group(2).strip()
            cards.append((card_index, card_name))
    return cards


def list_card_controls(card_index: int) -> List[str]:
    try:
        proc = run_amixer(["-c", str(card_index), "scontrols"])
    except Exception:
        return []

    controls: List[str] = []
    for line in proc.stdout.splitlines():
        match = re.search(r"Simple mixer control '([^']+)'", line)
        if match:
            controls.append(match.group(1))
    return controls


def detect_volume_card_index() -> int:
    """
    Find the most likely playback card.
    Priority:
    1. Explicit override
    2. USB audio card
    3. First card exposing a known playback control
    4. Fallback to card 0
    """
    if USB_AUDIO_CARD_INDEX is not None:
        return int(USB_AUDIO_CARD_INDEX)

    cards = list_alsa_cards()
    if not cards:
        return 0

    # Prefer USB card first
    for card_index, card_name in cards:
        name = card_name.lower()
        if "usb" in name or "sound device" in name or "audio" in name:
            controls = list_card_controls(card_index)
            if any(control in controls for control in VOLUME_CONTROL_CANDIDATES):
                return card_index

    # Otherwise return first card having a usable playback control
    for card_index, _card_name in cards:
        controls = list_card_controls(card_index)
        if any(control in controls for control in VOLUME_CONTROL_CANDIDATES):
            return card_index

    return 0


def detect_volume_control(card_index: int) -> Tuple[str, List[str]]:
    controls = list_card_controls(card_index)
    if not controls:
        raise RuntimeError(f"No mixer controls found on ALSA card {card_index}")

    for control_name in VOLUME_CONTROL_CANDIDATES:
        if control_name in controls:
            return control_name, controls

    raise RuntimeError(
        f"No supported playback control found on ALSA card {card_index}. "
        f"Available controls: {', '.join(controls)}"
    )


def get_current_pi_volume() -> Dict[str, Any]:
    card_index = detect_volume_card_index()
    control_name, available_controls = detect_volume_control(card_index)

    proc = run_amixer(["-c", str(card_index), "get", control_name])
    volume_percent = extract_current_volume_percent(proc.stdout)

    if volume_percent is None:
        raise RuntimeError(
            f"Unable to parse current volume from ALSA card {card_index}, control '{control_name}'"
        )

    return {
        "volume_percent": volume_percent,
        "card_index": card_index,
        "control": control_name,
        "checked_controls": list(VOLUME_CONTROL_CANDIDATES),
        "available_controls": available_controls,
        "failed_controls": [c for c in VOLUME_CONTROL_CANDIDATES if c != control_name]
    }


def set_pi_volume(percent: int) -> Dict[str, Any]:
    percent = max(0, min(100, int(percent)))

    card_index = detect_volume_card_index()
    control_name, available_controls = detect_volume_control(card_index)

    run_amixer(["-c", str(card_index), "set", control_name, f"{percent}%"])

    verify_proc = run_amixer(["-c", str(card_index), "get", control_name])
    verified_percent = extract_current_volume_percent(verify_proc.stdout)
    if verified_percent is None:
        verified_percent = percent

    return {
        "volume_percent": verified_percent,
        "requested_volume_percent": percent,
        "card_index": card_index,
        "updated_controls": [control_name],
        "control": control_name,
        "available_controls": available_controls,
        "failed_controls": [c for c in VOLUME_CONTROL_CANDIDATES if c != control_name]
    }


def handle_pi_volume_command(payload: Dict[str, Any]) -> None:
    command_text = str(payload.get("command", "")).strip()
    volume_percent = extract_volume_percent(command_text)

    if volume_percent is None:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "pi_volume_set_failed",
            "message": "Command format: Pi Volume 10% to Pi Volume 100%"
        })
        return

    try:
        result = set_pi_volume(volume_percent)

        update_state(lambda s: s.update({
            "last_audio": {
                "file": None,
                "source_path": None,
                "time": now_str(),
                "status": f"pi_volume_set_to_{result['volume_percent']}%"
            }
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "pi_volume_set",
            "volume_percent": result["volume_percent"],
            "requested_volume_percent": result["requested_volume_percent"],
            "card_index": result["card_index"],
            "control": result["control"],
            "updated_controls": result["updated_controls"],
            "available_controls": result["available_controls"],
            "failed_controls": result["failed_controls"],
            "message": (
                f"Pi volume set to {result['volume_percent']}% "
                f"using ALSA card {result['card_index']} control '{result['control']}'"
            )
        })

        add_event("pi_volume_set", {
            "volume_percent": result["volume_percent"],
            "updated_controls": result["updated_controls"],
            "failed_controls": result["failed_controls"]
        })

    except Exception as exc:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "pi_volume_set_failed",
            "volume_percent": volume_percent,
            "message": str(exc)
        })

        add_event("pi_volume_set_failed", {
            "volume_percent": volume_percent,
            "message": str(exc)
        })

def handle_current_pi_volume_command(payload: Dict[str, Any]) -> None:
    try:
        result = get_current_pi_volume()

        update_state(lambda s: s.update({
            "last_audio": {
                "file": None,
                "source_path": None,
                "time": now_str(),
                "status": f"current_pi_volume_{result['volume_percent']}%"
            }
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "current_pi_volume",
            "volume_percent": result["volume_percent"],
            "card_index": result["card_index"],
            "control": result["control"],
            "checked_controls": result["checked_controls"],
            "available_controls": result["available_controls"],
            "failed_controls": result["failed_controls"],
            "message": (
                f"Current Pi volume is {result['volume_percent']}% "
                f"on ALSA card {result['card_index']} control '{result['control']}'"
            )
        })

        add_event("current_pi_volume", {
            "volume_percent": result["volume_percent"],
            "control": result["control"],
            "checked_controls": result["checked_controls"],
            "failed_controls": result["failed_controls"]
        })

    except Exception as exc:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "current_pi_volume_failed",
            "message": str(exc)
        })

        add_event("current_pi_volume_failed", {
            "message": str(exc)
        })


def handle_person_video_event(
    event_time: dt.datetime,
    event_ts: float,
    person_count: int,
    best_confidence: float,
    image_file: str,
    image_path: str
) -> None:
    video_name = build_person_video_name(event_time)
    local_video_path = VIDEO_DIR / video_name

    update_state(lambda s: s.update({
        "last_video": {
            "file": video_name,
            "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
            "status": "buffering_post_event",
            "duration_sec": PERSON_VIDEO_DURATION_SEC,
            "person_count": person_count,
            "best_confidence": best_confidence,
        }
    }))

    try:
        actual_duration_sec = write_buffered_event_video(
            output_path=local_video_path,
            event_ts=event_ts,
            pre_sec=EVENT_PRE_RECORD_SEC,
            post_sec=EVENT_POST_RECORD_SEC,
        )

        update_state(lambda s: s.update({
            "last_video": {
                "file": video_name,
                "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "recorded",
                "duration_sec": actual_duration_sec,
                "person_count": person_count,
                "best_confidence": best_confidence,
            }
        }))

        async_upload_person_video(
            local_path=local_video_path,
            remote_dir=SFTP_PERSON_VIDEO_DIR,
            remote_name=video_name,
            event_time=event_time,
            person_count=person_count,
            best_confidence=best_confidence,
            image_file=image_file,
            image_path=image_path,
        )

    except Exception as video_exc:
        error_text = str(video_exc).strip() or repr(video_exc)

        update_state(lambda s: s.update({
            "last_video": {
                "file": video_name,
                "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": f"record_failed: {error_text}",
                "duration_sec": PERSON_VIDEO_DURATION_SEC,
                "person_count": person_count,
                "best_confidence": best_confidence,
            }
        }))

        try:
            mqtt_publish(MQTT_CAMERA_EVENT_TOPIC, {
                "date": event_time.strftime("%Y-%m-%d"),
                "time": event_time.strftime("%H:%M:%S"),
                "event": "person_detected",
                "device_id": DEVICE_ID,
                "image_file": image_file,
                "video_file": video_name,
                "image_path": image_path,
                "video_path": f"{SFTP_PERSON_VIDEO_DIR.rstrip('/')}/{video_name}",
                "camera_name": CAMERA_NAME,
                "duration_sec": PERSON_VIDEO_DURATION_SEC,
                "person_count": person_count,
                "video_status": "failed",
                "video_message": f"Video record failed: {error_text}",
                "best_confidence": best_confidence,
                "video_uploaded_at": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
                **build_common_links_payload(),
            })
        except Exception as mqtt_exc:
            update_state(lambda s: s["system"].update({
                "mqtt_last_error": str(mqtt_exc),
            }))

def open_rtsp() -> cv2.VideoCapture:
    # SUB stream: AI detection + local live view.
    cap = cv2.VideoCapture(DETECTION_RTSP_URL, cv2.CAP_FFMPEG)

    # Keep RTSP latency low.
    # For RTSP cameras these width/height settings may be ignored by camera,
    # but they do not harm. Actual resolution usually comes from RTSP URL/profile.
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    try:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, LIVE_FRAME_WIDTH)
    except Exception:
        pass

    return cap


def open_main_rtsp() -> cv2.VideoCapture:
    # MAIN stream: high-quality SFTP image/video upload buffer only.
    cap = cv2.VideoCapture(MAIN_RTSP_URL, cv2.CAP_FFMPEG)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    return cap


def open_cloudflare_live_rtsp() -> cv2.VideoCapture:
    cap = cv2.VideoCapture(CLOUDFLARE_LIVE_RTSP_URL, cv2.CAP_FFMPEG)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    return cap


def mjpeg_stream_from_rtsp(
    rtsp_url: str,
    frame_width: int = CLOUDFLARE_LIVE_FRAME_WIDTH,
    jpeg_quality: int = CLOUDFLARE_MJPEG_QUALITY,
    target_fps: float = CLOUDFLARE_STREAM_TARGET_FPS
):
    cap: Optional[cv2.VideoCapture] = None
    min_gap = 1.0 / max(float(target_fps), 1.0)

    try:
        while not stop_event.is_set():
            loop_started = time.time()

            if is_power_saving_active():
                if cap is not None:
                    try:
                        cap.release()
                    except Exception:
                        pass
                    cap = None
                time.sleep(1)
                continue

            if cap is None or not cap.isOpened():
                cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

                if not cap.isOpened():
                    time.sleep(1.5)
                    continue

            ok, frame = cap.read()
            if not ok or frame is None:
                try:
                    cap.release()
                except Exception:
                    pass
                cap = None
                time.sleep(0.5)
                continue

            frame = resize_frame_to_width(frame, frame_width)

            ok, jpg = cv2.imencode(
                ".jpg",
                frame,
                [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality]
            )

            if ok:
                yield (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n"
                    b"Cache-Control: no-cache, no-store, must-revalidate\r\n"
                    b"Pragma: no-cache\r\n"
                    b"Expires: 0\r\n\r\n" + jpg.tobytes() + b"\r\n"
                )

            elapsed = time.time() - loop_started
            sleep_left = min_gap - elapsed
            if sleep_left > 0:
                time.sleep(sleep_left)

    finally:
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass

def enhance_for_person_detection(frame: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8))
    l2 = clahe.apply(l)
    out = cv2.merge((l2, a, b))
    return cv2.cvtColor(out, cv2.COLOR_LAB2BGR)


def detect_persons_single_pass(frame: np.ndarray, scale_tag: str, min_conf: float) -> List[Dict[str, Any]]:
    if person_net is None:
        return []

    h, w = frame.shape[:2]
    inp = cv2.resize(frame, (300, 300))
    blob = cv2.dnn.blobFromImage(inp, 0.007843, (300, 300), 127.5)

    with person_dnn_lock:
        person_net.setInput(blob)
        detections = person_net.forward()

    results: List[Dict[str, Any]] = []
    for i in range(detections.shape[2]):
        conf = float(detections[0, 0, i, 2])
        if conf < max(min_conf, PERSON_CONF):
            continue

        cls_idx = int(detections[0, 0, i, 1])
        if cls_idx < 0 or cls_idx >= len(MOBILENET_CLASSES):
            continue
        if MOBILENET_CLASSES[cls_idx] != "person":
            continue

        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        x1, y1, x2, y2 = box.astype("int")
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(w - 1, x2)
        y2 = min(h - 1, y2)

        if x2 <= x1 or y2 <= y1:
            continue

        area = (x2 - x1) * (y2 - y1)
        if area < PERSON_MIN_AREA:
            continue

        bw = x2 - x1
        bh = y2 - y1
        aspect_ratio = bh / max(bw, 1)
        if aspect_ratio < PERSON_MIN_ASPECT_RATIO:
            continue

        results.append({
            "label": "person",
            "confidence": conf,
            "box": (x1, y1, x2, y2),
            "scale_tag": scale_tag
        })

    return results


def upscale_and_detect(frame: np.ndarray, factor: float, min_conf: float, scale_tag: str = "upscaled") -> List[Dict[str, Any]]:
    h, w = frame.shape[:2]
    up = cv2.resize(frame, (int(w * factor), int(h * factor)), interpolation=cv2.INTER_CUBIC)
    raw = detect_persons_single_pass(up, scale_tag, min_conf)

    mapped: List[Dict[str, Any]] = []
    for d in raw:
        x1, y1, x2, y2 = d["box"]
        x1 = int(x1 / factor)
        y1 = int(y1 / factor)
        x2 = int(x2 / factor)
        y2 = int(y2 / factor)
        x1 = max(0, min(w - 1, x1))
        y1 = max(0, min(h - 1, y1))
        x2 = max(0, min(w - 1, x2))
        y2 = max(0, min(h - 1, y2))
        if x2 <= x1 or y2 <= y1:
            continue
        mapped.append({
            "label": "person",
            "confidence": d["confidence"],
            "box": (x1, y1, x2, y2),
            "scale_tag": scale_tag
        })
    return mapped


def detect_persons_tiled(frame: np.ndarray) -> List[Dict[str, Any]]:
    h, w = frame.shape[:2]
    tile_w = max(320, min(420, int(w * 0.42)))
    tile_h = max(240, min(340, int(h * 0.48)))
    step_x = max(90, int(tile_w * PERSON_TILE_STEP_RATIO))
    step_y = max(70, int(tile_h * PERSON_TILE_STEP_RATIO))

    detections: List[Dict[str, Any]] = []
    y_limit = max(tile_h, int(h * 0.82))

    for y in range(0, max(1, y_limit - tile_h + 1), step_y):
        for x in range(0, max(1, w - tile_w + 1), step_x):
            tile = frame[y:y + tile_h, x:x + tile_w]
            if tile.size == 0:
                continue

            tile_up = cv2.resize(
                tile,
                (int(tile.shape[1] * 1.35), int(tile.shape[0] * 1.35)),
                interpolation=cv2.INTER_CUBIC
            )
            tile_dets = detect_persons_single_pass(tile_up, "tile", PERSON_TILE_MIN_CONF)

            for d in tile_dets:
                x1, y1, x2, y2 = d["box"]
                x1 = int(x + (x1 / 1.35))
                y1 = int(y + (y1 / 1.35))
                x2 = int(x + (x2 / 1.35))
                y2 = int(y + (y2 / 1.35))
                x1 = max(0, min(w - 1, x1))
                y1 = max(0, min(h - 1, y1))
                x2 = max(0, min(w - 1, x2))
                y2 = max(0, min(h - 1, y2))
                if x2 <= x1 or y2 <= y1:
                    continue
                if (x2 - x1) * (y2 - y1) < PERSON_MIN_AREA:
                    continue
                detections.append({
                    "label": "person",
                    "confidence": float(d["confidence"]),
                    "box": (x1, y1, x2, y2),
                    "scale_tag": "tile"
                })

    return detections


def detect_persons_hog(frame: np.ndarray) -> List[Dict[str, Any]]:
    if not PERSON_HOG_ENABLE or hog_detector is None:
        return []

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    rects, weights = hog_detector.detectMultiScale(
        gray,
        winStride=(4, 4),
        padding=(8, 8),
        scale=1.03
    )

    out: List[Dict[str, Any]] = []
    for (x, y, w, h), score in zip(rects, weights):
        if w * h < 500:
            continue
        out.append({
            "label": "person",
            "confidence": float(min(0.90, 0.30 + float(score) / 5.0)),
            "box": (int(x), int(y), int(x + w), int(y + h)),
            "scale_tag": "hog"
        })
    return out


def nms_merge_persons(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not candidates:
        return []

    boxes = []
    scores = []
    for d in candidates:
        x1, y1, x2, y2 = d["box"]
        boxes.append([x1, y1, max(1, x2 - x1), max(1, y2 - y1)])
        scores.append(float(d["confidence"]))

    kept = cv2.dnn.NMSBoxes(boxes, scores, 0.22, PERSON_NMS_THRESHOLD)
    if kept is None or len(kept) == 0:
        return []

    out: List[Dict[str, Any]] = []
    for idx in kept:
        i = int(idx[0] if isinstance(idx, (list, tuple, np.ndarray)) else idx)
        out.append(candidates[i])

    out.sort(key=lambda item: item["confidence"], reverse=True)
    return out


def _crop_box_with_padding(
    frame: np.ndarray,
    box: Tuple[int, int, int, int],
    pad_ratio: float = 0.03
) -> np.ndarray:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box
    bw = max(1, x2 - x1)
    bh = max(1, y2 - y1)
    pad_x = int(bw * pad_ratio)
    pad_y = int(bh * pad_ratio)

    cx1 = max(0, x1 - pad_x)
    cy1 = max(0, y1 - pad_y)
    cx2 = min(w - 1, x2 + pad_x)
    cy2 = min(h - 1, y2 + pad_y)

    if cx2 <= cx1 or cy2 <= cy1:
        return frame[0:0, 0:0]

    return frame[cy1:cy2, cx1:cx2]


def _box_area_xyxy(box: Tuple[int, int, int, int]) -> int:
    x1, y1, x2, y2 = box
    return max(0, x2 - x1) * max(0, y2 - y1)


def _box_intersection_area_xyxy(
    a: Tuple[int, int, int, int],
    b: Tuple[int, int, int, int]
) -> int:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    return max(0, ix2 - ix1) * max(0, iy2 - iy1)


def detect_mobilenet_labels_single_pass(
    frame: np.ndarray,
    labels: set,
    min_conf: float,
    scale_tag: str = "normal"
) -> List[Dict[str, Any]]:
    if person_net is None or frame is None or frame.size == 0:
        return []

    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(
        cv2.resize(frame, (300, 300)),
        scalefactor=0.007843,
        size=(300, 300),
        mean=127.5
    )

    with person_dnn_lock:
        person_net.setInput(blob)
        detections = person_net.forward()

    wanted = {str(label).strip().lower() for label in labels}
    results: List[Dict[str, Any]] = []

    for i in range(detections.shape[2]):
        conf = float(detections[0, 0, i, 2])
        if conf < min_conf:
            continue

        cls_idx = int(detections[0, 0, i, 1])
        if cls_idx < 0 or cls_idx >= len(MOBILENET_CLASSES):
            continue

        label = MOBILENET_CLASSES[cls_idx]
        if label not in wanted:
            continue

        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        x1, y1, x2, y2 = box.astype("int").tolist()
        x1 = max(0, min(w - 1, x1))
        y1 = max(0, min(h - 1, y1))
        x2 = max(0, min(w - 1, x2))
        y2 = max(0, min(h - 1, y2))

        if x2 <= x1 or y2 <= y1:
            continue

        results.append({
            "label": label,
            "confidence": round(conf, 4),
            "box": (x1, y1, x2, y2),
            "scale_tag": scale_tag,
        })

    return results


def detect_person_suppression_animals(frame: np.ndarray) -> List[Dict[str, Any]]:
    return detect_mobilenet_labels_single_pass(
        frame,
        PERSON_FALSE_POSITIVE_ANIMAL_CLASSES,
        PERSON_ANIMAL_SUPPRESSION_CONF,
        "animal_suppression"
    )


def person_overlaps_suppression_animal(
    person_box: Tuple[int, int, int, int],
    animal_detections: List[Dict[str, Any]]
) -> bool:
    person_area = max(1, _box_area_xyxy(person_box))

    for animal in animal_detections or []:
        animal_box = tuple(animal.get("box", (0, 0, 0, 0)))
        animal_area = max(1, _box_area_xyxy(animal_box))
        inter = _box_intersection_area_xyxy(person_box, animal_box)
        if inter <= 0:
            continue

        iou = box_iou_xyxy(person_box, animal_box)
        person_overlap = float(inter) / float(person_area)
        animal_overlap = float(inter) / float(animal_area)

        if iou >= PERSON_ANIMAL_SUPPRESSION_IOU:
            return True

        if person_overlap >= PERSON_ANIMAL_SUPPRESSION_PERSON_OVERLAP:
            return True

        # If the animal is mostly inside the person box, it is almost always
        # the dog/cat false-positive case reported in field testing.
        if animal_overlap >= 0.55:
            return True

    return False


def is_whiteboard_like_person_false_positive(
    frame: np.ndarray,
    box: Tuple[int, int, int, int],
    confidence: float
) -> bool:
    if confidence < PERSON_WHITEBOARD_MIN_CONF:
        return False

    patch = _crop_box_with_padding(frame, box, pad_ratio=0.01)
    if patch is None or patch.size == 0:
        return False

    ph, pw = patch.shape[:2]
    if ph < 20 or pw < 10:
        return False

    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
    s = hsv[:, :, 1]
    v = hsv[:, :, 2]

    bright_low_sat = np.logical_and(v > 150, s < 55)
    full_bright_low_sat_ratio = float(np.count_nonzero(bright_low_sat)) / float(max(bright_low_sat.size, 1))
    full_dark_ratio = float(np.count_nonzero(v < 65)) / float(max(v.size, 1))

    top_h = max(8, ph // 3)
    top_s = s[:top_h, :]
    top_v = v[:top_h, :]
    top_bright_low_sat = np.logical_and(top_v > 150, top_s < 55)
    top_bright_low_sat_ratio = float(np.count_nonzero(top_bright_low_sat)) / float(max(top_bright_low_sat.size, 1))
    top_dark_ratio = float(np.count_nonzero(top_v < 65)) / float(max(top_v.size, 1))
    top_sat_mean = float(top_s.mean())

    # Whiteboards/windows/wall panels: upper area is almost completely bright
    # and unsaturated, with no dark head/hair region. A real person normally
    # has visible hair/face/cloth boundaries in the top third of the box.
    if (
        full_bright_low_sat_ratio >= PERSON_WHITEBOARD_FULL_BRIGHT_LOW_SAT_RATIO and
        full_dark_ratio <= PERSON_WHITEBOARD_FULL_DARK_RATIO_MAX and
        top_bright_low_sat_ratio >= PERSON_WHITEBOARD_TOP_BRIGHT_LOW_SAT_RATIO and
        top_dark_ratio <= PERSON_WHITEBOARD_TOP_DARK_RATIO_MAX and
        top_sat_mean <= PERSON_WHITEBOARD_TOP_SAT_MEAN_MAX
    ):
        return True

    return False


def person_patch_allowed(
    frame: np.ndarray,
    box: Tuple[int, int, int, int],
    confidence: float
) -> bool:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box
    bw = x2 - x1
    bh = y2 - y1
    aspect_ratio = bh / max(bw, 1)

    patch = _crop_box_with_padding(frame, box)
    if patch is None or patch.size == 0:
        return False

    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)

    variance = float(gray.var())
    saturation_mean = float(hsv[:, :, 1].mean())

    edges = cv2.Canny(gray, 50, 140)
    edge_density = float(np.count_nonzero(edges)) / float(max(edges.size, 1))

    # Reject plain vertical stone / plain pole / plain wall-like object.
    if variance < PERSON_MIN_TEXTURE_VARIANCE and saturation_mean < 22.0 and confidence < 0.88:
        return False

    # Reject very thin high-aspect pole/tree/barricade shapes.
    if aspect_ratio >= PERSON_POLE_ASPECT_RATIO and (bw / max(w, 1)) <= PERSON_POLE_MAX_WIDTH_RATIO:
        if confidence < 0.90:
            return False
        if edge_density < 0.055:
            return False

    # Too few edges usually means pole/plain object.
    if edge_density < PERSON_MIN_EDGE_DENSITY and confidence < 0.90:
        return False

    # Too many edges usually means tree/bush/fence clutter.
    if edge_density > PERSON_MAX_EDGE_DENSITY and confidence < 0.88:
        return False

    return True


def person_box_allowed(
    frame: np.ndarray,
    box: Tuple[int, int, int, int],
    confidence: float,
    animal_detections: Optional[List[Dict[str, Any]]] = None
) -> bool:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box

    bw = x2 - x1
    bh = y2 - y1
    if bw <= 0 or bh <= 0:
        return False

    area = bw * bh
    aspect_ratio = bh / max(bw, 1)

    if confidence < PERSON_CONF:
        return False

    if area < PERSON_MIN_AREA:
        return False

    if bw < int(w * PERSON_MIN_BOX_WIDTH_RATIO):
        return False

    if aspect_ratio < PERSON_MIN_ASPECT_RATIO:
        return False

    if aspect_ratio > PERSON_MAX_ASPECT_RATIO:
        return False

    if bh < int(h * PERSON_MIN_BOX_HEIGHT_RATIO):
        return False

    if (bw / max(w, 1)) > PERSON_MAX_BOX_WIDTH_RATIO:
        return False

    if aspect_ratio < 1.45 and confidence < 0.78:
        return False

    # Polygon geofence check.
    # Foot point is better than center point for person detection because
    # it confirms that the person is standing inside the geofence.
    foot_x = int((x1 + x2) / 2)
    foot_y = int(y2)

    if not point_inside_person_polygon(frame, foot_x, foot_y):
        return False

    person_exclusion_zones = load_ratio_boxes_from_config(
        "person_exclusion_zones",
        PERSON_EXCLUSION_ZONES
    )
    if point_inside_any_ratio_box(foot_x, foot_y, frame, person_exclusion_zones):
        return False

    if animal_detections and person_overlaps_suppression_animal(box, animal_detections):
        return False

    if is_whiteboard_like_person_false_positive(frame, box, confidence):
        return False

    if not person_patch_allowed(frame, box, confidence):
        return False

    return True


last_person_full_scan_ts = 0.0


def detect_persons(frame: np.ndarray) -> List[Dict[str, Any]]:
    global last_person_full_scan_ts

    enhanced = enhance_for_person_detection(frame)

    candidates: List[Dict[str, Any]] = []

    candidates.extend(
        detect_persons_single_pass(
            enhanced,
            "normal",
            PERSON_CONF
        )
    )

    now_ts = time.time()
    run_full_scan = (now_ts - last_person_full_scan_ts) >= PERSON_FULL_SCAN_INTERVAL_SEC

    if run_full_scan:
        last_person_full_scan_ts = now_ts

        candidates.extend(
            detect_persons_tiled(enhanced)
        )

        if len(candidates) == 0:
            candidates.extend(
                upscale_and_detect(
                    enhanced,
                    PERSON_UPSCALE_FACTOR,
                    max(0.64, PERSON_CONF - 0.04),
                    "fallback_up"
                )
            )

    merged = nms_merge_persons(candidates)

    if not merged:
        return []

    animal_detections = detect_person_suppression_animals(enhanced)
    filtered: List[Dict[str, Any]] = []

    for d in merged:
        conf = float(d["confidence"])
        if not person_box_allowed(frame, d["box"], conf, animal_detections):
            continue
        filtered.append(d)

    filtered.sort(key=lambda item: item["confidence"], reverse=True)
    return filtered


def draw_person_annotations(frame: np.ndarray, persons: List[Dict[str, Any]]) -> np.ndarray:
    out = frame.copy()
    for idx, d in enumerate(persons, start=1):
        x1, y1, x2, y2 = d["box"]
        label = f'Person {idx} {d["confidence"]:.2f}'
        cv2.rectangle(out, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(out, label, (x1, max(25, y1 - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2, cv2.LINE_AA)
    return out


def nms_merge_boxes(
    detections: List[Dict[str, Any]],
    conf_threshold: float,
    nms_threshold: float
) -> List[Dict[str, Any]]:
    if not detections:
        return []

    boxes: List[List[int]] = []
    scores: List[float] = []

    for d in detections:
        x1, y1, x2, y2 = d["box"]
        boxes.append([x1, y1, max(1, x2 - x1), max(1, y2 - y1)])
        scores.append(float(d["confidence"]))

    kept = cv2.dnn.NMSBoxes(boxes, scores, conf_threshold, nms_threshold)
    if kept is None or len(kept) == 0:
        return []

    out: List[Dict[str, Any]] = []
    for idx in kept:
        i = int(idx[0] if isinstance(idx, (list, tuple, np.ndarray)) else idx)
        out.append(detections[i])

    out.sort(key=lambda item: item["confidence"], reverse=True)
    return out


def create_motion_mask(
    previous_frame: Optional[np.ndarray],
    current_frame: np.ndarray
) -> Optional[np.ndarray]:
    if previous_frame is None or current_frame is None:
        return None

    if previous_frame.shape[:2] != current_frame.shape[:2]:
        return None

    try:
        prev_gray = cv2.cvtColor(previous_frame, cv2.COLOR_BGR2GRAY)
        curr_gray = cv2.cvtColor(current_frame, cv2.COLOR_BGR2GRAY)

        prev_gray = cv2.GaussianBlur(prev_gray, (5, 5), 0)
        curr_gray = cv2.GaussianBlur(curr_gray, (5, 5), 0)

        diff = cv2.absdiff(prev_gray, curr_gray)

        _, motion_mask = cv2.threshold(
            diff,
            VEHICLE_MOTION_THRESHOLD,
            255,
            cv2.THRESH_BINARY
        )

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

        motion_mask = cv2.morphologyEx(
            motion_mask,
            cv2.MORPH_OPEN,
            kernel,
            iterations=1
        )

        motion_mask = cv2.dilate(
            motion_mask,
            kernel,
            iterations=VEHICLE_MOTION_DILATE_ITER
        )

        return motion_mask

    except Exception as exc:
        print(f"[VEHICLE MOTION ERROR] {exc}", flush=True)
        return None


def box_motion_ratio(
    motion_mask: Optional[np.ndarray],
    box: Tuple[int, int, int, int]
) -> Tuple[float, int]:
    if motion_mask is None or motion_mask.size == 0:
        return 0.0, 0

    mh, mw = motion_mask.shape[:2]
    x1, y1, x2, y2 = box

    x1 = max(0, min(mw - 1, x1))
    y1 = max(0, min(mh - 1, y1))
    x2 = max(0, min(mw - 1, x2))
    y2 = max(0, min(mh - 1, y2))

    if x2 <= x1 or y2 <= y1:
        return 0.0, 0

    crop = motion_mask[y1:y2, x1:x2]
    active_pixels = int(np.count_nonzero(crop))
    ratio = float(active_pixels) / float(max(crop.size, 1))
    return ratio, active_pixels


def vehicle_motion_allowed(
    motion_mask: Optional[np.ndarray],
    box: Tuple[int, int, int, int]
) -> bool:
    motion_ratio, active_pixels = box_motion_ratio(motion_mask, box)

    if active_pixels < VEHICLE_MOTION_MIN_PIXELS:
        return False

    if motion_ratio < VEHICLE_MOTION_MIN_RATIO:
        return False

    return True


def vehicle_box_center(box: Tuple[int, int, int, int]) -> Tuple[float, float]:
    x1, y1, x2, y2 = box
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def annotate_vehicle_motion_state(
    vehicles: List[Dict[str, Any]],
    motion_mask: Optional[np.ndarray],
    mode: str
) -> List[Dict[str, Any]]:
    """
    Adds moving/static information using:
      1. frame-difference motion mask
      2. bbox center displacement between detections

    This fixes moving mode when frame-difference mask is weak.
    """
    global vehicle_motion_tracks

    now_ts = time.time()
    mode = normalize_vehicle_detection_mode(mode)

    with vehicle_motion_track_lock:
        old_tracks = [
            track for track in vehicle_motion_tracks
            if (now_ts - float(track.get("ts", 0.0))) <= VEHICLE_MOVING_TRACK_TTL_SEC
        ]

        new_tracks: List[Dict[str, Any]] = []
        annotated: List[Dict[str, Any]] = []

        for vehicle in vehicles:
            item = dict(vehicle)
            box = tuple(item.get("box", (0, 0, 0, 0)))

            cx, cy = vehicle_box_center(box)
            motion_ratio, motion_pixels = box_motion_ratio(motion_mask, box)

            best_shift = 0.0
            best_track = None
            best_score = -1.0

            for track in old_tracks:
                old_box = tuple(track.get("box", (0, 0, 0, 0)))
                old_cx, old_cy = vehicle_box_center(old_box)

                shift = ((cx - old_cx) ** 2 + (cy - old_cy) ** 2) ** 0.5
                iou = box_iou_xyxy(box, old_box)

                # Prefer same object by IOU, then by closeness.
                score = (iou * 1000.0) - shift

                if score > best_score:
                    best_score = score
                    best_shift = shift
                    best_track = track

            moving_by_motion = (
                motion_pixels >= VEHICLE_MOTION_MIN_PIXELS and
                motion_ratio >= VEHICLE_MOTION_MIN_RATIO
            )

            moving_by_shift = best_shift >= VEHICLE_MOVING_MIN_CENTER_SHIFT_PX

            old_recent_moving = False
            if best_track is not None:
                old_recent_moving = (
                    now_ts - float(best_track.get("last_moving_ts", 0.0))
                ) <= VEHICLE_MOVING_RECENT_SEC

            is_moving = bool(
                moving_by_motion or
                moving_by_shift or
                old_recent_moving
            )

            item["motion_ratio"] = round(float(motion_ratio), 4)
            item["motion_pixels"] = int(motion_pixels)
            item["movement_px"] = round(float(best_shift), 2)
            item["is_moving"] = is_moving
            item["movement_state"] = "moving" if is_moving else "static"
            item["mode"] = mode

            last_moving_ts = now_ts if is_moving else 0.0

            if best_track is not None and not is_moving:
                last_moving_ts = float(best_track.get("last_moving_ts", 0.0))

            new_tracks.append({
                "box": box,
                "center": (cx, cy),
                "ts": now_ts,
                "last_moving_ts": last_moving_ts,
                "label": item.get("label"),
            })

            annotated.append(item)

        vehicle_motion_tracks = new_tracks
        return annotated


def vehicle_box_allowed(
    frame: np.ndarray,
    box: Tuple[int, int, int, int],
    confidence: float,
    motion_mask: Optional[np.ndarray],
    detection_mode: str
) -> Tuple[bool, float]:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = box

    bw = x2 - x1
    bh = y2 - y1

    if bw <= 0 or bh <= 0:
        return False, 0.0

    if confidence < VEHICLE_CONF:
        return False, 0.0

    area = bw * bh

    if area < VEHICLE_MIN_AREA:
        return False, 0.0

    if bw < int(w * VEHICLE_MIN_BOX_WIDTH_RATIO):
        return False, 0.0

    if bh < int(h * VEHICLE_MIN_BOX_HEIGHT_RATIO):
        return False, 0.0

    if bw > int(w * VEHICLE_MAX_BOX_WIDTH_RATIO):
        return False, 0.0

    if bh > int(h * VEHICLE_MAX_BOX_HEIGHT_RATIO):
        return False, 0.0

    cx = int((x1 + x2) / 2)
    cy = int((y1 + y2) / 2)

    vehicle_exclusion_zones = load_ratio_boxes_from_config(
        "vehicle_exclusion_zones",
        VEHICLE_EXCLUSION_ZONES
    )

    if point_inside_any_ratio_box(cx, cy, frame, vehicle_exclusion_zones):
        return False, 0.0

    inside_geofence, geofence_overlap = vehicle_box_inside_geofence(frame, box)

    if not inside_geofence:
        return False, geofence_overlap

    # IMPORTANT:
    # Do NOT reject moving mode here.
    # Moving/static decision happens after NMS using bbox displacement + motion mask.
    return True, geofence_overlap


def detect_vehicles(
    frame: np.ndarray,
    motion_mask: Optional[np.ndarray] = None,
    detection_mode: Optional[str] = None
) -> List[Dict[str, Any]]:
    if person_net is None:
        return []

    mode = normalize_vehicle_detection_mode(
        detection_mode or load_vehicle_detection_mode()
    )

    h, w = frame.shape[:2]

    blob = cv2.dnn.blobFromImage(
        cv2.resize(frame, (300, 300)),
        scalefactor=0.007843,
        size=(300, 300),
        mean=127.5
    )

    with person_dnn_lock:
        person_net.setInput(blob)
        detections = person_net.forward()

    candidates: List[Dict[str, Any]] = []

    for i in range(detections.shape[2]):
        confidence = float(detections[0, 0, i, 2])

        if confidence < max(0.40, VEHICLE_CONF - 0.15):
            continue

        class_index = int(detections[0, 0, i, 1])

        if class_index < 0 or class_index >= len(MOBILENET_CLASSES):
            continue

        label = MOBILENET_CLASSES[class_index]

        if label not in VEHICLE_CLASSES:
            continue

        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        x1, y1, x2, y2 = box.astype("int").tolist()

        x1 = max(0, min(w - 1, x1))
        y1 = max(0, min(h - 1, y1))
        x2 = max(0, min(w - 1, x2))
        y2 = max(0, min(h - 1, y2))

        if x2 <= x1 or y2 <= y1:
            continue

        allowed, geofence_overlap = vehicle_box_allowed(
            frame,
            (x1, y1, x2, y2),
            confidence,
            motion_mask,
            mode
        )

        if not allowed:
            continue

        motion_ratio, motion_pixels = box_motion_ratio(
            motion_mask,
            (x1, y1, x2, y2)
        )

        candidates.append({
            "label": label,
            "display_label": VEHICLE_CLASS_LABELS.get(label, label.title()),
            "confidence": round(confidence, 4),
            "box": (x1, y1, x2, y2),
            "motion_ratio": round(motion_ratio, 4),
            "motion_pixels": motion_pixels,
            "mode": mode,
            "geofence_overlap": round(geofence_overlap, 4),
        })

    merged = nms_merge_boxes(
        candidates,
        max(0.40, VEHICLE_CONF - 0.15),
        VEHICLE_NMS_THRESHOLD
    )

    merged.sort(
        key=lambda item: float(item.get("confidence", 0.0)),
        reverse=True
    )

    annotated = annotate_vehicle_motion_state(
        merged,
        motion_mask,
        mode
    )

    if mode == "moving":
        moving_only = [
            vehicle for vehicle in annotated
            if bool(vehicle.get("is_moving", False))
        ]

        return moving_only

    return annotated


def draw_vehicle_annotations(frame: np.ndarray, vehicles: List[Dict[str, Any]]) -> np.ndarray:
    out = frame.copy()
    vehicle_polygon = get_vehicle_polygon_pixels(out)
    draw_polygon_outline(out, vehicle_polygon, "Vehicle Polygon Zone", (255, 200, 0), 0.0)

    for idx, d in enumerate(vehicles, start=1):
        x1, y1, x2, y2 = d["box"]
        mode = str(d.get("mode", load_vehicle_detection_mode())).upper()
        overlap_percent = float(d.get("geofence_overlap", 0.0)) * 100.0
        label = f'{d["display_label"]} {idx} {d["confidence"]:.2f} {mode} G:{overlap_percent:.0f}%'

        cv2.rectangle(out, (x1, y1), (x2, y2), (255, 200, 0), 2)
        cv2.putText(
            out,
            label,
            (x1, max(25, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 200, 0),
            2,
            cv2.LINE_AA
        )

    return out

def expand_pixel_box(
    box: Tuple[int, int, int, int],
    frame_w: int,
    frame_h: int,
    pad_ratio: float
) -> Tuple[int, int, int, int]:
    """
    Expands vehicle box slightly before searching for plate.
    This helps when the detected vehicle box is tight.
    """
    x1, y1, x2, y2 = box

    bw = max(1, x2 - x1)
    bh = max(1, y2 - y1)

    pad_x = int(bw * pad_ratio)
    pad_y = int(bh * pad_ratio)

    return (
        max(0, x1 - pad_x),
        max(0, y1 - pad_y),
        min(frame_w - 1, x2 + pad_x),
        min(frame_h - 1, y2 + pad_y),
    )

def _apply_gamma(image: np.ndarray, gamma: float) -> np.ndarray:
    inv = 1.0 / max(0.05, float(gamma))

    table = np.array([
        ((i / 255.0) ** inv) * 255 for i in range(256)
    ], dtype=np.uint8)

    return cv2.LUT(image, table)


def _dedupe_named_images(items: List[Tuple[str, np.ndarray]]) -> List[Tuple[str, np.ndarray]]:
    kept: List[Tuple[str, np.ndarray]] = []
    seen = set()

    for name, img in items:
        if img is None or img.size == 0:
            continue

        key = (name, img.shape[:2])

        if key in seen:
            continue

        kept.append((name, img))
        seen.add(key)

    return kept

def build_vehicle_video_name(event_time: dt.datetime) -> str:
    device_part = sanitize_filename_part(DEVICE_ID)
    suffix_part = sanitize_filename_part(VEHICLE_VIDEO_SUFFIX)
    return (
        f"{device_part}-Vehicle_"
        f"{event_time.strftime('%Y%m%d_%H%M%S')}_"
        f"{suffix_part}.{VEHICLE_VIDEO_EXTENSION}"
    )


def async_upload_vehicle_video(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    event_time: dt.datetime,
    vehicle_count: int,
    best_confidence: float,
    vehicle_labels: List[str]
) -> None:
    def worker():
        remote_path = f"{remote_dir.rstrip('/')}/{remote_name}"
        event_key = build_vehicle_event_key(event_time)

        try:
            sftp_upload(local_path, remote_dir, remote_name)

            deleted_local = False
            delete_error = None
            try:
                if local_path.exists():
                    local_path.unlink()
                    deleted_local = True
            except Exception as exc:
                delete_error = str(exc)

            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None,
            }))

            update_state(lambda s: s.update({
                "last_vehicle_video": {
                    "file": remote_name,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "status": "uploaded_deleted_local" if deleted_local else "uploaded_delete_failed",
                    "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
                    "vehicle_count": vehicle_count,
                    "best_confidence": best_confidence,
                    "labels": vehicle_labels,
                }
            }))

            update_vehicle_event_result(
                event_key,
                video_done=True,
                video_ok=True,
                video_file=remote_name,
                video_path=remote_path,
                video_status="success",
                video_message="Vehicle video uploaded successfully",
                duration_sec=VEHICLE_VIDEO_DURATION_SEC,
            )
            maybe_publish_vehicle_combined_response(event_key)

            add_event("vehicle_video_uploaded", {
                "file": remote_name,
                "video_path": remote_path,
                "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
                "vehicle_count": vehicle_count,
                "vehicle_labels": vehicle_labels,
                "best_confidence": best_confidence,
                "local_deleted": deleted_local,
                "local_delete_error": delete_error,
            })

        except Exception as exc:
            error_text = str(exc).strip() or repr(exc)

            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="vehicle_video",
                delete_local_on_success=True,
                metadata={
                    "event_key": event_key,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
                    "vehicle_count": vehicle_count,
                    "best_confidence": best_confidence,
                    "vehicle_labels": vehicle_labels,
                },
            )

            update_state(lambda s: s["system"].update({
                "sftp_last_error": error_text,
            }))
            update_state(lambda s: s.update({
                "last_vehicle_video": {
                    "file": remote_name,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "status": f"upload_failed_queued_retry: {error_text}",
                    "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
                    "vehicle_count": vehicle_count,
                    "best_confidence": best_confidence,
                    "labels": vehicle_labels,
                }
            }))
            add_event("vehicle_video_upload_failed_queued", {
                "file": remote_name,
                "video_path": remote_path,
                "error": error_text,
            })

    threading.Thread(target=worker, daemon=True).start()

def build_vehicle_event_key(event_time: dt.datetime) -> str:
    return event_time.strftime("%Y%m%d_%H%M%S")


def init_vehicle_event_result(
    event_time: dt.datetime,
    vehicle_count: int,
    best_confidence: float,
    vehicle_labels: List[str]
) -> str:
    event_key = build_vehicle_event_key(event_time)
    with vehicle_event_lock:
        vehicle_event_results[event_key] = {
            "event_time": event_time,
            "vehicle_count": vehicle_count,
            "best_confidence": best_confidence,
            "vehicle_labels": list(vehicle_labels),

            "image_done": False,
            "image_ok": False,
            "image_file": None,
            "image_path": None,
            "image_status": None,
            "image_message": None,

            "video_done": False,
            "video_ok": False,
            "video_file": None,
            "video_path": None,
            "video_status": None,
            "video_message": None,
            "duration_sec": VEHICLE_VIDEO_DURATION_SEC,

            "published": False,
        }
    return event_key


def update_vehicle_event_result(event_key: str, **kwargs: Any) -> Optional[Dict[str, Any]]:
    with vehicle_event_lock:
        item = vehicle_event_results.get(event_key)
        if not item:
            return None
        item.update(kwargs)
        return dict(item)


def maybe_publish_vehicle_combined_response(event_key: str) -> None:
    with vehicle_event_lock:
        item = vehicle_event_results.get(event_key)
        if not item:
            return

        if item.get("published"):
            return

        if not (item.get("image_done") and item.get("video_done")):
            return

        event_time: dt.datetime = item["event_time"]
        image_path = item.get("image_path")
        video_path = item.get("video_path")

        payload = {
            "date": event_time.strftime("%Y-%m-%d"),
            "time": event_time.strftime("%H:%M:%S"),
            "event": "vehicle_detected",
            "device_id": DEVICE_ID,
            "camera_name": CAMERA_NAME,

            "image_file": item.get("image_file"),
            "image_path": image_path,
            "image_status": item.get("image_status") or ("success" if item.get("image_ok") else "failed"),
            "image_message": item.get("image_message"),

            "video_file": item.get("video_file"),
            "video_path": video_path,
            "video_status": item.get("video_status") or ("success" if item.get("video_ok") else "failed"),
            "video_message": item.get("video_message"),

            "dir": image_path,
            "video_dir": video_path,

            "vehicle_count": item.get("vehicle_count", 0),
            "vehicle_labels": item.get("vehicle_labels", []),
            "best_confidence": item.get("best_confidence", 0.0),
            "duration_sec": item.get("duration_sec", VEHICLE_VIDEO_DURATION_SEC),
            **build_common_links_payload(),
        }

        item["published"] = True

    try:
        mqtt_publish(MQTT_RESPONSE_TOPIC, payload)
        update_state(lambda s: s["system"].update({
            "mqtt_last_ok": now_str(),
            "mqtt_last_error": None,
        }))
    except Exception as mqtt_exc:
        update_state(lambda s: s["system"].update({
            "mqtt_last_error": str(mqtt_exc),
        }))
    finally:
        with vehicle_event_lock:
            vehicle_event_results.pop(event_key, None)


def async_upload_vehicle_image(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    event_time: dt.datetime,
    vehicle_count: int,
    best_confidence: float,
    vehicle_labels: List[str],
    rel_img: str,
    vehicle_mode: str,
    geofence_overlap: float
) -> None:
    def worker():
        remote_path = f"{remote_dir.rstrip('/')}/{remote_name}"
        event_key = build_vehicle_event_key(event_time)

        try:
            sftp_upload(local_path, remote_dir, remote_name)

            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None,
            }))

            update_state(lambda s: s.update({
                "last_vehicle": {
                    "detected": True,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "image": rel_img,
                    "count": vehicle_count,
                    "best_confidence": best_confidence,
                    "labels": vehicle_labels,
                    "image_status": "uploaded",
                    "image_file": remote_name,
                    "image_uploaded_path": remote_path,
                    "mode": vehicle_mode,
                    "geofence_overlap": geofence_overlap,
                }
            }))

            update_vehicle_event_result(
                event_key,
                image_done=True,
                image_ok=True,
                image_file=remote_name,
                image_path=remote_path,
                image_status="success",
                image_message="Vehicle image uploaded successfully",
            )
            maybe_publish_vehicle_combined_response(event_key)

            add_event("vehicle_image_uploaded", {
                "file": remote_name,
                "image_path": remote_path,
                "vehicle_count": vehicle_count,
                "vehicle_labels": vehicle_labels,
                "best_confidence": best_confidence,
            })

        except Exception as exc:
            error_text = str(exc).strip() or repr(exc)

            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="vehicle_image",
                delete_local_on_success=False,
                metadata={
                    "event_key": event_key,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "vehicle_count": vehicle_count,
                    "best_confidence": best_confidence,
                    "vehicle_labels": vehicle_labels,
                    "rel_img": rel_img,
                    "vehicle_mode": vehicle_mode,
                    "geofence_overlap": geofence_overlap,
                },
            )

            update_state(lambda s: s["system"].update({
                "sftp_last_error": error_text,
            }))

            update_state(lambda s: s.update({
                "last_vehicle": {
                    "detected": True,
                    "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "image": rel_img,
                    "count": vehicle_count,
                    "best_confidence": best_confidence,
                    "labels": vehicle_labels,
                    "image_status": f"upload_failed_queued_retry: {error_text}",
                    "image_file": remote_name,
                    "image_uploaded_path": remote_path,
                    "mode": vehicle_mode,
                    "geofence_overlap": geofence_overlap,
                }
            }))
            add_event("vehicle_image_upload_failed_queued", {
                "file": remote_name,
                "image_path": remote_path,
                "error": error_text,
            })

    threading.Thread(target=worker, daemon=True).start()

def handle_vehicle_video_event(
    event_time: dt.datetime,
    event_ts: float,
    vehicle_count: int,
    best_confidence: float,
    vehicle_labels: List[str]
) -> None:
    video_name = build_vehicle_video_name(event_time)
    local_video_path = VIDEO_DIR / video_name
    event_key = build_vehicle_event_key(event_time)

    update_state(lambda s: s.update({
        "last_vehicle_video": {
            "file": video_name,
            "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
            "status": "buffering_post_event",
            "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
            "vehicle_count": vehicle_count,
            "best_confidence": best_confidence,
            "labels": vehicle_labels,
        }
    }))

    try:
        actual_duration_sec = write_buffered_event_video(
            output_path=local_video_path,
            event_ts=event_ts,
            pre_sec=EVENT_PRE_RECORD_SEC,
            post_sec=EVENT_POST_RECORD_SEC,
        )

        update_state(lambda s: s.update({
            "last_vehicle_video": {
                "file": video_name,
                "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "recorded",
                "duration_sec": actual_duration_sec,
                "vehicle_count": vehicle_count,
                "best_confidence": best_confidence,
                "labels": vehicle_labels,
            }
        }))

        async_upload_vehicle_video(
            local_path=local_video_path,
            remote_dir=SFTP_VEHICLE_VIDEO_DIR,
            remote_name=video_name,
            event_time=event_time,
            vehicle_count=vehicle_count,
            best_confidence=best_confidence,
            vehicle_labels=vehicle_labels,
        )

    except Exception as video_exc:
        remote_path = f"{SFTP_VEHICLE_VIDEO_DIR.rstrip('/')}/{video_name}"

        update_state(lambda s: s.update({
            "last_vehicle_video": {
                "file": video_name,
                "time": event_time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": f"record_failed: {video_exc}",
                "duration_sec": VEHICLE_VIDEO_DURATION_SEC,
                "vehicle_count": vehicle_count,
                "best_confidence": best_confidence,
                "labels": vehicle_labels,
            }
        }))

        update_vehicle_event_result(
            event_key,
            video_done=True,
            video_ok=False,
            video_file=video_name,
            video_path=remote_path,
            video_status="failed",
            video_message=f"Vehicle video record failed: {video_exc}",
            duration_sec=VEHICLE_VIDEO_DURATION_SEC,
        )
        maybe_publish_vehicle_combined_response(event_key)


def mqtt_publish(topic: str, payload: Dict[str, Any]) -> None:
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    client.connect(MQTT_HOST, MQTT_PORT, 20)
    msg_info = client.publish(topic, json.dumps(payload), qos=1, retain=False)
    msg_info.wait_for_publish(timeout=5)
    client.disconnect()


def sftp_connect() -> Tuple[paramiko.SSHClient, paramiko.SFTPClient]:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(
        hostname=SFTP_HOST,
        port=SFTP_PORT,
        username=SFTP_USERNAME,
        password=SFTP_PASSWORD,
        timeout=20,
        banner_timeout=20,
        auth_timeout=20,
        look_for_keys=False,
        allow_agent=False
    )
    sftp = ssh.open_sftp()
    return ssh, sftp


def sftp_mkdirs(sftp: paramiko.SFTPClient, remote_dir: str) -> None:
    current = "/"
    for part in [p for p in remote_dir.strip("/").split("/") if p]:
        current = f"{current.rstrip('/')}/{part}"
        try:
            sftp.stat(current)
        except FileNotFoundError:
            sftp.mkdir(current)


def wait_for_file_stable(
    path: Path,
    checks: int = 4,
    gap_sec: float = 0.5,
    min_size_bytes: int = 1024
) -> Tuple[bool, int]:
    last_size = -1
    stable_count = 0

    for _ in range(max(1, checks * 4)):
        if not path.exists():
            time.sleep(gap_sec)
            continue

        try:
            current_size = int(path.stat().st_size)
        except Exception:
            current_size = 0

        if current_size >= min_size_bytes and current_size == last_size:
            stable_count += 1
            if stable_count >= checks:
                return True, current_size
        else:
            stable_count = 0

        last_size = current_size
        time.sleep(gap_sec)

    final_size = int(path.stat().st_size) if path.exists() else 0
    return final_size >= min_size_bytes, final_size


def sftp_upload(local_path: Path, remote_dir: str, remote_name: str) -> None:
    local_path = Path(local_path)
    remote_dir = str(remote_dir).rstrip("/")

    if not local_path.exists():
        raise FileNotFoundError(f"Local upload file missing: {local_path}")

    stable_ok, local_size = wait_for_file_stable(local_path)
    if not stable_ok or local_size <= 1024:
        raise RuntimeError(f"Local file not ready or empty: {local_path}, size={local_size}")

    remote_final_path = f"{remote_dir}/{remote_name}"
    remote_temp_path = f"{remote_final_path}.part"

    last_error: Optional[Exception] = None

    for attempt in range(1, 5):
        ssh = None
        sftp = None

        try:
            ssh, sftp = sftp_connect()
            sftp.get_channel().settimeout(90)

            sftp_mkdirs(sftp, remote_dir)

            try:
                sftp.remove(remote_temp_path)
            except Exception:
                pass

            # Upload to temporary file first.
            # confirm=False avoids Paramiko's early false size-check issue.
            sftp.put(str(local_path), remote_temp_path, confirm=False)

            time.sleep(0.8)

            temp_size = int(sftp.stat(remote_temp_path).st_size)
            if temp_size != local_size:
                raise RuntimeError(
                    f"SFTP temp size mismatch attempt={attempt}: "
                    f"remote={temp_size}, local={local_size}, path={remote_temp_path}"
                )

            try:
                sftp.remove(remote_final_path)
            except Exception:
                pass

            sftp.rename(remote_temp_path, remote_final_path)

            time.sleep(0.5)

            final_size = int(sftp.stat(remote_final_path).st_size)
            if final_size != local_size:
                raise RuntimeError(
                    f"SFTP final size mismatch attempt={attempt}: "
                    f"remote={final_size}, local={local_size}, path={remote_final_path}"
                )

            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None,
                "sftp_last_file": remote_final_path,
                "sftp_last_size": final_size
            }))

            return

        except Exception as exc:
            last_error = exc

            try:
                if sftp is not None:
                    sftp.remove(remote_temp_path)
            except Exception:
                pass

            time.sleep(1.5 * attempt)

        finally:
            try:
                if sftp is not None:
                    sftp.close()
            except Exception:
                pass

            try:
                if ssh is not None:
                    ssh.close()
            except Exception:
                pass

    raise RuntimeError(f"SFTP upload failed after retries: {last_error}")



def load_sftp_retry_queue() -> List[Dict[str, Any]]:
    with sftp_retry_lock:
        try:
            if not SFTP_RETRY_QUEUE_FILE.exists():
                return []

            data = json.loads(SFTP_RETRY_QUEUE_FILE.read_text())
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
        except Exception as exc:
            update_state(lambda s: s["system"].update({
                "sftp_retry_last_error": f"queue_read_failed: {exc}"
            }))

        return []


def save_sftp_retry_queue(items: List[Dict[str, Any]]) -> None:
    with sftp_retry_lock:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp_path = SFTP_RETRY_QUEUE_FILE.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(items, indent=2, sort_keys=True))
        tmp_path.replace(SFTP_RETRY_QUEUE_FILE)

        update_state(lambda s: s["system"].update({
            "sftp_retry_pending_count": len(items),
            "sftp_retry_queue_file": str(SFTP_RETRY_QUEUE_FILE),
        }))


def queue_sftp_retry(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    source: str = "generic",
    delete_local_on_success: bool = False,
    mqtt_topic: Optional[str] = None,
    mqtt_payload: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    local_path = Path(local_path)
    remote_dir = str(remote_dir).rstrip("/")
    remote_name = str(remote_name)
    remote_path = f"{remote_dir}/{remote_name}"
    now_ts = time.time()

    with sftp_retry_lock:
        items = load_sftp_retry_queue()

        for item in items:
            if (
                item.get("local_path") == str(local_path)
                and item.get("remote_path") == remote_path
            ):
                item.update({
                    "updated_at": now_str(),
                    "next_retry_at": 0,
                    "last_error": item.get("last_error"),
                    "source": source or item.get("source") or "generic",
                    "delete_local_on_success": bool(delete_local_on_success),
                    "mqtt_topic": mqtt_topic,
                    "mqtt_payload": mqtt_payload,
                    "metadata": metadata or item.get("metadata") or {},
                })
                save_sftp_retry_queue(items)
                return str(item.get("id"))

        job_id = uuid.uuid4().hex
        items.append({
            "id": job_id,
            "source": source,
            "local_path": str(local_path),
            "remote_dir": remote_dir,
            "remote_name": remote_name,
            "remote_path": remote_path,
            "delete_local_on_success": bool(delete_local_on_success),
            "mqtt_topic": mqtt_topic,
            "mqtt_payload": mqtt_payload,
            "metadata": metadata or {},
            "attempts": 0,
            "created_at": now_str(),
            "created_at_ts": now_ts,
            "updated_at": now_str(),
            "next_retry_at": 0,
            "last_error": None,
        })

        save_sftp_retry_queue(items)

    add_event("sftp_retry_queued", {
        "id": job_id,
        "source": source,
        "file": remote_name,
        "remote_path": remote_path,
        "delete_local_on_success": bool(delete_local_on_success),
    })

    update_state(lambda s: s["system"].update({
        "sftp_last_error": f"queued_retry: {remote_name}",
    }))

    return job_id


def remove_sftp_retry_job(job_id: str) -> None:
    with sftp_retry_lock:
        items = load_sftp_retry_queue()
        items = [item for item in items if str(item.get("id")) != str(job_id)]
        save_sftp_retry_queue(items)


def update_sftp_retry_job(job_id: str, **changes: Any) -> None:
    with sftp_retry_lock:
        items = load_sftp_retry_queue()
        for item in items:
            if str(item.get("id")) == str(job_id):
                item.update(changes)
                item["updated_at"] = now_str()
                break
        save_sftp_retry_queue(items)


def handle_sftp_retry_success(job: Dict[str, Any], remote_path: str, local_deleted: bool, delete_error: Optional[str]) -> None:
    metadata = job.get("metadata") or {}
    source = str(job.get("source") or "generic")
    remote_name = str(job.get("remote_name") or Path(remote_path).name)

    update_state(lambda s: s["system"].update({
        "sftp_last_ok": now_str(),
        "sftp_last_error": None,
        "sftp_last_file": remote_path,
    }))

    if source == "person_video":
        update_state(lambda s: s.update({
            "last_video": {
                "file": remote_name,
                "time": metadata.get("time") or now_str(),
                "status": "retry_uploaded_deleted_local" if local_deleted else "retry_uploaded_delete_failed",
                "duration_sec": metadata.get("duration_sec", PERSON_VIDEO_DURATION_SEC),
                "person_count": metadata.get("person_count", 0),
                "best_confidence": metadata.get("best_confidence", 0.0),
            }
        }))

    elif source == "vehicle_video":
        event_key = str(metadata.get("event_key") or "")
        labels = metadata.get("vehicle_labels") or []

        update_state(lambda s: s.update({
            "last_vehicle_video": {
                "file": remote_name,
                "time": metadata.get("time") or now_str(),
                "status": "retry_uploaded_deleted_local" if local_deleted else "retry_uploaded_delete_failed",
                "duration_sec": metadata.get("duration_sec", VEHICLE_VIDEO_DURATION_SEC),
                "vehicle_count": metadata.get("vehicle_count", 0),
                "best_confidence": metadata.get("best_confidence", 0.0),
                "labels": labels,
            }
        }))

        if event_key:
            update_vehicle_event_result(
                event_key,
                video_done=True,
                video_ok=True,
                video_file=remote_name,
                video_path=remote_path,
                video_status="success",
                video_message="Vehicle video uploaded successfully after retry",
                duration_sec=metadata.get("duration_sec", VEHICLE_VIDEO_DURATION_SEC),
            )
            maybe_publish_vehicle_combined_response(event_key)

    elif source == "vehicle_image":
        event_key = str(metadata.get("event_key") or "")
        labels = metadata.get("vehicle_labels") or []

        update_state(lambda s: s.update({
            "last_vehicle": {
                "detected": True,
                "time": metadata.get("time") or now_str(),
                "image": metadata.get("rel_img"),
                "count": metadata.get("vehicle_count", 0),
                "best_confidence": metadata.get("best_confidence", 0.0),
                "labels": labels,
                "image_status": "retry_uploaded",
                "image_file": remote_name,
                "image_uploaded_path": remote_path,
                "mode": metadata.get("vehicle_mode", "unknown"),
                "geofence_overlap": metadata.get("geofence_overlap", 0.0),
            }
        }))

        if event_key:
            update_vehicle_event_result(
                event_key,
                image_done=True,
                image_ok=True,
                image_file=remote_name,
                image_path=remote_path,
                image_status="success",
                image_message="Vehicle image uploaded successfully after retry",
            )
            maybe_publish_vehicle_combined_response(event_key)

    mqtt_topic = job.get("mqtt_topic")
    mqtt_payload = job.get("mqtt_payload")
    if mqtt_topic and isinstance(mqtt_payload, dict) and not is_power_saving_active():
        try:
            mqtt_publish(str(mqtt_topic), mqtt_payload)
            update_state(lambda s: s["system"].update({
                "mqtt_last_ok": now_str(),
                "mqtt_last_error": None,
            }))
        except Exception as exc:
            update_state(lambda s: s["system"].update({
                "mqtt_last_error": str(exc),
            }))

    add_event("sftp_retry_uploaded", {
        "id": job.get("id"),
        "source": source,
        "file": remote_name,
        "remote_path": remote_path,
        "local_deleted": local_deleted,
        "local_delete_error": delete_error,
    })


def sftp_retry_worker_loop() -> None:
    while not stop_event.is_set():
        if is_power_saving_active():
            time.sleep(SFTP_RETRY_INTERVAL_SEC)
            continue

        items = load_sftp_retry_queue()
        now_ts = time.time()

        if not items:
            time.sleep(SFTP_RETRY_INTERVAL_SEC)
            continue

        for job in list(items):
            if stop_event.is_set():
                break

            job_id = str(job.get("id") or "")
            if not job_id:
                continue

            if float(job.get("next_retry_at") or 0) > now_ts:
                continue

            local_path = Path(str(job.get("local_path") or ""))
            remote_dir = str(job.get("remote_dir") or "").rstrip("/")
            remote_name = str(job.get("remote_name") or "")
            remote_path = str(job.get("remote_path") or f"{remote_dir}/{remote_name}")
            attempts = int(job.get("attempts") or 0)

            if attempts >= SFTP_RETRY_MAX_ATTEMPTS:
                update_sftp_retry_job(job_id, last_error="max_attempts_reached")
                continue

            if not local_path.exists():
                remove_sftp_retry_job(job_id)
                add_event("sftp_retry_local_file_missing", {
                    "id": job_id,
                    "source": job.get("source"),
                    "local_path": str(local_path),
                    "remote_path": remote_path,
                })
                continue

            created_at_ts = float(job.get("created_at_ts") or now_ts)
            if (now_ts - created_at_ts) > SFTP_RETRY_MAX_AGE_SEC:
                update_sftp_retry_job(job_id, last_error="retry_job_expired")
                continue

            try:
                update_sftp_retry_job(job_id, attempts=attempts + 1, last_attempt_at=now_str())
                sftp_upload(local_path, remote_dir, remote_name)

                local_deleted = False
                delete_error = None
                if bool(job.get("delete_local_on_success")):
                    try:
                        if local_path.exists():
                            local_path.unlink()
                            local_deleted = True
                    except Exception as exc:
                        delete_error = str(exc)

                handle_sftp_retry_success(job, remote_path, local_deleted, delete_error)
                remove_sftp_retry_job(job_id)

            except Exception as exc:
                error_text = str(exc).strip() or repr(exc)
                next_retry = time.time() + min(300, SFTP_RETRY_INTERVAL_SEC * max(1, min(attempts + 1, 10)))
                update_sftp_retry_job(
                    job_id,
                    attempts=attempts + 1,
                    last_error=error_text,
                    next_retry_at=next_retry,
                )
                update_state(lambda s: s["system"].update({
                    "sftp_retry_last_error": error_text,
                    "sftp_last_error": error_text,
                }))
                add_event("sftp_retry_failed", {
                    "id": job_id,
                    "source": job.get("source"),
                    "file": remote_name,
                    "attempts": attempts + 1,
                    "error": error_text,
                })

        time.sleep(SFTP_RETRY_INTERVAL_SEC)

def sftp_download(remote_path: str, local_path: Path) -> None:
    ssh = None
    sftp = None
    try:
        ssh, sftp = sftp_connect()
        local_path.parent.mkdir(parents=True, exist_ok=True)
        sftp.get(remote_path, str(local_path))
    finally:
        if sftp is not None:
            sftp.close()
        if ssh is not None:
            ssh.close()

def async_upload_person_image(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    remote_path: str
) -> None:
    def worker():
        def set_person_image_status(status: str, error: Optional[str] = None) -> None:
            def mut(state):
                person = state.setdefault("last_person", {})
                person["image"] = person.get("image") or remote_name
                person["image_file"] = remote_name
                person["image_uploaded_path"] = remote_path
                person["image_status"] = status
                if error:
                    person["image_error"] = error
            update_state(mut)

        if is_power_saving_active():
            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="person_image",
                delete_local_on_success=False,
                mqtt_topic=None,
                mqtt_payload=None,
                metadata={"queued_from": "power_saving", "remote_path": remote_path},
            )
            set_person_image_status("queued_power_saving")
            update_state(lambda s: s["system"].update({
                "sftp_last_error": "person image upload queued: power saving mode active"
            }))
            return

        try:
            sftp_upload(local_path, remote_dir, remote_name)
            set_person_image_status("uploaded")
            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None
            }))
            add_event("person_image_uploaded", {
                "file": remote_name,
                "remote_path": remote_path
            })
        except Exception as exc:
            error_text = str(exc)
            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="person_image",
                delete_local_on_success=False,
                mqtt_topic=None,
                mqtt_payload=None,
                metadata={"queued_from": "person_image", "remote_path": remote_path},
            )
            set_person_image_status("queued_after_error", error_text)
            update_state(lambda s: s["system"].update({
                "sftp_last_error": error_text
            }))
            add_event("person_image_upload_failed_queued", {
                "file": remote_name,
                "remote_dir": remote_dir,
                "remote_path": remote_path,
                "error": error_text
            })

    threading.Thread(target=worker, daemon=True).start()


def async_send(
    local_path: Path,
    remote_dir: str,
    remote_name: str,
    mqtt_topic: Optional[str],
    mqtt_payload: Optional[Dict[str, Any]]
) -> None:
    def worker():
        if is_power_saving_active():
            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="async_send",
                delete_local_on_success=False,
                mqtt_topic=mqtt_topic,
                mqtt_payload=mqtt_payload,
                metadata={"queued_from": "power_saving"},
            )
            update_state(lambda s: s["system"].update({
                "sftp_last_error": "upload queued: power saving mode active"
            }))
            return

        upload_ok = False
        error_text = None

        try:
            sftp_upload(local_path, remote_dir, remote_name)
            upload_ok = True
            update_state(lambda s: s["system"].update({
                "sftp_last_ok": now_str(),
                "sftp_last_error": None
            }))
        except Exception as exc:
            error_text = str(exc)
            update_state(lambda s: s["system"].update({
                "sftp_last_error": error_text
            }))

        if not upload_ok:
            queue_sftp_retry(
                local_path=local_path,
                remote_dir=remote_dir,
                remote_name=remote_name,
                source="async_send",
                delete_local_on_success=False,
                mqtt_topic=mqtt_topic,
                mqtt_payload=mqtt_payload,
                metadata={"queued_from": "async_send"},
            )
            add_event("sftp_upload_failed_queued", {
                "file": remote_name,
                "remote_dir": remote_dir,
                "error": error_text
            })
            return

        if mqtt_topic and mqtt_payload and not is_power_saving_active():
            try:
                time.sleep(15)
                if is_power_saving_active():
                    return

                mqtt_publish(mqtt_topic, mqtt_payload)
                update_state(lambda s: s["system"].update({
                    "mqtt_last_ok": now_str(),
                    "mqtt_last_error": None
                }))
            except Exception as exc:
                update_state(lambda s: s["system"].update({
                    "mqtt_last_error": str(exc)
                }))

    threading.Thread(target=worker, daemon=True).start()


def clear_audio_queue() -> int:
    cleared_count = 0

    while True:
        try:
            audio_queue.get_nowait()
            audio_queue.task_done()
            cleared_count += 1
        except queue.Empty:
            break

    return cleared_count


def stop_current_audio_process() -> None:
    global current_audio_proc

    if current_audio_proc is None:
        return

    try:
        if current_audio_proc.poll() is None:
            current_audio_proc.terminate()
            try:
                current_audio_proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                current_audio_proc.kill()
                current_audio_proc.wait(timeout=2)
    except Exception:
        pass
    finally:
        current_audio_proc = None

    try:
        subprocess.run(
            ["pkill", "-9", "aplay"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except Exception:
        pass


def list_aplay_output_devices() -> List[str]:
    """
    Return ALSA playback devices in preferred order.

    Priority:
      1. USB/audio-looking devices using plughw
      2. default ALSA device
      3. other plughw devices

    plughw is preferred because it performs sample-format conversion.
    """
    usb_devices: List[str] = []
    other_devices: List[str] = []

    try:
        proc = subprocess.run(
            ["aplay", "-l"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        for line in proc.stdout.splitlines():
            match = re.search(
                r"card\s+(\d+):.*device\s+(\d+):",
                line,
                flags=re.IGNORECASE
            )
            if not match:
                continue

            card_index = match.group(1)
            device_index = match.group(2)
            device_name = f"plughw:{card_index},{device_index}"

            lower_line = line.lower()
            if "usb" in lower_line or "audio" in lower_line or "sound" in lower_line:
                usb_devices.append(device_name)
            else:
                other_devices.append(device_name)

    except Exception as exc:
        print(f"[AUDIO WARN] Could not list ALSA devices: {exc}", flush=True)

    ordered_devices = usb_devices + ["default"] + other_devices

    unique_devices: List[str] = []
    for device in ordered_devices:
        if device not in unique_devices:
            unique_devices.append(device)

    return unique_devices


def play_with_aplay(file_path: Path, timeout_sec: int = 60, retries: int = 3) -> bool:
    global current_audio_proc

    if not file_path.exists():
        print(f"[AUDIO ERROR] File missing: {file_path}", flush=True)
        return False

    with audio_lock:
        devices = list_aplay_output_devices()

        if not devices:
            devices = ["default"]

        print(f"[AUDIO DEBUG] Playback devices: {devices}", flush=True)

        for attempt in range(1, retries + 1):
            for device in devices:
                try:
                    if device == "default":
                        cmd = ["aplay", "-q", str(file_path)]
                    else:
                        cmd = ["aplay", "-q", "-D", device, str(file_path)]

                    print(
                        f"[AUDIO DEBUG] attempt={attempt} device={device} file={file_path}",
                        flush=True
                    )

                    current_audio_proc = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )

                    stdout_data, stderr_data = current_audio_proc.communicate(
                        timeout=timeout_sec
                    )

                    if current_audio_proc.returncode == 0:
                        print(
                            f"[AUDIO OK] Played: {file_path} using {device}",
                            flush=True
                        )
                        return True

                    err = (stderr_data or stdout_data or "aplay failed").strip()
                    print(
                        f"[AUDIO ERROR] attempt={attempt} device={device} {err}",
                        flush=True
                    )

                    current_audio_proc = None
                    time.sleep(0.25)

                except subprocess.TimeoutExpired:
                    stop_current_audio_process()
                    print(
                        f"[AUDIO ERROR] attempt={attempt} device={device} aplay timeout",
                        flush=True
                    )
                    time.sleep(0.25)

                except Exception as exc:
                    stop_current_audio_process()
                    print(
                        f"[AUDIO ERROR] attempt={attempt} device={device} {exc}",
                        flush=True
                    )
                    time.sleep(0.25)

                finally:
                    current_audio_proc = None

        return False

def play_warning_audio(target: str = "person") -> None:
    warning_target = normalize_warning_audio_target(target)
    status_key = f"last_{warning_target}_status"
    wav = ASSET_DIR / "warning.wav"

    if not wav.exists():
        print(f"[AUDIO ERROR] Missing warning file: {wav}", flush=True)
        update_state(lambda s: s["system"].update({
            "last_error": f"Missing warning file: {wav}"
        }))
        return

    allowed, reason = is_warning_audio_allowed(warning_target)
    if not allowed:
        update_state(lambda s: s["warning_audio"].update({
            "last_status": reason,
            status_key: reason
        }))
        add_event("warning_audio_skipped", {
            "target": warning_target,
            "file": str(wav.name),
            "reason": reason
        })
        return

    update_state(lambda s: s["warning_audio"].update({
        "last_status": f"playing {warning_target}",
        status_key: "playing"
    }))
    add_event("warning_audio_playing", {
        "target": warning_target,
        "file": str(wav.name),
        "reason": reason
    })

    update_state(lambda s: s.update({
        "last_audio": {
            "file": wav.name,
            "source_path": str(wav),
            "time": now_str(),
            "status": f"playing_{warning_target}_warning"
        }
    }))

    try:
        stop_current_audio_process()

        ok = play_with_aplay(wav, timeout_sec=20)
        played_status = "played" if ok else "failed"

        update_state(lambda s: s["warning_audio"].update({
            "last_status": f"{warning_target} {played_status}",
            status_key: played_status,
            "last_played_at": now_str(),
            f"last_{warning_target}_played_at": now_str()
        }))

        update_state(lambda s: s.update({
            "last_audio": {
                "file": wav.name,
                "source_path": str(wav),
                "time": now_str(),
                "status": f"{warning_target}_warning_completed" if ok else f"{warning_target}_warning_failed"
            }
        }))

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "warning_audio_played" if ok else "warning_audio_failed",
            "target": warning_target,
            "file": wav.name,
            "time": now_str()
        })

        add_event("warning_audio", {
            "target": warning_target,
            "file": wav.name,
            "status": "completed" if ok else "failed"
        })

    except Exception as exc:
        update_state(lambda s: s["warning_audio"].update({
            "last_status": f"{warning_target} error: {exc}",
            status_key: f"error: {exc}"
        }))
        update_state(lambda s: s["system"].update({
            "last_error": f"{warning_target} warning audio error: {exc}"
        }))
        print(f"[AUDIO ERROR] {exc}", flush=True)


def build_exclusion_mask(roi_shape: Tuple[int, int]) -> np.ndarray:
    roi_h, roi_w = roi_shape
    mask = np.ones((roi_h, roi_w), dtype=np.uint8) * 255

    for rx1, ry1, rx2, ry2 in GARBAGE_EXCLUSION_ZONES:
        x1 = int(roi_w * rx1)
        y1 = int(roi_h * ry1)
        x2 = int(roi_w * rx2)
        y2 = int(roi_h * ry2)
        cv2.rectangle(mask, (x1, y1), (x2, y2), 0, thickness=-1)

    return mask


def preprocess_roi(roi: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    hsv = cv2.GaussianBlur(hsv, (5, 5), 0)
    return gray, hsv


def load_reference_roi_shape(shape: Tuple[int, int]) -> Optional[np.ndarray]:
    if not GARBAGE_REF_FILE.exists():
        return None

    ref = cv2.imread(str(GARBAGE_REF_FILE))
    if ref is None:
        return None

    h, w = shape
    if ref.shape[:2] != (h, w):
        ref = cv2.resize(ref, (w, h))
    return ref


def save_reference_roi(color_roi: np.ndarray) -> None:
    cv2.imwrite(str(GARBAGE_REF_FILE), color_roi)


def build_foreground_mask(
    curr_roi: np.ndarray,
    ref_roi: np.ndarray
) -> Tuple[np.ndarray, float, float]:

    curr_gray, curr_hsv = preprocess_roi(curr_roi)
    ref_gray,  ref_hsv  = preprocess_roi(ref_roi)

    _, curr_s, curr_v = cv2.split(curr_hsv)
    _, ref_s,  ref_v  = cv2.split(ref_hsv)

    gray_diff = cv2.absdiff(curr_gray, ref_gray)
    sat_diff  = cv2.absdiff(curr_s,    ref_s)
    val_diff  = cv2.absdiff(curr_v,    ref_v)

    # ── tighter thresholds to reduce false positives ──────────────────
    _, m1 = cv2.threshold(gray_diff, 22,  255, cv2.THRESH_BINARY)
    _, m2 = cv2.threshold(sat_diff,  28,  255, cv2.THRESH_BINARY)
    _, m3 = cv2.threshold(val_diff,  24,  255, cv2.THRESH_BINARY)

    mask = cv2.bitwise_or(m1, m2)
    mask = cv2.bitwise_or(mask, m3)

    ref_edges  = cv2.Canny(ref_gray,  50, 150)
    curr_edges = cv2.Canny(curr_gray, 50, 150)
    edge_change = cv2.absdiff(curr_edges, ref_edges)
    _, edge_change_bin = cv2.threshold(edge_change, 28, 255, cv2.THRESH_BINARY)
    mask = cv2.bitwise_or(mask, edge_change_bin)

    # ── ignore very dark pixels (night shadows) ───────────────────────
    valid_light = cv2.inRange(curr_v, 32, 255)
    mask = cv2.bitwise_and(mask, valid_light)

    if GARBAGE_EXCLUSION_ZONES:
        exclusion_mask = build_exclusion_mask(curr_roi.shape[:2])
        mask           = cv2.bitwise_and(mask, exclusion_mask)
        edge_change_bin = cv2.bitwise_and(edge_change_bin, exclusion_mask)

    k3 = np.ones((3, 3), np.uint8)
    k5 = np.ones((5, 5), np.uint8)

    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  k3)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k5)
    mask = cv2.dilate(mask, k3, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k5)

    diff_ratio       = round(float(np.count_nonzero(mask))           / float(mask.size),            4) if mask.size            else 0.0
    edge_change_ratio = round(float(np.count_nonzero(edge_change_bin)) / float(edge_change_bin.size), 4) if edge_change_bin.size else 0.0

    return mask, diff_ratio, edge_change_ratio


def contour_solidity(contour: np.ndarray) -> float:
    area = cv2.contourArea(contour)
    hull = cv2.convexHull(contour)
    hull_area = cv2.contourArea(hull)
    if hull_area <= 0:
        return 1.0
    return float(area) / float(hull_area)


def count_candidate_objects(
    curr_roi: np.ndarray,
    ref_roi: np.ndarray
) -> Tuple[int, float, float, float, List[Tuple[int, int, int, int]]]:

    mask, diff_ratio, edge_change_ratio = build_foreground_mask(curr_roi, ref_roi)

    curr_gray = cv2.cvtColor(curr_roi, cv2.COLOR_BGR2GRAY)
    ref_gray  = cv2.cvtColor(ref_roi,  cv2.COLOR_BGR2GRAY)
    curr_edges = cv2.Canny(curr_gray, 40, 120)
    ref_edges  = cv2.Canny(ref_gray,  40, 120)
    edges = cv2.absdiff(curr_edges, ref_edges)

    if GARBAGE_EXCLUSION_ZONES:
        exclusion_mask = build_exclusion_mask(curr_roi.shape[:2])
        edges = cv2.bitwise_and(edges, exclusion_mask)

    # ── improved: watershed-style separation of touching objects ──────
    sure_bg = cv2.dilate(mask, np.ones((5, 5), np.uint8), iterations=2)
    dist    = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    if dist.max() > 0:
        _, sure_fg = cv2.threshold(dist, 0.28 * dist.max(), 255, 0)
    else:
        sure_fg = mask.copy()
    sure_fg  = sure_fg.astype(np.uint8)
    unknown  = cv2.subtract(sure_bg, sure_fg)

    _, markers = cv2.connectedComponents(sure_fg)
    markers = markers + 1
    markers[unknown == 255] = 0

    roi_color = curr_roi.copy()
    markers   = cv2.watershed(roi_color, markers)
    # convert watershed boundaries back to component mask
    watershed_mask = np.zeros_like(mask)
    watershed_mask[markers > 1] = 255

    # combine original mask + watershed split mask
    combined = cv2.bitwise_or(mask, watershed_mask)

    contours, _ = cv2.findContours(combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    roi_h, roi_w = curr_roi.shape[:2]
    roi_area = float(max(roi_h * roi_w, 1))
    max_component_area = roi_area * MAX_COMPONENT_AREA_RATIO

    boxes: List[Tuple[int, int, int, int]] = []
    total_blob_area = 0.0

    for contour in contours:
        area = cv2.contourArea(contour)
        if area < MIN_COMPONENT_AREA or area > max_component_area:
            continue

        x, y, w, h = cv2.boundingRect(contour)

        if w < MIN_COMPONENT_W or h < MIN_COMPONENT_H:
            continue

        if (y + h) > int(roi_h * BOTTOM_STRIP_IGNORE_RATIO):
            continue

        box_area    = float(max(w * h, 1))
        fill_ratio  = float(area) / box_area
        if fill_ratio < MIN_FILL_RATIO or fill_ratio > MAX_FILL_RATIO:
            continue

        aspect_ratio = max(w / max(h, 1), h / max(w, 1))
        if aspect_ratio > MAX_ASPECT_RATIO:
            continue

        if len(contour) < MIN_CONTOUR_POINTS:
            continue

        solidity = contour_solidity(contour)
        if solidity > MAX_SOLIDITY and fill_ratio > 0.88:
            continue

        # edge density check — rejects flat uniform regions (shadows, ground marks)
        component_mask = np.zeros((h, w), dtype=np.uint8)
        shifted = contour.copy()
        shifted[:, 0, 0] -= x
        shifted[:, 0, 1] -= y
        cv2.drawContours(component_mask, [shifted], -1, 255, thickness=-1)

        component_edges = cv2.bitwise_and(
            edges[y:y + h, x:x + w],
            edges[y:y + h, x:x + w],
            mask=component_mask
        )
        edge_density = float(np.count_nonzero(component_edges)) / float(max(area, 1))
        if edge_density < MIN_EDGE_DENSITY:
            continue

        # ── NEW: texture variance check — rejects sky/plain-ground blobs ──
        patch = curr_roi[y:y + h, x:x + w]
        patch_gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY) if patch.ndim == 3 else patch
        variance = float(patch_gray.var())
        if variance < 28.0:
            continue

        # ── NEW: color diversity check — garbage is rarely single-tone ──
        patch_hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
        hue_std = float(patch_hsv[:, :, 0].std())
        sat_mean = float(patch_hsv[:, :, 1].mean())
        if hue_std < 4.0 and sat_mean < 18.0:
            continue

        boxes.append((x, y, x + w, y + h))
        total_blob_area += area

    blob_area_ratio = round(total_blob_area / roi_area, 4)
    edge_ratio = edge_change_ratio
    return len(boxes), diff_ratio, edge_ratio, blob_area_ratio, boxes


def garbage_count_to_severity(count: int) -> str:
    if count >= COUNT_HIGH_MIN:
        return "HIGH"
    if count >= COUNT_MEDIUM_MIN:
        return "MEDIUM"
    if count >= COUNT_LOW_MIN:
        return "LOW"
    return "NONE"


def _box_iou(box_a: Tuple[int, int, int, int], box_b: Tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    inter_w = max(0, inter_x2 - inter_x1)
    inter_h = max(0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h

    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)
    denom = float(area_a + area_b - inter_area)

    if denom <= 0.0:
        return 0.0
    return float(inter_area) / denom


def boxes_overlap_or_close(
    a: Tuple[int, int, int, int],
    b: Tuple[int, int, int, int],
    gap_px: int
) -> bool:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b

    return not (
        ax2 + gap_px < bx1 or
        bx2 + gap_px < ax1 or
        ay2 + gap_px < by1 or
        by2 + gap_px < ay1
    )


def merge_close_boxes(
    boxes: List[Tuple[int, int, int, int]],
    roi_w: int,
    roi_h: int,
    gap_px: int
) -> List[Tuple[int, int, int, int]]:
    if not boxes:
        return []

    merged = list(boxes)
    changed = True

    while changed:
        changed = False
        result: List[Tuple[int, int, int, int]] = []
        used = [False] * len(merged)

        for i, box in enumerate(merged):
            if used[i]:
                continue

            x1, y1, x2, y2 = box
            used[i] = True

            for j in range(i + 1, len(merged)):
                if used[j]:
                    continue

                other = merged[j]
                if boxes_overlap_or_close((x1, y1, x2, y2), other, gap_px):
                    ox1, oy1, ox2, oy2 = other
                    x1 = min(x1, ox1)
                    y1 = min(y1, oy1)
                    x2 = max(x2, ox2)
                    y2 = max(y2, oy2)
                    used[j] = True
                    changed = True

            x1 = max(0, min(roi_w - 1, x1))
            y1 = max(0, min(roi_h - 1, y1))
            x2 = max(0, min(roi_w - 1, x2))
            y2 = max(0, min(roi_h - 1, y2))

            if x2 > x1 and y2 > y1:
                result.append((x1, y1, x2, y2))

        merged = result

    return merged


def garbage_change_box_allowed(
    roi: np.ndarray,
    box: Tuple[int, int, int, int],
    roi_area: float
) -> bool:
    roi_h, roi_w = roi.shape[:2]
    x1, y1, x2, y2 = box

    bw = x2 - x1
    bh = y2 - y1
    if bw <= 0 or bh <= 0:
        return False

    area = float(bw * bh)

    min_area = max(
        int(GARBAGE_CHANGE_MIN_AREA_PX),
        int(roi_area * GARBAGE_CHANGE_MIN_AREA_RATIO)
    )
    min_w = max(22, int(roi_w * GARBAGE_CHANGE_MIN_WIDTH_RATIO))
    min_h = max(22, int(roi_h * GARBAGE_CHANGE_MIN_HEIGHT_RATIO))

    if area < min_area:
        return False

    if bw < min_w or bh < min_h:
        return False

    if area > roi_area * GARBAGE_MAX_BOX_AREA_RATIO:
        return False

    cx = x1 + (bw // 2)
    cy = y1 + (bh // 2)

    for rx1, ry1, rx2, ry2 in GARBAGE_EXCLUSION_ZONES:
        ex1 = int(roi_w * rx1)
        ey1 = int(roi_h * ry1)
        ex2 = int(roi_w * rx2)
        ey2 = int(roi_h * ry2)
        if ex1 <= cx <= ex2 and ey1 <= cy <= ey2:
            return False

    patch = roi[y1:y2, x1:x2]
    if patch is None or patch.size == 0:
        return False

    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)

    variance = float(gray.var())
    saturation_mean = float(hsv[:, :, 1].mean())

    # Reject small plain ground/shadow/light patches.
    # White bags/paper usually still have enough texture/edge variance.
    if variance < GARBAGE_MIN_TEXTURE_VARIANCE and saturation_mean < GARBAGE_MIN_SATURATION_MEAN:
        return False

    return True


def _load_reference_frame() -> Optional[np.ndarray]:
    if not GARBAGE_REF_FILE.exists():
        return None

    ref = cv2.imread(str(GARBAGE_REF_FILE))
    return ref if ref is not None else None


def _safe_upload_filename(filename: str) -> str:
    base_name = str(filename or "").replace("\\", "/").split("/")[-1]
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", base_name).strip("._")
    return safe_name or "uploaded_reference_image"


def save_garbage_reference_frame(
    frame: np.ndarray,
    source: str,
    message: str,
    original_filename: str = ""
) -> Dict[str, Any]:
    if frame is None or frame.size == 0:
        raise RuntimeError("Reference image is empty")

    GARBAGE_REF_FILE.parent.mkdir(parents=True, exist_ok=True)

    tmp_file = GARBAGE_REF_FILE.with_name(
        GARBAGE_REF_FILE.stem + ".tmp" + GARBAGE_REF_FILE.suffix
    )

    ok = cv2.imwrite(str(tmp_file), frame, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    if not ok:
        raise RuntimeError(f"Failed to save reference image: {GARBAGE_REF_FILE}")

    tmp_file.replace(GARBAGE_REF_FILE)

    now = now_dt()
    safe_original_filename = _safe_upload_filename(original_filename)

    update_state(lambda s: s.update({
        "last_garbage": {
            "detected": False,
            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "image": s.get("last_garbage", {}).get("image"),
            "severity": "NONE",
            "diff_ratio": 0.0,
            "edge_ratio": 0.0,
            "blob_area_ratio": 0.0,
            "blob_count": 0,
            "triggered_by": source,
            "reference_items": ["Reference updated"]
        }
    }), force_flush=True)

    event_name = (
        "garbage_reference_uploaded"
        if source == "garbage_reference_upload"
        else "garbage_reference_captured"
    )

    event_payload = {
        "file": GARBAGE_REF_FILE.name,
        "time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "source": source,
        "width": int(frame.shape[1]),
        "height": int(frame.shape[0])
    }

    if original_filename:
        event_payload["original_filename"] = safe_original_filename

    add_event(event_name, event_payload)

    result = {
        "file": str(GARBAGE_REF_FILE),
        "updated_at": now.isoformat(),
        "source": source,
        "width": int(frame.shape[1]),
        "height": int(frame.shape[0]),
        "message": message
    }

    if original_filename:
        result["original_filename"] = safe_original_filename

    return result


def capture_garbage_reference_from_live() -> Dict[str, Any]:
    frame = get_frame_copy()
    if frame is None:
        raise RuntimeError("No live frame available")

    return save_garbage_reference_frame(
        frame=frame,
        source="garbage_sample_capture",
        message="Garbage reference image captured successfully"
    )


def normalize_uploaded_reference_to_live_frame(reference_frame: np.ndarray) -> np.ndarray:
    """
    AI-cleaned reference image must match the live RTSP frame size.

    If the uploaded reference comes from WhatsApp/mobile/gallery, it may be
    resized. Comparing 1455x1080 against 640x480 weakens corner matching.
    This stores the uploaded reference in the current live-frame size.
    """
    if reference_frame is None or reference_frame.size == 0:
        raise RuntimeError("Reference image is empty")

    live_frame = get_frame_copy()

    if live_frame is None or live_frame.size == 0:
        return reference_frame

    target_h, target_w = live_frame.shape[:2]
    src_h, src_w = reference_frame.shape[:2]

    if target_h <= 0 or target_w <= 0 or src_h <= 0 or src_w <= 0:
        return reference_frame

    if (src_h, src_w) == (target_h, target_w):
        return reference_frame

    src_aspect = float(src_w) / float(max(src_h, 1))
    target_aspect = float(target_w) / float(max(target_h, 1))
    aspect_error = abs(src_aspect - target_aspect) / float(max(target_aspect, 0.0001))

    if aspect_error > GARBAGE_REFERENCE_ASPECT_TOLERANCE:
        raise RuntimeError(
            "Uploaded reference image aspect ratio does not match live camera. "
            "Upload an AI-cleaned image made from the same raw RTSP snapshot."
        )

    return cv2.resize(
        reference_frame,
        (target_w, target_h),
        interpolation=cv2.INTER_AREA if src_w > target_w or src_h > target_h else cv2.INTER_LINEAR
    )


def upload_garbage_reference_from_request(upload_file: Any) -> Dict[str, Any]:
    if upload_file is None or not getattr(upload_file, "filename", ""):
        raise RuntimeError("No reference image selected")

    raw = upload_file.read(GARBAGE_REF_UPLOAD_MAX_BYTES + 1)
    if not raw:
        raise RuntimeError("Uploaded reference image is empty")

    if len(raw) > GARBAGE_REF_UPLOAD_MAX_BYTES:
        max_mb = GARBAGE_REF_UPLOAD_MAX_BYTES // (1024 * 1024)
        raise RuntimeError(f"Reference image is too large. Maximum allowed size is {max_mb} MB")

    np_buffer = np.frombuffer(raw, dtype=np.uint8)
    frame = cv2.imdecode(np_buffer, cv2.IMREAD_COLOR)

    if frame is None or frame.size == 0:
        raise RuntimeError("Uploaded file is not a valid image")

    frame = normalize_uploaded_reference_to_live_frame(frame)

    return save_garbage_reference_frame(
        frame=frame,
        source="garbage_reference_upload",
        message="Garbage reference image uploaded successfully",
        original_filename=upload_file.filename
    )

def draw_garbage_boxes(
    frame: np.ndarray,
    roi_box: Tuple[int, int, int, int],
    detections: List[Dict[str, Any]],
    severity: str,
    change_boxes: Optional[List[Tuple[int, int, int, int]]] = None
) -> np.ndarray:
    out = frame.copy()
    x1_roi, y1_roi, x2_roi, y2_roi = roi_box

    color = (160, 160, 160)
    if severity == "LOW":
        color = (0, 255, 0)
    elif severity == "MEDIUM":
        color = (0, 165, 255)
    elif severity == "HIGH":
        color = (0, 0, 255)

    garbage_points = get_garbage_polygon_pixels(frame)

    if len(garbage_points) >= 3:
        polygon_np = np.array(garbage_points, dtype=np.int32)
        cv2.polylines(out, [polygon_np], True, (0, 255, 255), 2, cv2.LINE_AA)
    else:
        cv2.rectangle(out, (x1_roi, y1_roi), (x2_roi, y2_roi), (0, 255, 255), 2)

    for det in detections:
        x1, y1, x2, y2 = det["box"]
        gx1 = x1 + x1_roi
        gy1 = y1 + y1_roi
        gx2 = x2 + x1_roi
        gy2 = y2 + y1_roi

        cv2.rectangle(out, (gx1, gy1), (gx2, gy2), color, 2)

    for box in change_boxes or []:
        x1, y1, x2, y2 = box
        gx1 = x1 + x1_roi
        gy1 = y1 + y1_roi
        gx2 = x2 + x1_roi
        gy2 = y2 + y1_roi

        cv2.rectangle(out, (gx1, gy1), (gx2, gy2), color, 2)

    return out


def garbage_diff_to_severity(diff_ratio: float, blob_area_ratio: float = 0.0) -> str:
    signal = max(float(diff_ratio or 0.0), float(blob_area_ratio or 0.0))

    if signal >= 0.18:
        return "HIGH"
    if signal >= 0.08:
        return "MEDIUM"
    if signal >= 0.025:
        return "LOW"

    return "NONE"


def garbage_severity_rank(severity: str) -> int:
    order = {
        "NONE": 0,
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3
    }
    return order.get(str(severity or "NONE").upper(), 0)


def max_garbage_severity(a: str, b: str) -> str:
    a = str(a or "NONE").upper()
    b = str(b or "NONE").upper()

    return a if garbage_severity_rank(a) >= garbage_severity_rank(b) else b


def garbage_severity_to_min_count(severity: str) -> int:
    severity = str(severity or "NONE").upper()

    if severity == "HIGH":
        return COUNT_HIGH_MIN
    if severity == "MEDIUM":
        return COUNT_MEDIUM_MIN
    if severity == "LOW":
        return COUNT_LOW_MIN

    return 0


def _box_area(box: Tuple[int, int, int, int]) -> float:
    x1, y1, x2, y2 = box
    return float(max(0, x2 - x1) * max(0, y2 - y1))


def _clip_box(
    box: Tuple[int, int, int, int],
    roi_w: int,
    roi_h: int
) -> Optional[Tuple[int, int, int, int]]:
    x1, y1, x2, y2 = box
    x1 = max(0, min(roi_w - 1, int(x1)))
    y1 = max(0, min(roi_h - 1, int(y1)))
    x2 = max(0, min(roi_w - 1, int(x2)))
    y2 = max(0, min(roi_h - 1, int(y2)))

    if x2 <= x1 or y2 <= y1:
        return None

    return x1, y1, x2, y2


def _box_too_large_for_marker(
    box: Tuple[int, int, int, int],
    roi_area: float
) -> bool:
    return _box_area(box) > float(roi_area) * 0.18


def _add_non_duplicate_boxes(
    base_boxes: List[Tuple[int, int, int, int]],
    candidate_boxes: List[Tuple[int, int, int, int]],
    max_boxes: int = 30
) -> List[Tuple[int, int, int, int]]:
    result = list(base_boxes)

    for candidate in candidate_boxes:
        duplicate = False

        for existing in result:
            if _box_iou(candidate, existing) >= 0.25:
                duplicate = True
                break

        if not duplicate:
            result.append(candidate)

        if len(result) >= max_boxes:
            break

    return result

def _polygon_valid_mask_from_roi(roi: np.ndarray) -> np.ndarray:
    """
    get_garbage_roi() returns a polygon-masked crop.
    Outside polygon becomes black. This mask prevents fallback detection outside
    the yellow polygon area.
    """
    if roi is None or roi.size == 0:
        return np.zeros((1, 1), dtype=np.uint8)

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    return cv2.inRange(gray, 6, 255)


def _yellow_ratio_from_patch(patch: np.ndarray) -> float:
    if patch is None or patch.size == 0:
        return 0.0

    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
    hue = hsv[:, :, 0]
    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]

    yellow = (
        (hue >= 16) &
        (hue <= 42) &
        (sat >= 45) &
        (val >= 105)
    )

    return float(np.count_nonzero(yellow)) / float(max(yellow.size, 1))


def static_corner_garbage_boxes_from_roi(
    roi: np.ndarray,
    roi_w: int,
    roi_h: int,
    roi_area: float
) -> List[Tuple[int, int, int, int]]:
    """
    Add-on detector for missed corner/static garbage.

    Important:
    This does NOT replace old reference-difference boxes.
    It only adds extra boxes when the AI-cleaned reference still contains
    similar garbage in the corner.
    """
    if roi is None or roi.size == 0:
        return []

    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    hue = hsv[:, :, 0]
    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]

    valid_polygon = _polygon_valid_mask_from_roi(roi)

    green_mask = (
        (hue >= 35) &
        (hue <= 95) &
        (sat >= 35) &
        (val >= 35)
    )

    soil_mask = (
        (hue >= 5) &
        (hue <= 32) &
        (sat >= 16) &
        (sat <= 155) &
        (val >= 42) &
        (val <= 210)
    )

    white_litter = (
        ((val >= 148) & (sat <= 95)) |
        ((val >= 188) & (sat <= 150))
    )

    colored_litter = (
        (sat >= 76) &
        (val >= 72) &
        (~green_mask) &
        (~soil_mask)
    )

    object_mask = (white_litter | colored_litter).astype(np.uint8) * 255
    object_mask = cv2.bitwise_and(object_mask, valid_polygon)

    edges = cv2.Canny(gray, 45, 145)
    edges = cv2.bitwise_and(edges, valid_polygon)

    tile_size = max(24, int(min(roi_w, roi_h) * float(GARBAGE_STATIC_TILE_SIZE_RATIO)))
    step = max(14, int(min(roi_w, roi_h) * float(GARBAGE_STATIC_TILE_STEP_RATIO)))

    boxes: List[Tuple[int, int, int, int]] = []

    ys = list(range(0, max(1, roi_h - tile_size + 1), step))
    xs = list(range(0, max(1, roi_w - tile_size + 1), step))

    last_y = max(0, roi_h - tile_size)
    last_x = max(0, roi_w - tile_size)

    if not ys or ys[-1] != last_y:
        ys.append(last_y)

    if not xs or xs[-1] != last_x:
        xs.append(last_x)

    for y in ys:
        for x in xs:
            x2 = min(roi_w, x + tile_size)
            y2 = min(roi_h, y + tile_size)

            if x2 <= x or y2 <= y:
                continue

            tile_area = float((x2 - x) * (y2 - y))
            valid_patch = valid_polygon[y:y2, x:x2]
            valid_pixels = int(np.count_nonzero(valid_patch))

            if valid_pixels < int(tile_area * 0.55):
                continue

            patch_object = object_mask[y:y2, x:x2]
            patch_edges = edges[y:y2, x:x2]
            patch_green = green_mask[y:y2, x:x2]
            patch_soil = soil_mask[y:y2, x:x2]
            patch_rgb = roi[y:y2, x:x2]

            object_ratio = float(np.count_nonzero(patch_object)) / float(max(valid_pixels, 1))
            edge_ratio = float(np.count_nonzero(patch_edges)) / float(max(valid_pixels, 1))
            green_ratio = float(np.count_nonzero(patch_green)) / float(max(valid_pixels, 1))
            soil_ratio = float(np.count_nonzero(patch_soil)) / float(max(valid_pixels, 1))
            yellow_ratio = _yellow_ratio_from_patch(patch_rgb)

            if object_ratio < float(GARBAGE_STATIC_MIN_OBJECT_RATIO):
                continue

            if edge_ratio < float(GARBAGE_STATIC_MIN_EDGE_RATIO):
                continue

            if green_ratio > float(GARBAGE_STATIC_MAX_GREEN_RATIO) and object_ratio < 0.095:
                continue

            if soil_ratio > float(GARBAGE_STATIC_MAX_SOIL_RATIO) and object_ratio < 0.080:
                continue

            if yellow_ratio > 0.10:
                continue

            box = _clip_box((x, y, x2, y2), roi_w, roi_h)

            if box is None:
                continue

            boxes.append(box)

    if not boxes:
        return []

    boxes = merge_close_boxes(
        boxes,
        roi_w,
        roi_h,
        max(5, int(min(roi_w, roi_h) * 0.012))
    )

    min_area = max(180.0, roi_area * 0.00045)
    max_area = roi_area * 0.18

    filtered: List[Tuple[int, int, int, int]] = []

    for box in boxes:
        area = _box_area(box)

        if area < min_area or area > max_area:
            continue

        x1, y1, x2, y2 = box
        patch = roi[y1:y2, x1:x2]

        if patch is None or patch.size == 0:
            continue

        if _yellow_ratio_from_patch(patch) > 0.10:
            continue

        filtered.append(box)

    filtered.sort(key=_box_area, reverse=True)

    return filtered[:int(GARBAGE_STATIC_MAX_BOXES)]


def _boxes_from_binary_mask_tiles(
    binary_mask: np.ndarray,
    roi_w: int,
    roi_h: int,
    roi_area: float,
    max_boxes: int = 35
) -> List[Tuple[int, int, int, int]]:
    boxes: List[Tuple[int, int, int, int]] = []

    if binary_mask is None or binary_mask.size == 0:
        return boxes

    tile_w = max(36, int(roi_w * 0.07))
    tile_h = max(32, int(roi_h * 0.07))

    min_pixels = max(90, int(tile_w * tile_h * 0.08))
    min_box_area = max(240.0, roi_area * 0.00055)
    max_box_area = roi_area * 0.08

    for y in range(0, roi_h, tile_h):
        for x in range(0, roi_w, tile_w):
            x2 = min(roi_w, x + tile_w)
            y2 = min(roi_h, y + tile_h)

            tile = binary_mask[y:y2, x:x2]

            if tile is None or tile.size == 0:
                continue

            changed_pixels = cv2.countNonZero(tile)

            if changed_pixels < min_pixels:
                continue

            contours, _ = cv2.findContours(
                tile,
                cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE
            )

            if not contours:
                continue

            xs: List[int] = []
            ys: List[int] = []
            xe: List[int] = []
            ye: List[int] = []

            for contour in contours:
                area = cv2.contourArea(contour)

                if area < 18:
                    continue

                bx, by, bw, bh = cv2.boundingRect(contour)

                if bw < 5 or bh < 5:
                    continue

                xs.append(x + bx)
                ys.append(y + by)
                xe.append(x + bx + bw)
                ye.append(y + by + bh)

            if not xs:
                continue

            pad = max(4, int(min(tile_w, tile_h) * 0.10))

            box = _clip_box(
                (
                    min(xs) - pad,
                    min(ys) - pad,
                    max(xe) + pad,
                    max(ye) + pad
                ),
                roi_w,
                roi_h
            )

            if box is None:
                continue

            box_area = _box_area(box)

            if box_area < min_box_area:
                continue

            if box_area > max_box_area:
                continue

            boxes.append(box)

    boxes.sort(key=_box_area, reverse=True)

    boxes = merge_close_boxes(
        boxes[:max_boxes * 2],
        roi_w,
        roi_h,
        max(3, int(min(roi_w, roi_h) * 0.004))
    )

    boxes = [
        box for box in boxes
        if min_box_area <= _box_area(box) <= max_box_area
    ]

    boxes.sort(key=_box_area, reverse=True)

    return boxes[:max_boxes]


def particular_diff_boxes_from_mask(
    roi: np.ndarray,
    ref_roi: np.ndarray,
    diff_mask: np.ndarray,
    roi_w: int,
    roi_h: int,
    roi_area: float
) -> List[Tuple[int, int, int, int]]:
    if roi is None or ref_roi is None or diff_mask is None or diff_mask.size == 0:
        return []

    curr_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    ref_gray = cv2.cvtColor(ref_roi, cv2.COLOR_BGR2GRAY)
    gray_diff = cv2.absdiff(curr_gray, ref_gray)

    curr_hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    ref_hsv = cv2.cvtColor(ref_roi, cv2.COLOR_BGR2HSV)
    _, curr_s, curr_v = cv2.split(curr_hsv)
    _, ref_s, ref_v = cv2.split(ref_hsv)

    sat_diff = cv2.absdiff(curr_s, ref_s)
    val_diff = cv2.absdiff(curr_v, ref_v)

    _, strong_gray = cv2.threshold(gray_diff, 34, 255, cv2.THRESH_BINARY)
    _, strong_sat = cv2.threshold(sat_diff, 34, 255, cv2.THRESH_BINARY)
    _, strong_val = cv2.threshold(val_diff, 36, 255, cv2.THRESH_BINARY)

    curr_edges = cv2.Canny(curr_gray, 45, 135)
    ref_edges = cv2.Canny(ref_gray, 45, 135)
    edge_change = cv2.absdiff(curr_edges, ref_edges)
    _, edge_change = cv2.threshold(edge_change, 24, 255, cv2.THRESH_BINARY)

    k3 = np.ones((3, 3), np.uint8)

    detail_mask = cv2.bitwise_or(strong_gray, strong_sat)
    detail_mask = cv2.bitwise_or(detail_mask, strong_val)
    detail_mask = cv2.bitwise_and(detail_mask, diff_mask)

    edge_near_change = cv2.dilate(edge_change, k3, iterations=1)
    detail_mask = cv2.bitwise_or(
        cv2.bitwise_and(detail_mask, edge_near_change),
        cv2.bitwise_and(strong_gray, strong_val)
    )

    if GARBAGE_EXCLUSION_ZONES:
        exclusion_mask = build_exclusion_mask(roi.shape[:2])
        detail_mask = cv2.bitwise_and(detail_mask, exclusion_mask)

    detail_mask = cv2.morphologyEx(detail_mask, cv2.MORPH_OPEN, k3)
    detail_mask = cv2.morphologyEx(detail_mask, cv2.MORPH_CLOSE, k3)

    contours, _ = cv2.findContours(detail_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    min_area = max(180.0, roi_area * 0.00045)
    max_area = roi_area * 0.18
    boxes: List[Tuple[int, int, int, int]] = []

    for contour in contours:
        area = cv2.contourArea(contour)
        if area < min_area:
            continue

        x, y, w, h = cv2.boundingRect(contour)
        if w < max(8, int(roi_w * 0.012)) or h < max(8, int(roi_h * 0.012)):
            continue

        box = _clip_box((x, y, x + w, y + h), roi_w, roi_h)
        if box is None:
            continue

        if _box_area(box) > max_area:
            continue

        boxes.append(box)

    if len(boxes) <= 1:
        tile_boxes = _boxes_from_binary_mask_tiles(detail_mask, roi_w, roi_h, roi_area)
        if len(tile_boxes) > len(boxes):
            boxes = tile_boxes

    boxes.sort(key=_box_area, reverse=True)
    boxes = merge_close_boxes(
        boxes[:40],
        roi_w,
        roi_h,
        max(4, int(min(roi_w, roi_h) * 0.006))
    )
    boxes = [box for box in boxes if not _box_too_large_for_marker(box, roi_area)]
    boxes.sort(key=_box_area, reverse=True)

    return boxes[:30]


def analyze_garbage_once(frame: np.ndarray) -> Dict[str, Any]:
    reference_frame = _load_reference_frame()
    roi, roi_box = get_garbage_roi(frame)

    if reference_frame is None:
        marked = draw_garbage_boxes(
            frame=frame,
            roi_box=roi_box,
            detections=[],
            severity="NONE",
            change_boxes=[]
        )

        cv2.putText(
            marked,
            "Reference Missing - Send Garbage Sample Capture",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (0, 0, 255),
            2,
            cv2.LINE_AA
        )

        return {
            "severity": "NONE",
            "diff_ratio": 0.0,
            "edge_ratio": 0.0,
            "blob_area_ratio": 0.0,
            "blob_count": 0,
            "boxes": [],
            "detections": [],
            "garbage_labels": [],
            "marked_frame": marked,
            "roi_color": roi.copy(),
            "ref_missing": True,
            "change_boxes": [],
            "object_count": 0,
            "change_count": 0,
            "object_confidence": 0.0,
            "raw_change_count": 0,
            "merged_change_count": 0
        }

    ref_roi, _ = get_garbage_roi(reference_frame)

    if ref_roi.shape[:2] != roi.shape[:2]:
        ref_roi = cv2.resize(
            ref_roi,
            (roi.shape[1], roi.shape[0]),
            interpolation=cv2.INTER_LINEAR
        )

    roi_h, roi_w = roi.shape[:2]
    roi_area = float(max(roi_h * roi_w, 1))

    diff_mask, diff_ratio, edge_change_ratio = build_foreground_mask(roi, ref_roi)

    contours, _ = cv2.findContours(
        diff_mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    raw_change_boxes: List[Tuple[int, int, int, int]] = []

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        candidate_box = (x, y, x + w, y + h)

        if not garbage_change_box_allowed(roi, candidate_box, roi_area):
            continue

        raw_change_boxes.append(candidate_box)

    merge_gap_px = max(
        14,
        int(min(roi_w, roi_h) * GARBAGE_CHANGE_MERGE_GAP_RATIO)
    )

    merged_change_boxes = merge_close_boxes(
        raw_change_boxes,
        roi_w,
        roi_h,
        merge_gap_px
    )

    change_boxes: List[Tuple[int, int, int, int]] = []
    change_area_sum = 0.0

    for box in merged_change_boxes:
        if not garbage_change_box_allowed(roi, box, roi_area):
            continue

        x1, y1, x2, y2 = box
        change_boxes.append(box)
        change_area_sum += float((x2 - x1) * (y2 - y1))

    detections = detect_garbage_objects(roi)

    extra_change_boxes: List[Tuple[int, int, int, int]] = []

    for cbox in change_boxes:
        matched = False

        for det in detections:
            if _box_iou(cbox, det["box"]) >= 0.10:
                matched = True
                break

        if not matched:
            extra_change_boxes.append(cbox)

    blob_area_ratio = round(change_area_sum / roi_area, 4)

    # Always calculate severity from the total changed area.
    # This is important when uploaded reference comparison creates one large merged
    # change box: count-based severity alone would say LOW even though the area is HIGH.
    diff_fallback_severity = garbage_diff_to_severity(
        diff_ratio=diff_ratio,
        blob_area_ratio=blob_area_ratio
    )
    diff_fallback_used = False

    particular_change_boxes = particular_diff_boxes_from_mask(
        roi=roi,
        ref_roi=ref_roi,
        diff_mask=diff_mask,
        roi_w=roi_w,
        roi_h=roi_h,
        roi_area=roi_area
    )

    # Night/grayscale/low-contrast frames may make the stricter particular detector
    # return zero boxes even when diff_ratio is high. In that case, split the
    # changed mask into small local tile boxes.
    if not particular_change_boxes and diff_fallback_severity != "NONE":
        particular_change_boxes = _boxes_from_binary_mask_tiles(
            binary_mask=diff_mask,
            roi_w=roi_w,
            roi_h=roi_h,
            roi_area=roi_area,
            max_boxes=35
        )

    static_corner_boxes = static_corner_garbage_boxes_from_roi(
        roi=roi,
        roi_w=roi_w,
        roi_h=roi_h,
        roi_area=roi_area
    )

    # IMPORTANT:
    # Keep old reference-difference boxes as the primary visual result.
    # Do not replace large old boxes with smaller boxes.
    # Just add non-duplicate particular/static corner boxes.
    if diff_fallback_severity != "NONE":
        if particular_change_boxes:
            extra_change_boxes = _add_non_duplicate_boxes(
                extra_change_boxes,
                particular_change_boxes,
                max_boxes=55
            )

        if static_corner_boxes:
            extra_change_boxes = _add_non_duplicate_boxes(
                extra_change_boxes,
                static_corner_boxes,
                max_boxes=65
            )

        if not extra_change_boxes:
            extra_change_boxes = _add_non_duplicate_boxes(
                particular_change_boxes,
                static_corner_boxes,
                max_boxes=65
            )
            diff_fallback_used = True

    total_count = len(detections) + len(extra_change_boxes)

    count_severity = garbage_count_to_severity(total_count)
    severity = max_garbage_severity(count_severity, diff_fallback_severity)

    if severity != "NONE":
        total_count = max(total_count, garbage_severity_to_min_count(severity))

    display_labels = [d["display_label"] for d in detections]

    if extra_change_boxes:
        label = "Mixed Trash"
        if diff_fallback_used:
            label = "Large Mixed Trash"

        display_labels.extend([label] * len(extra_change_boxes))

    avg_conf = round(
        float(sum(d["confidence"] for d in detections)) / float(max(len(detections), 1)),
        4
    ) if detections else 0.0

    edge_ratio = round(
        float(len(extra_change_boxes)) / float(max(total_count, 1)),
        4
    )

    marked = draw_garbage_boxes(
        frame,
        roi_box,
        detections,
        severity,
        extra_change_boxes
    )

    return {
        "severity": severity,
        "diff_ratio": diff_ratio,
        "edge_ratio": edge_ratio,
        "blob_area_ratio": blob_area_ratio,
        "blob_count": total_count,
        "boxes": [d["box"] for d in detections],
        "detections": detections,
        "garbage_labels": display_labels,
        "marked_frame": marked,
        "roi_color": roi.copy(),
        "ref_missing": False,
        "change_boxes": extra_change_boxes,
        "object_count": len(detections),
        "change_count": len(extra_change_boxes),
        "object_confidence": avg_conf,
        "raw_change_count": len(raw_change_boxes),
        "merged_change_count": len(change_boxes),
        "diff_fallback_used": diff_fallback_used,
        "diff_fallback_severity": diff_fallback_severity
    }


def analyze_garbage_stable() -> Optional[Dict[str, Any]]:
    samples = []

    for idx in range(GARBAGE_CAPTURE_SAMPLES):
        frame = get_frame_copy()
        if frame is None:
            time.sleep(0.2)
            continue

        result = analyze_garbage_once(frame)
        samples.append(result)

        if idx < (GARBAGE_CAPTURE_SAMPLES - 1):
            time.sleep(GARBAGE_SAMPLE_GAP_SEC)

    if not samples:
        return None

    # Prefer the sample with the highest blob_count. This is better for dump events.
    samples.sort(key=lambda item: (
        not item.get("ref_missing", False),
        int(item.get("blob_count", 0)),
        float(item.get("blob_area_ratio", 0.0))
    ), reverse=True)

    return samples[0]


def cloudflare_is_active() -> bool:
    return cloudflare_proc is not None and cloudflare_proc.poll() is None and bool(cloudflare_url)


def stop_live_tunnel() -> None:
    global cloudflare_proc, cloudflare_url, cloudflare_expiry_ts, cloudflare_stop_timer

    with cloudflare_lock:
        if cloudflare_stop_timer is not None:
            try:
                cloudflare_stop_timer.cancel()
            except Exception:
                pass
            cloudflare_stop_timer = None

        if cloudflare_proc is not None:
            try:
                cloudflare_proc.terminate()
                cloudflare_proc.wait(timeout=5)
            except Exception:
                try:
                    cloudflare_proc.kill()
                except Exception:
                    pass

        cloudflare_proc = None
        cloudflare_url = None
        cloudflare_expiry_ts = 0.0

    update_state(lambda s: s["live_link"].update({"active": False, "url": None, "expires_at": None}), force_flush=True)


def start_live_tunnel(duration_sec: int = LIVE_LINK_DURATION_SEC) -> Optional[str]:
    global cloudflare_proc, cloudflare_url, cloudflare_expiry_ts, cloudflare_stop_timer

    with cloudflare_lock:
        now_ts = time.time()

        if cloudflare_is_active() and cloudflare_url:
            cloudflare_expiry_ts = now_ts + duration_sec

            if cloudflare_stop_timer is not None:
                try:
                    cloudflare_stop_timer.cancel()
                except Exception:
                    pass

            cloudflare_stop_timer = threading.Timer(duration_sec, stop_live_tunnel)
            cloudflare_stop_timer.daemon = True
            cloudflare_stop_timer.start()

            expires_at = dt.datetime.fromtimestamp(cloudflare_expiry_ts).strftime("%Y-%m-%d %H:%M:%S")
            update_state(lambda s: s["live_link"].update({"active": True, "url": f"{cloudflare_url}/live", "expires_at": expires_at}), force_flush=True)
            return cloudflare_url

        if not Path(CLOUDFLARED_BIN).exists():
            return None

        if cloudflare_proc is not None:
            try:
                cloudflare_proc.terminate()
                cloudflare_proc.wait(timeout=5)
            except Exception:
                try:
                    cloudflare_proc.kill()
                except Exception:
                    pass

        cmd = [CLOUDFLARED_BIN, "tunnel", "--url", f"http://127.0.0.1:{PORT}", "--no-autoupdate"]
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        found_url = None
        deadline = time.time() + 25
        pattern = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.IGNORECASE)

        while time.time() < deadline:
            line = proc.stdout.readline()
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(0.2)
                continue

            match = pattern.search(line)
            if match:
                found_url = match.group(0).rstrip("/")
                break

        if not found_url:
            try:
                proc.terminate()
            except Exception:
                pass
            return None

        cloudflare_proc = proc
        cloudflare_url = found_url
        cloudflare_expiry_ts = time.time() + duration_sec

        if cloudflare_stop_timer is not None:
            try:
                cloudflare_stop_timer.cancel()
            except Exception:
                pass

        cloudflare_stop_timer = threading.Timer(duration_sec, stop_live_tunnel)
        cloudflare_stop_timer.daemon = True
        cloudflare_stop_timer.start()

        expires_at = dt.datetime.fromtimestamp(cloudflare_expiry_ts).strftime("%Y-%m-%d %H:%M:%S")
        update_state(lambda s: s["live_link"].update({"active": True, "url": f"{found_url}/live", "expires_at": expires_at}), force_flush=True)
        return found_url

def permanent_live_url() -> Optional[str]:
    return PERMANENT_LIVE_URL


def permanent_dashboard_url() -> Optional[str]:
    return PERMANENT_DASHBOARD_URL

def build_live_links_payload(force_new: bool = False) -> Dict[str, Any]:
    if is_power_saving_active():
        return {
            "dashboard_url_temp": None,
            "live_stream_url_temp": None,
            "live_expires_in_sec": 0,
            "live_expires_at": None,
            "live_status": "blocked_power_saving"
        }

    live_base = start_live_tunnel(LIVE_LINK_DURATION_SEC) if force_new else (cloudflare_url if cloudflare_is_active() else None)
    expires_at = dt.datetime.fromtimestamp(cloudflare_expiry_ts).isoformat() if cloudflare_expiry_ts > 0 else None
    return {
        "dashboard_url_temp": live_base if live_base else None,
        "live_stream_url_temp": f"{live_base}/live" if live_base else None,
        "live_expires_in_sec": int(max(cloudflare_expiry_ts - time.time(), 0)) if live_base else 0,
        "live_expires_at": expires_at
    }


def build_common_links_payload() -> Dict[str, Any]:
    return {
        "dashboard_url_local": local_dashboard_url(),
        "live_stream_url_local": local_stream_url(),
        "camera_config_url": PERMANENT_CAMERA_CONFIG_URL,
        "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
    }


def get_pi_temperature_c() -> Optional[float]:
    try:
        out = subprocess.check_output(["vcgencmd", "measure_temp"], text=True, timeout=3).strip()
        m = re.search(r"([0-9]+(?:\.[0-9]+)?)", out)
        if m:
            return round(float(m.group(1)), 2)
    except Exception:
        pass

    try:
        raw = Path("/sys/class/thermal/thermal_zone0/temp").read_text(encoding="utf-8").strip()
        return round(float(raw) / 1000.0, 2)
    except Exception:
        return None


def detect_primary_iface() -> Optional[str]:
    try:
        out = subprocess.check_output(["ip", "route", "get", "8.8.8.8"], text=True, timeout=3)
        m = re.search(r"\bdev\s+([a-zA-Z0-9._-]+)", out)
        if m:
            return m.group(1)
    except Exception:
        pass

    try:
        out = subprocess.check_output(["ip", "route", "show", "default"], text=True, timeout=3)
        m = re.search(r"\bdev\s+([a-zA-Z0-9._-]+)", out)
        if m:
            return m.group(1)
    except Exception:
        pass

    for candidate in ["eth0", "wlan0"]:
        if Path(f"/sys/class/net/{candidate}").exists():
            return candidate
    return None


def read_iface_link_speed(iface: Optional[str]) -> Optional[int]:
    if not iface:
        return None
    path = Path(f"/sys/class/net/{iface}/speed")
    try:
        raw = path.read_text(encoding="utf-8").strip()
        val = int(raw)
        return val if val > 0 else None
    except Exception:
        return None


def read_iface_operstate(iface: Optional[str]) -> str:
    if not iface:
        return "down"
    try:
        return Path(f"/sys/class/net/{iface}/operstate").read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def read_iface_bytes(iface: Optional[str]) -> Tuple[int, int]:
    if not iface:
        return 0, 0
    try:
        rx = int(Path(f"/sys/class/net/{iface}/statistics/rx_bytes").read_text(encoding="utf-8").strip())
        tx = int(Path(f"/sys/class/net/{iface}/statistics/tx_bytes").read_text(encoding="utf-8").strip())
        return rx, tx
    except Exception:
        return 0, 0


def calc_network_rates(iface: Optional[str]) -> Tuple[int, int]:
    global last_net_rx, last_net_tx, last_net_ts
    rx, tx = read_iface_bytes(iface)
    now_ts = time.time()

    if last_net_rx is None or last_net_tx is None or last_net_ts is None:
        last_net_rx = rx
        last_net_tx = tx
        last_net_ts = now_ts
        return 0, 0

    elapsed = max(now_ts - last_net_ts, 1e-6)
    rx_bps = int(max(rx - last_net_rx, 0) / elapsed)
    tx_bps = int(max(tx - last_net_tx, 0) / elapsed)

    last_net_rx = rx
    last_net_tx = tx
    last_net_ts = now_ts
    return rx_bps, tx_bps


def parse_first_float(text: str) -> Optional[float]:
    m = re.search(r"([-+]?[0-9]+(?:\.[0-9]+)?)", text)
    if not m:
        return None
    try:
        return float(m.group(1))
    except Exception:
        return None


def parse_battery_command_output(text: str) -> Dict[str, Optional[float]]:
    text = (text or "").strip()
    if not text:
        return {
            "battery_voltage": None,
            "battery_current_a": None,
            "battery_current_ma": None
        }

    try:
        payload = json.loads(text)
        voltage = payload.get("battery_voltage")
        current_a = payload.get("battery_current_a")
        current_ma = payload.get("battery_current_ma")

        if current_ma is None and current_a is not None:
            current_ma = float(current_a) * 1000.0
        if current_a is None and current_ma is not None:
            current_a = float(current_ma) / 1000.0

        return {
            "battery_voltage": round(float(voltage), 3) if voltage is not None else None,
            "battery_current_a": round(float(current_a), 3) if current_a is not None else None,
            "battery_current_ma": round(float(current_ma), 1) if current_ma is not None else None
        }
    except Exception:
        pass

    # Backward-compatible fallback:
    # if old command returns only a single float, treat it as voltage
    value = parse_first_float(text)
    return {
        "battery_voltage": round(value * BATTERY_DIVIDER_RATIO, 3) if value is not None else None,
        "battery_current_a": None,
        "battery_current_ma": None
    }


def read_battery_metrics() -> Dict[str, Optional[float]]:
    try:
        if BATTERY_MODE == "disabled":
            return {
                "battery_voltage": None,
                "battery_current_a": None,
                "battery_current_ma": None
            }

        if BATTERY_MODE == "sysfs" and BATTERY_SYSFS_PATH:
            raw = Path(BATTERY_SYSFS_PATH).read_text(encoding="utf-8").strip()
            value = parse_first_float(raw)
            if value is None:
                return {
                    "battery_voltage": None,
                    "battery_current_a": None,
                    "battery_current_ma": None
                }

            if value > 1000:
                if value > 100000:
                    value = value / 1000000.0
                else:
                    value = value / 1000.0

            return {
                "battery_voltage": round(value * BATTERY_DIVIDER_RATIO, 3),
                "battery_current_a": None,
                "battery_current_ma": None
            }

        if BATTERY_MODE == "command" and BATTERY_COMMAND:
            out = subprocess.check_output(
                shlex.split(BATTERY_COMMAND),
                text=True,
                timeout=5
            ).strip()
            return parse_battery_command_output(out)

    except Exception:
        pass

    return {
        "battery_voltage": None,
        "battery_current_a": None,
        "battery_current_ma": None
    }


def battery_status_text(voltage: Optional[float]) -> str:
    if voltage is None:
        return "Unavailable"
    if voltage >= 12.2:
        return "Good"
    if voltage >= 11.7:
        return "Medium"
    return "Low"


def read_ram_usage() -> Dict[str, Optional[float]]:
    try:
        vm = psutil.virtual_memory()
        total_mb = round(vm.total / (1024 * 1024), 2)
        used_mb = round((vm.total - vm.available) / (1024 * 1024), 2)
        percent = round(float(vm.percent), 2)
        return {
            "ram_total_mb": total_mb,
            "ram_used_mb": used_mb,
            "ram_percent": percent
        }
    except Exception:
        return {
            "ram_total_mb": None,
            "ram_used_mb": None,
            "ram_percent": None
        }


def get_tailscale_id() -> Optional[str]:
    """
    Returns the device Tailscale IPv4 address.

    Example command:
        tailscale ip -4

    Example output:
        100.96.110.12

    This value is sent as "tailscale_id" in Data Status.
    """
    try:
        result = subprocess.run(
            ["tailscale", "ip", "-4"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
            check=False
        )

        if result.returncode != 0:
            return None

        tailscale_ip_lines = result.stdout.strip().splitlines()
        if not tailscale_ip_lines:
            return None

        tailscale_ip = tailscale_ip_lines[0].strip()
        return tailscale_ip or None

    except Exception:
        return None


def check_cloudflare_live_server() -> Dict[str, Any]:
    """Check the permanent Cloudflare /live URL for the MQTT Data Status packet."""
    checked_at = now_str()

    if not PERMANENT_LIVE_URL:
        return {
            "cloudflare_server_url": None,
            "cloudflare_server_final_url": None,
            "cloudflare_server_response_code": None,
            "cloudflare_server_status": "NOT_CONFIGURED",
            "cloudflare_server_reachable": False,
            "cloudflare_server_response_time_ms": None,
            "cloudflare_server_content_type": None,
            "cloudflare_server_header": None,
            "cloudflare_cf_ray": None,
            "cloudflare_server_checked_at": checked_at,
            "cloudflare_server_error": "Permanent live URL is not configured"
        }

    started_at = time.monotonic()
    response = None

    try:
        response = requests.get(
            PERMANENT_LIVE_URL,
            headers={
                "User-Agent": f"GCam-Device-Status/{SOFTWARE_VERSION}",
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"
            },
            allow_redirects=True,
            stream=True,
            timeout=(3, 8)
        )

        response_time_ms = round((time.monotonic() - started_at) * 1000.0, 2)
        response_code = int(response.status_code)
        server_ok = 200 <= response_code < 400

        return {
            "cloudflare_server_url": PERMANENT_LIVE_URL,
            "cloudflare_server_final_url": str(response.url),
            "cloudflare_server_response_code": response_code,
            "cloudflare_server_status": "ONLINE" if server_ok else "HTTP_ERROR",
            "cloudflare_server_reachable": True,
            "cloudflare_server_response_time_ms": response_time_ms,
            "cloudflare_server_content_type": response.headers.get("Content-Type"),
            "cloudflare_server_header": response.headers.get("Server"),
            "cloudflare_cf_ray": response.headers.get("CF-Ray"),
            "cloudflare_server_checked_at": checked_at,
            "cloudflare_server_error": None if server_ok else f"HTTP {response_code}"
        }

    except requests.RequestException as exc:
        response_time_ms = round((time.monotonic() - started_at) * 1000.0, 2)
        return {
            "cloudflare_server_url": PERMANENT_LIVE_URL,
            "cloudflare_server_final_url": None,
            "cloudflare_server_response_code": None,
            "cloudflare_server_status": "UNREACHABLE",
            "cloudflare_server_reachable": False,
            "cloudflare_server_response_time_ms": response_time_ms,
            "cloudflare_server_content_type": None,
            "cloudflare_server_header": None,
            "cloudflare_cf_ray": None,
            "cloudflare_server_checked_at": checked_at,
            "cloudflare_server_error": str(exc)
        }

    finally:
        if response is not None:
            response.close()



def _recording_timestamp_from_path(path: Path) -> Optional[dt.datetime]:
    match = re.fullmatch(r"rec_(\d{8})_(\d{6})\.mp4", path.name)
    if not match:
        return None
    try:
        return dt.datetime.strptime(match.group(1) + match.group(2), "%Y%m%d%H%M%S")
    except ValueError:
        return None


def _raw_recording_files() -> List[Path]:
    results: List[Path] = []
    try:
        if not RECORDING_DIR.exists():
            return results
        for path in RECORDING_DIR.glob("*/*.mp4"):
            if path.is_file():
                results.append(path)
    except Exception:
        return results

    def sort_key(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except OSError:
            return 0.0

    results.sort(key=sort_key)
    return results


def _latest_recording_output_info() -> Optional[Tuple[Path, int, float]]:
    files = _raw_recording_files()
    if not files:
        return None
    path = files[-1]
    try:
        stat = path.stat()
        return path, int(stat.st_size), float(stat.st_mtime)
    except OSError:
        return None


def _tail_recording_log(max_bytes: int = 4096) -> str:
    try:
        if not RECORDING_FFMPEG_LOG.exists():
            return ""
        with RECORDING_FFMPEG_LOG.open("rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - max_bytes))
            data = fh.read().decode("utf-8", errors="replace")
        lines = [line.strip() for line in data.splitlines() if line.strip()]
        return lines[-1] if lines else ""
    except Exception:
        return ""


def _recording_files(include_recent: bool = True) -> List[Tuple[dt.datetime, Path]]:
    results: List[Tuple[dt.datetime, Path]] = []
    try:
        if not RECORDING_DIR.exists():
            return results
        now_ts = time.time()
        for path in RECORDING_DIR.glob("*/*.mp4"):
            if not path.is_file():
                continue
            stamp = _recording_timestamp_from_path(path)
            if stamp is None:
                continue
            if not include_recent:
                try:
                    if (now_ts - path.stat().st_mtime) < 3.0:
                        # The newest FFmpeg segment may still be open. Do not offer
                        # an actively-written MP4 to the browser.
                        continue
                except OSError:
                    continue
            results.append((stamp, path))
    except Exception:
        return results
    results.sort(key=lambda item: item[0])
    return results


def _ffprobe_duration_sec(path: Path) -> Optional[float]:
    try:
        proc = subprocess.run(
            [
                "/usr/bin/ffprobe",
                "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(path),
            ],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=8,
        )
        if proc.returncode != 0:
            return None
        value = float(proc.stdout.strip())
        return value if value > 0 else None
    except Exception:
        return None


PLAYBACK_GAP_TOLERANCE_SEC = 5.0


def _playback_payload_for_file(
    path: Path,
    segment_start: dt.datetime,
    offset_sec: float = 0.0,
    range_end: Optional[dt.datetime] = None,
) -> Dict[str, Any]:
    rel = path.relative_to(RECORDING_DIR).as_posix()
    duration = _ffprobe_duration_sec(path)
    effective_duration = duration if duration is not None else float(RECORDING_SEGMENT_SEC)

    payload: Dict[str, Any] = {
        "relative_path": rel,
        "url": f"/playback/video/{rel}",
        "segment_start": segment_start.strftime("%Y-%m-%d %H:%M:%S"),
        "segment_duration_sec": round(duration, 3) if duration is not None else None,
        "offset_sec": round(max(offset_sec, 0.0), 3),
    }

    if range_end is not None:
        segment_end = segment_start + dt.timedelta(seconds=effective_duration)
        requested_stop_offset = (range_end - segment_start).total_seconds()
        stop_offset = max(0.0, min(effective_duration, requested_stop_offset))
        is_final_segment = range_end <= segment_end + dt.timedelta(seconds=0.25)

        payload.update({
            "range_end": range_end.strftime("%Y-%m-%d %H:%M:%S"),
            "stop_offset_sec": round(stop_offset, 3),
            "is_final_segment": bool(is_final_segment),
        })

    return payload


def find_recording_for_datetime(target: dt.datetime) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    files = _recording_files(include_recent=False)
    if not files:
        return None, "No completed recording files are available yet."

    selected: Optional[Tuple[dt.datetime, Path]] = None
    for stamp, path in files:
        if stamp <= target:
            selected = (stamp, path)
        else:
            break

    if selected is None:
        return None, "The requested time is older than the first available recording."

    segment_start, path = selected
    duration = _ffprobe_duration_sec(path)
    if duration is None:
        # Conservative fallback when ffprobe cannot read a damaged/incomplete file.
        duration = float(RECORDING_SEGMENT_SEC + 30)

    offset = (target - segment_start).total_seconds()
    if offset < 0 or offset > (duration + 2.0):
        return None, "A recording gap exists at the requested timestamp."

    payload = _playback_payload_for_file(path, segment_start, offset)
    payload["segment_duration_sec"] = round(duration, 3)
    return payload, None


def find_recording_for_range(
    range_start: dt.datetime,
    range_end: dt.datetime,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    if range_end <= range_start:
        return None, "End date/time must be later than start date/time."

    playback, error = find_recording_for_datetime(range_start)
    if playback is None:
        return None, error

    relative_path = str(playback.get("relative_path", "")).strip()
    if not relative_path:
        return None, "The requested recording segment could not be resolved."

    path = RECORDING_DIR / relative_path
    segment_start_text = str(playback.get("segment_start", ""))

    try:
        segment_start = dt.datetime.strptime(segment_start_text, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None, "The requested recording segment has an invalid timestamp."

    payload = _playback_payload_for_file(
        path,
        segment_start,
        float(playback.get("offset_sec", 0.0) or 0.0),
        range_end=range_end,
    )

    return payload, None


def find_next_recording(relative_path: str) -> Optional[Dict[str, Any]]:
    # Legacy single-time playback compatibility.
    safe_rel = str(relative_path or "").strip().replace("\\", "/")
    files = _recording_files(include_recent=False)
    for idx, (stamp, path) in enumerate(files):
        try:
            rel = path.relative_to(RECORDING_DIR).as_posix()
        except ValueError:
            continue
        if rel == safe_rel and (idx + 1) < len(files):
            next_stamp, next_path = files[idx + 1]
            current_duration = _ffprobe_duration_sec(path) or float(RECORDING_SEGMENT_SEC)
            expected_end = stamp + dt.timedelta(seconds=current_duration)
            gap_sec = (next_stamp - expected_end).total_seconds()
            if gap_sec > PLAYBACK_GAP_TOLERANCE_SEC:
                return None
            next_offset = max(0.0, -gap_sec)
            return _playback_payload_for_file(next_path, next_stamp, next_offset)
    return None



def find_next_recording_live(relative_path: str) -> Optional[Dict[str, Any]]:
    """Find the next completed segment without rescanning the full recording archive.

    Playback files are timestamp-named, so continuous/live-edge playback only needs to
    probe the few timestamps immediately after the current segment. This keeps MQTT DVR
    polling cheap even when the SD card contains tens of thousands of recordings.
    """
    safe_rel = str(relative_path or "").strip().replace("\\", "/")
    current_path = RECORDING_DIR / safe_rel

    try:
        current_path = current_path.resolve()
        recording_root = RECORDING_DIR.resolve()
        current_path.relative_to(recording_root)
    except Exception:
        return None

    if not current_path.is_file():
        return None

    current_stamp = _recording_timestamp_from_path(current_path)
    if current_stamp is None:
        return None

    current_duration = _ffprobe_duration_sec(current_path) or float(RECORDING_SEGMENT_SEC)
    expected_next = current_stamp + dt.timedelta(seconds=max(current_duration, 0.1))

    tolerance = max(PLAYBACK_GAP_TOLERANCE_SEC, 2.0)
    search_start = expected_next - dt.timedelta(seconds=tolerance)
    search_end = expected_next + dt.timedelta(seconds=tolerance)

    best: Optional[Tuple[dt.datetime, Path]] = None
    probe = search_start
    while probe <= search_end:
        candidate = (
            RECORDING_DIR
            / probe.strftime("%Y-%m-%d")
            / f"rec_{probe.strftime('%Y%m%d_%H%M%S')}.mp4"
        )
        if candidate != current_path and candidate.is_file():
            try:
                stat = candidate.stat()
                # Do not hand the browser the MP4 that FFmpeg is still writing.
                if stat.st_size > 0 and (time.time() - stat.st_mtime) >= 3.0:
                    stamp = _recording_timestamp_from_path(candidate)
                    if stamp is not None and stamp > current_stamp:
                        if best is None or stamp < best[0]:
                            best = (stamp, candidate)
            except OSError:
                pass
        probe += dt.timedelta(seconds=1)

    if best is None:
        return None

    next_stamp, next_path = best
    current_end = current_stamp + dt.timedelta(seconds=current_duration)
    gap_sec = (next_stamp - current_end).total_seconds()
    next_offset = max(0.0, -gap_sec)
    return _playback_payload_for_file(next_path, next_stamp, next_offset)


def find_previous_recording_live(relative_path: str) -> Optional[Dict[str, Any]]:
    """Return the immediately previous completed segment for MQTT DVR reverse playback."""
    safe_rel = str(relative_path or "").strip().replace("\\", "/")
    current_path = RECORDING_DIR / safe_rel

    try:
        current_path = current_path.resolve()
        recording_root = RECORDING_DIR.resolve()
        current_path.relative_to(recording_root)
    except Exception:
        return None

    if not current_path.is_file():
        return None

    files = _recording_files(include_recent=False)
    for idx, (stamp, path) in enumerate(files):
        try:
            rel = path.relative_to(RECORDING_DIR).as_posix()
        except ValueError:
            continue

        if rel != safe_rel:
            continue
        if idx <= 0:
            return None

        previous_stamp, previous_path = files[idx - 1]
        previous_duration = _ffprobe_duration_sec(previous_path) or float(RECORDING_SEGMENT_SEC)
        previous_end = previous_stamp + dt.timedelta(seconds=max(previous_duration, 0.1))
        gap_sec = (stamp - previous_end).total_seconds()
        if gap_sec > PLAYBACK_GAP_TOLERANCE_SEC:
            return None

        payload = _playback_payload_for_file(previous_path, previous_stamp, 0.0)
        payload["reverse_start_offset_sec"] = round(max(previous_duration - 0.08, 0.0), 3)
        return payload

    return None

def find_next_recording_for_range(
    relative_path: str,
    range_end: dt.datetime,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    safe_rel = str(relative_path or "").strip().replace("\\", "/")
    files = _recording_files(include_recent=False)

    for idx, (stamp, path) in enumerate(files):
        try:
            rel = path.relative_to(RECORDING_DIR).as_posix()
        except ValueError:
            continue

        if rel != safe_rel:
            continue

        current_duration = _ffprobe_duration_sec(path) or float(RECORDING_SEGMENT_SEC)
        current_end = stamp + dt.timedelta(seconds=current_duration)

        if range_end <= current_end + dt.timedelta(seconds=0.25):
            return None, "Requested playback range is already complete."

        if (idx + 1) >= len(files):
            return None, "No completed recording segment is available for the remaining requested range."

        next_stamp, next_path = files[idx + 1]
        gap_sec = (next_stamp - current_end).total_seconds()

        if gap_sec > PLAYBACK_GAP_TOLERANCE_SEC:
            return None, (
                "A recording gap exists before the requested end time "
                f"({round(gap_sec, 1)} seconds)."
            )

        # If segments overlap slightly, skip the already-played overlap in the next file.
        next_offset = max(0.0, -gap_sec)

        # If the requested end falls inside a positive gap, the requested range cannot
        # be reproduced continuously even when the gap is within the small tolerance.
        if gap_sec > 0 and range_end <= next_stamp:
            return None, "A recording gap exists before the requested end time."

        payload = _playback_payload_for_file(
            next_path,
            next_stamp,
            next_offset,
            range_end=range_end,
        )
        return payload, None

    return None, "The current recording segment could not be found."


def recording_available_dates() -> List[str]:
    dates = {stamp.strftime("%Y-%m-%d") for stamp, _ in _recording_files(include_recent=True)}
    return sorted(dates, reverse=True)


def latest_completed_recording_end() -> Optional[dt.datetime]:
    """Return the end timestamp of the newest completed playback segment."""
    files = _recording_files(include_recent=False)
    if not files:
        return None

    segment_start, path = files[-1]
    duration = _ffprobe_duration_sec(path) or float(RECORDING_SEGMENT_SEC)
    return segment_start + dt.timedelta(seconds=max(duration, 0.1))


def parse_mqtt_playback_start(payload: Dict[str, Any]) -> Tuple[Optional[dt.datetime], Optional[str]]:
    """
    Parse MQTT playback start time. Supported examples:
      start_date=2026-08-06, start_time=16:31:00
      start_date=06-08-2026, start_time=04:31:00 PM
      start_datetime=2026-08-06 16:31:00
    """
    combined = str(
        payload.get("start_datetime")
        or payload.get("datetime")
        or payload.get("start")
        or ""
    ).strip()

    candidates: List[str] = []
    if combined:
        candidates.append(combined)
    else:
        date_text = str(payload.get("start_date") or payload.get("date") or "").strip()
        time_text = str(payload.get("start_time") or payload.get("time") or "").strip()
        if not date_text or not time_text:
            return None, (
                "start_date and start_time are required. "
                "Example: 06-08-2026 and 04:31:00 PM"
            )
        candidates.append(f"{date_text} {time_text}")

    formats = (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d-%m-%Y %H:%M:%S",
        "%d-%m-%Y %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%Y-%m-%d %I:%M:%S %p",
        "%Y-%m-%d %I:%M %p",
        "%d-%m-%Y %I:%M:%S %p",
        "%d-%m-%Y %I:%M %p",
        "%d/%m/%Y %I:%M:%S %p",
        "%d/%m/%Y %I:%M %p",
    )

    for candidate in candidates:
        normalized = re.sub(r"\s+", " ", candidate.strip()).upper()
        for fmt in formats:
            try:
                return dt.datetime.strptime(normalized, fmt), None
            except ValueError:
                continue

    return None, (
        "Invalid playback start date/time. Supported date formats: YYYY-MM-DD or DD-MM-YYYY; "
        "time formats: HH:MM[:SS] or hh:mm[:ss] AM/PM."
    )


def build_start_to_live_playback_url(start_at: dt.datetime) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Build a video-only URL that starts at start_at and keeps following newly completed clips."""
    first_playback, error = find_recording_for_datetime(start_at)
    if first_playback is None:
        return None, error

    latest_end = latest_completed_recording_end()
    if latest_end is None:
        return None, "No completed recording files are available yet."
    if latest_end <= start_at:
        return None, "The requested start time is newer than the latest completed recording."

    base_url = PERMANENT_PLAYBACK_LIVE_URL or f"{local_dashboard_url()}/playback/live"
    playback_url = (
        f"{base_url}?start_date={start_at.strftime('%Y-%m-%d')}"
        f"&start_time={start_at.strftime('%H:%M:%S')}"
        "&follow_live=1"
    )

    return {
        "playback_url": playback_url,
        "start_datetime": start_at.strftime("%Y-%m-%d %H:%M:%S"),
        "latest_completed_end": latest_end.strftime("%Y-%m-%d %H:%M:%S"),
        "first_segment": first_playback.get("relative_path"),
        "mode": "start_to_live_edge",
    }, None


def is_recording_process_active() -> bool:
    with recording_process_lock:
        return recording_process is not None and recording_process.poll() is None


def collect_storage_status() -> Dict[str, Any]:
    RECORDING_DIR.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(str(RECORDING_DIR))

    # Count every MP4 byte for storage accounting, even if a damaged filename cannot
    # be parsed for playback. Playback itself still uses timestamp-valid filenames.
    raw_files = _raw_recording_files()
    recording_bytes = 0
    for path in raw_files:
        try:
            recording_bytes += path.stat().st_size
        except OSError:
            pass

    files = _recording_files(include_recent=True)
    valid_files: List[Tuple[dt.datetime, Path, int]] = []
    for stamp, path in files:
        try:
            size = path.stat().st_size
        except OSError:
            continue
        valid_files.append((stamp, path, size))

    oldest = valid_files[0][0] if valid_files else None
    newest = valid_files[-1][0] if valid_files else None

    # Capacity dedicated to playback = already-recorded bytes + current free bytes
    # minus the protected reserve. There is no fixed day limit.
    recording_capacity_bytes = max(
        0,
        usage.free + recording_bytes - RECORDING_RESERVE_BYTES,
    )
    available_recording_bytes = max(0, usage.free - RECORDING_RESERVE_BYTES)

    # Estimate actual camera recording rate from completed segments.
    completed_samples: List[int] = []
    now_ts = time.time()
    for _stamp, path, size in valid_files:
        try:
            if (now_ts - path.stat().st_mtime) < 15.0:
                continue
        except OSError:
            continue
        if size > 0:
            completed_samples.append(size)

    completed_samples = completed_samples[-60:]
    bytes_per_hour: Optional[float] = None
    if completed_samples:
        sample_seconds = float(len(completed_samples) * RECORDING_SEGMENT_SEC)
        if sample_seconds > 0:
            bytes_per_hour = (sum(completed_samples) / sample_seconds) * 3600.0

    estimated_capacity_hours: Optional[float] = None
    estimated_remaining_hours: Optional[float] = None
    if bytes_per_hour is not None and bytes_per_hour > 0:
        estimated_capacity_hours = recording_capacity_bytes / bytes_per_hour
        estimated_remaining_hours = available_recording_bytes / bytes_per_hour

    current_playback_span_hours: Optional[float] = None
    if oldest is not None and newest is not None:
        current_playback_span_hours = max(
            0.0,
            ((newest - oldest).total_seconds() + RECORDING_SEGMENT_SEC) / 3600.0,
        )

    process_active = is_recording_process_active()
    latest_info = _latest_recording_output_info()
    active_segment_mb = 0.0
    latest_output_age_sec: Optional[float] = None
    active_segment_name: Optional[str] = None

    if latest_info is not None:
        latest_path, latest_size, latest_mtime = latest_info
        active_segment_mb = latest_size / (1024 ** 2)
        latest_output_age_sec = max(0.0, now_ts - latest_mtime)
        active_segment_name = latest_path.name

    if not RECORDING_ENABLED:
        recorder_status = "DISABLED"
    elif not process_active:
        recorder_status = "IDLE"
    elif latest_info is not None and active_segment_mb > 0 and latest_output_age_sec is not None and latest_output_age_sec <= RECORDING_STALL_TIMEOUT_SEC:
        recorder_status = "RECORDING"
    else:
        recorder_status = "CONNECTING"

    recorder_last_error = None
    try:
        state_snapshot = load_state()
        recorder_last_error = state_snapshot.get("system", {}).get("recording_last_error")
    except Exception:
        recorder_last_error = None

    return {
        "time": now_str(),
        "storage_path": str(RECORDING_DIR),
        "sd_total_gb": round(usage.total / (1024 ** 3), 2),
        "sd_used_gb": round(usage.used / (1024 ** 3), 2),
        "sd_free_gb": round(usage.free / (1024 ** 3), 2),
        "sd_used_percent": round((usage.used / usage.total) * 100.0, 2) if usage.total else 0.0,
        "recordings_used_gb": round(recording_bytes / (1024 ** 3), 3),
        "recordings_used_mb": round(recording_bytes / (1024 ** 2), 1),
        "recording_capacity_gb": round(recording_capacity_bytes / (1024 ** 3), 3),
        "available_recording_gb": round(available_recording_bytes / (1024 ** 3), 3),
        "estimated_hourly_recording_gb": round(bytes_per_hour / (1024 ** 3), 3) if bytes_per_hour is not None else None,
        "estimated_capacity_hours": round(estimated_capacity_hours, 1) if estimated_capacity_hours is not None else None,
        "estimated_remaining_hours": round(estimated_remaining_hours, 1) if estimated_remaining_hours is not None else None,
        "current_playback_span_hours": round(current_playback_span_hours, 2) if current_playback_span_hours is not None else None,
        "recording_file_count": len(raw_files),
        "playable_file_count": len(valid_files),
        "recording_active": process_active,
        "recorder_status": recorder_status,
        "recorder_last_error": recorder_last_error,
        "active_segment_mb": round(active_segment_mb, 2),
        "active_segment_name": active_segment_name,
        "latest_output_age_sec": round(latest_output_age_sec, 1) if latest_output_age_sec is not None else None,
        "recording_enabled": RECORDING_ENABLED,
        "storage_mode": "capacity_based_ring_buffer",
        "segment_sec": RECORDING_SEGMENT_SEC,
        "reserve_gb": round(RECORDING_RESERVE_BYTES / (1024 ** 3), 2),
        "storage_available_for_recording": usage.free > RECORDING_RESERVE_BYTES,
        "oldest_recording": oldest.strftime("%Y-%m-%d %H:%M:%S") if oldest else None,
        "newest_recording": newest.strftime("%Y-%m-%d %H:%M:%S") if newest else None,
        "available_dates": sorted({stamp.strftime("%Y-%m-%d") for stamp, _, _ in valid_files}, reverse=True),
        "recording_source": "shared_local_mjpeg",
        "recording_source_url": RECORDING_SOURCE_URL,
        "recording_output_fps": RECORDING_OUTPUT_FPS,
        "recording_output_width": RECORDING_OUTPUT_WIDTH,
        "ffmpeg_log": str(RECORDING_FFMPEG_LOG),
        "playback_url": PERMANENT_PLAYBACK_URL or f"{local_dashboard_url()}/playback",
    }


def _prune_empty_recording_dirs() -> None:
    try:
        if not RECORDING_DIR.exists():
            return
        for child in RECORDING_DIR.iterdir():
            if child.is_dir():
                try:
                    next(child.iterdir())
                except StopIteration:
                    child.rmdir()
                except Exception:
                    pass
    except Exception:
        pass


def enforce_recording_retention() -> Dict[str, Any]:
    RECORDING_DIR.mkdir(parents=True, exist_ok=True)
    deleted_files = 0
    deleted_bytes = 0

    # Storage-based ring buffer: there is no day-based deletion. Once free space
    # reaches the protected reserve, delete the oldest completed MP4 segments until
    # the reserve plus a small headroom is restored, then continuous recording can
    # keep using the released space.
    usage = shutil.disk_usage(str(RECORDING_DIR))
    free_estimate = usage.free
    target_free = RECORDING_RESERVE_BYTES + RECORDING_CLEANUP_HEADROOM_BYTES

    if free_estimate <= RECORDING_RESERVE_BYTES:
        for _stamp, path in _recording_files(include_recent=True):
            if free_estimate >= target_free:
                break
            try:
                stat = path.stat()
                # Never delete the MP4 that FFmpeg is currently writing.
                if (time.time() - stat.st_mtime) < 15.0:
                    continue
                size = stat.st_size
                path.unlink(missing_ok=True)
                free_estimate += size
                deleted_files += 1
                deleted_bytes += size
            except Exception:
                continue

    _prune_empty_recording_dirs()
    return {
        "deleted_files": deleted_files,
        "deleted_gb": round(deleted_bytes / (1024 ** 3), 3),
        "free_after_cleanup_gb": round(free_estimate / (1024 ** 3), 3),
    }


def stop_recording_process() -> None:
    global recording_process, recording_process_date, recording_process_started_at
    with recording_process_lock:
        proc = recording_process
        recording_process = None
        recording_process_date = None
        recording_process_started_at = None

    if proc is None:
        return

    try:
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=8)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def start_recording_process() -> Tuple[bool, Optional[str]]:
    global recording_process, recording_process_date, recording_process_started_at

    if not RECORDING_ENABLED:
        return False, "recording disabled in config"

    if not Path("/usr/bin/ffmpeg").exists():
        return False, "/usr/bin/ffmpeg not found"

    date_key = now_dt().strftime("%Y-%m-%d")
    day_dir = RECORDING_DIR / date_key
    day_dir.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    output_pattern = str(day_dir / "rec_%Y%m%d_%H%M%S.mp4")

    # Keep a real FFmpeg log. Previously stderr went to /dev/null, which meant an
    # RTSP/authentication/codec problem could look like an "ACTIVE" recorder.
    try:
        if RECORDING_FFMPEG_LOG.exists() and RECORDING_FFMPEG_LOG.stat().st_size > (4 * 1024 * 1024):
            with RECORDING_FFMPEG_LOG.open("rb") as src:
                src.seek(max(0, RECORDING_FFMPEG_LOG.stat().st_size - (512 * 1024)))
                tail = src.read()
            RECORDING_FFMPEG_LOG.write_bytes(tail)
    except Exception:
        pass

    # Record from the app's local shared MJPEG feed instead of opening a second
    # camera RTSP connection. The reader_loop() owns the single SUB RTSP connection;
    # this FFmpeg process only consumes frames already available inside G-Cam.
    # Encode to browser-compatible H.264 MP4 so every completed segment is playable.
    gop_size = max(10, RECORDING_OUTPUT_FPS * 2)
    cmd = [
        "/usr/bin/ffmpeg",
        "-nostdin",
        "-hide_banner",
        "-loglevel", "warning",
        "-rw_timeout", "15000000",
        "-fflags", "+genpts+discardcorrupt+nobuffer",
        "-use_wallclock_as_timestamps", "1",
        "-f", "mpjpeg",
        "-i", RECORDING_SOURCE_URL,
        "-map", "0:v:0",
        "-an",
        "-vf", f"fps={RECORDING_OUTPUT_FPS},scale={RECORDING_OUTPUT_WIDTH}:-2:flags=fast_bilinear",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-tune", "zerolatency",
        "-crf", "28",
        "-pix_fmt", "yuv420p",
        "-g", str(gop_size),
        "-keyint_min", str(gop_size),
        "-sc_threshold", "0",
        "-avoid_negative_ts", "make_zero",
        "-f", "segment",
        "-segment_format", "mp4",
        "-segment_time", str(RECORDING_SEGMENT_SEC),
        "-segment_atclocktime", "1",
        "-reset_timestamps", "1",
        "-strftime", "1",
        "-y",
        output_pattern,
    ]

    log_fh = None
    try:
        log_fh = RECORDING_FFMPEG_LOG.open("ab", buffering=0)
        banner = (
            f"\n[{now_str()}] Starting playback recorder\n"
            f"source=shared_local_mjpeg\n"
            f"source_url={RECORDING_SOURCE_URL}\n"
            f"camera_rtsp={RECORDING_RTSP_URL}\n"
            f"output={RECORDING_OUTPUT_WIDTH}px/{RECORDING_OUTPUT_FPS}fps H.264\n"
            f"segment_sec={RECORDING_SEGMENT_SEC}\n"
        ).encode("utf-8", errors="replace")
        log_fh.write(banner)

        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=log_fh,
            start_new_session=True,
        )
    except Exception as exc:
        if log_fh is not None:
            try:
                log_fh.close()
            except Exception:
                pass
        return False, str(exc)
    finally:
        if log_fh is not None:
            try:
                log_fh.close()
            except Exception:
                pass

    # Catch immediate FFmpeg option/RTSP failures instead of falsely reporting ACTIVE.
    time.sleep(1.0)
    if proc.poll() is not None:
        detail = _tail_recording_log()
        error = f"FFmpeg exited immediately with code {proc.returncode}"
        if detail:
            error += f": {detail}"
        return False, error

    started_at = time.time()
    with recording_process_lock:
        recording_process = proc
        recording_process_date = date_key
        recording_process_started_at = started_at

    return True, None


def recording_manager_loop() -> None:
    last_cleanup_ts = 0.0
    last_state_ts = 0.0

    RECORDING_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    while not stop_event.is_set():
        try:
            now_ts = time.time()

            if (now_ts - last_cleanup_ts) >= 60.0:
                enforce_recording_retention()
                last_cleanup_ts = now_ts

            if not RECORDING_ENABLED:
                stop_recording_process()
                time.sleep(5)
                continue

            if is_power_saving_active():
                stop_recording_process()
                update_state(lambda s: s["system"].update({
                    "recording_active": False,
                    "recording_status": "IDLE",
                    "recording_last_error": "Power saving mode active"
                }))
                time.sleep(2)
                continue

            usage = shutil.disk_usage(str(RECORDING_DIR))
            if usage.free <= RECORDING_RESERVE_BYTES:
                enforce_recording_retention()
                usage = shutil.disk_usage(str(RECORDING_DIR))
                if usage.free <= RECORDING_RESERVE_BYTES:
                    stop_recording_process()
                    update_state(lambda s: s["system"].update({
                        "recording_active": False,
                        "recording_status": "IDLE",
                        "recording_last_error": "Protected SD free-space reserve reached"
                    }))
                    time.sleep(10)
                    continue

            current_date = now_dt().strftime("%Y-%m-%d")
            with recording_process_lock:
                proc = recording_process
                proc_date = recording_process_date
                proc_started_at = recording_process_started_at
                active = proc is not None and proc.poll() is None

            if active and proc_date != current_date:
                stop_recording_process()
                active = False

            if not active:
                ok, error = start_recording_process()
                update_state(lambda s: s["system"].update({
                    "recording_active": bool(ok),
                    "recording_status": "CONNECTING" if ok else "IDLE",
                    "recording_last_error": error,
                    "recording_last_started_at": now_str() if ok else s["system"].get("recording_last_started_at")
                }))
                if not ok:
                    time.sleep(5)
                    continue

                with recording_process_lock:
                    proc_started_at = recording_process_started_at
                active = True

            # A living FFmpeg PID is not enough. Require actual MP4 bytes to appear
            # and continue changing. Restart automatically when RTSP is stuck.
            latest_info = _latest_recording_output_info()
            output_is_fresh = False
            output_matches_current_run = False
            if latest_info is not None:
                _latest_path, latest_size, latest_mtime = latest_info
                output_is_fresh = latest_size > 0 and (now_ts - latest_mtime) <= RECORDING_STALL_TIMEOUT_SEC
                if proc_started_at is not None:
                    output_matches_current_run = latest_mtime >= (proc_started_at - 2.0)

            run_age = (now_ts - proc_started_at) if proc_started_at is not None else 0.0
            if active and run_age >= RECORDING_START_GRACE_SEC and not (output_is_fresh and output_matches_current_run):
                detail = _tail_recording_log()
                if not detail:
                    detail = (
                        "FFmpeg is alive but no MP4 data is being written from the shared live feed. "
                        "Check Camera Status / Last Frame on the dashboard."
                    )

                stop_recording_process()
                update_state(lambda s: s["system"].update({
                    "recording_active": False,
                    "recording_status": "STALLED",
                    "recording_last_error": detail,
                }))
                time.sleep(3)
                continue

            recorder_status = "RECORDING" if (output_is_fresh and output_matches_current_run) else "CONNECTING"

            if (now_ts - last_state_ts) >= 10.0:
                update_state(lambda s: s["system"].update({
                    "recording_enabled": RECORDING_ENABLED,
                    "recording_active": is_recording_process_active(),
                    "recording_status": recorder_status,
                    "recording_storage_mode": "capacity_based_ring_buffer",
                    "recording_reserve_gb": RECORDING_RESERVE_GB,
                    "recording_segment_sec": RECORDING_SEGMENT_SEC,
                    "recording_playback_url": PERMANENT_PLAYBACK_URL,
                    "recording_last_error": None if recorder_status == "RECORDING" else s["system"].get("recording_last_error")
                }))
                last_state_ts = now_ts

        except Exception as exc:
            update_state(lambda s: s["system"].update({
                "recording_active": False,
                "recording_status": "STALLED",
                "recording_last_error": f"Recorder manager error: {exc}"
            }))

        time.sleep(2)


def collect_device_status(include_cloudflare_server_check: bool = False) -> Dict[str, Any]:
    iface = detect_primary_iface()
    network_status = read_iface_operstate(iface)
    link_speed = read_iface_link_speed(iface)
    rx_bps, tx_bps = calc_network_rates(iface)
    temp_c = get_pi_temperature_c()
    location = detect_geo_location()
    ram = read_ram_usage()
    battery = read_battery_metrics()
    battery_voltage = battery.get("battery_voltage")
    tailscale_id = get_tailscale_id()

    status = {
        "device_id": DEVICE_ID,
        "camera_name": CAMERA_NAME,
        "software_version": SOFTWARE_VERSION,
        "software_features": SOFTWARE_FEATURES,
        **power_saving_status_payload(),
        **feature_flags_payload(),
        **garbage_detection_mode_payload(),
        "router_ip": ROUTER_IP,
        "configured_pi_ip": PI_IP,
        "detected_pi_ip": detect_local_ip(),
        "public_ip": detect_public_ip(),
        "approx_public_location": location,
        "pi_temperature_c": temp_c,
        "network_status": network_status,
        "network_iface": iface,
        "network_link_speed_mbps": link_speed,
        "network_rx_bps": rx_bps,
        "network_tx_bps": tx_bps,
        "ram_total_mb": ram["ram_total_mb"],
        "ram_used_mb": ram["ram_used_mb"],
        "ram_percent": ram["ram_percent"],
        "battery_voltage": battery_voltage,
        "battery_current_a": battery.get("battery_current_a"),
        "battery_current_ma": battery.get("battery_current_ma"),
        "battery_status": battery_status_text(battery_voltage),
        "camera_ip": CAMERA_IP,
        "camera_config_url": PERMANENT_CAMERA_CONFIG_URL,
        "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
        "rtsp_url": RTSP_URL,
        "cloudflare_live_rtsp_url": CLOUDFLARE_LIVE_RTSP_URL,
        "tailscale_id": tailscale_id,
        "tailscale_mail_id": TAILSCALE_MAIL_ID,
        "links": {
            "dashboard_local": local_dashboard_url(),
            "stream_local": local_stream_url(),
            "cloudflare_live": PERMANENT_LIVE_URL
        }
    }

    if include_cloudflare_server_check:
        status.update(check_cloudflare_live_server())

    return status

def refresh_device_metrics_in_state() -> None:
    status = collect_device_status()

    def mutate(state):
        state["public_ip"] = status["public_ip"]
        state["raspberry_ip"] = status["detected_pi_ip"]
        state["links"]["dashboard_local"] = status["links"]["dashboard_local"]
        state["links"]["stream_local"] = status["links"]["stream_local"]
        state["camera_config_url"] = status["camera_config_url"]
        state["camera_config_target_url"] = CAMERA_CONFIG_TARGET_URL
        state["system"].update({
            "pi_temperature_c": status["pi_temperature_c"],
            "network_status": status["network_status"],
            "network_iface": status["network_iface"],
            "network_link_speed_mbps": status["network_link_speed_mbps"],
            "network_rx_bps": status["network_rx_bps"],
            "network_tx_bps": status["network_tx_bps"],
            "battery_voltage": status["battery_voltage"],
            "battery_current_a": status["battery_current_a"],
            "battery_current_ma": status["battery_current_ma"],
            "battery_status": status["battery_status"],
            "ram_total_mb": status["ram_total_mb"],
            "ram_used_mb": status["ram_used_mb"],
            "ram_percent": status["ram_percent"],
            "geo_location": status["approx_public_location"]
        })
        state["system"].pop("battery_voltage", None)
        state["system"].pop("battery_status", None)

    update_state(mutate)


def has_default_route_for_iface(iface: Optional[str]) -> bool:
    if not iface:
        return False

    try:
        proc = subprocess.run(
            ["ip", "route", "show", "default"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2
        )

        output = proc.stdout.strip()
        if not output:
            return False

        return f" dev {iface} " in f" {output} " or f" dev {iface}\n" in f" {output}\n"

    except Exception:
        return False


def tcp_reachable_for_audio(host: str, port: int) -> Tuple[bool, str]:
    try:
        with socket.create_connection(
            (host, int(port)),
            timeout=NETWORK_AUDIO_TCP_TIMEOUT_SEC
        ):
            return True, f"tcp_reachable_{host}:{port}"
    except Exception as exc:
        return False, f"tcp_unreachable_{host}:{port}: {exc}"


def internet_reachable_for_audio() -> Tuple[bool, str]:
    targets: List[Tuple[str, int]] = []

    try:
        targets.append((str(MQTT_HOST), int(MQTT_PORT)))
    except Exception:
        pass

    targets.extend(NETWORK_AUDIO_INTERNET_TEST_TARGETS)

    seen = set()
    errors: List[str] = []

    for host, port in targets:
        key = (host, int(port))
        if key in seen:
            continue

        seen.add(key)

        ok, reason = tcp_reachable_for_audio(host, int(port))
        if ok:
            return True, reason

        errors.append(reason)

    return False, "all_internet_targets_unreachable: " + " | ".join(errors[:4])


def is_network_reachable_for_audio() -> Tuple[bool, str, Optional[str]]:
    """
    Audio mute/unmute must follow real internet availability.

    Correct behavior:
      - Interface down = offline.
      - Interface up but no default route = offline.
      - Interface up + router/default route but WAN internet down = offline.
      - Interface up + real TCP internet target reachable = online.
    """
    iface = detect_primary_iface()
    operstate = read_iface_operstate(iface)

    if operstate != "up":
        return False, f"interface_{operstate}", iface

    if not has_default_route_for_iface(iface):
        return False, f"interface_up_no_default_route_{iface}", iface

    internet_ok, internet_reason = internet_reachable_for_audio()

    if internet_ok:
        return True, f"interface_up_default_route_real_internet_ok_{internet_reason}", iface

    return False, f"interface_up_default_route_but_real_internet_offline_{internet_reason}", iface


def is_network_audio_muted() -> bool:
    try:
        state = load_state()
        return bool(state.get("system", {}).get("network_audio_muted", False))
    except Exception:
        return False


def update_network_audio_state(
    muted: bool,
    reason: str,
    iface: Optional[str],
    saved_volume: Optional[int]
) -> None:
    update_state(lambda s: s["system"].update({
        "network_audio_muted": muted,
        "network_audio_mute_reason": reason,
        "network_audio_last_changed_at": now_str(),
        "network_audio_last_check_at": now_str(),
        "network_audio_iface": iface,
        "network_audio_saved_volume": saved_volume
    }), force_flush=True)


def mute_audio_for_network_offline(reason: str, iface: Optional[str]) -> None:
    global network_audio_restore_volume

    saved_volume: Optional[int] = network_audio_restore_volume

    if saved_volume is None:
        try:
            state = load_state()
            old_saved_volume = state.get("system", {}).get("network_audio_saved_volume")
            if old_saved_volume is not None:
                old_saved_volume = int(old_saved_volume)
                if old_saved_volume > 0:
                    saved_volume = old_saved_volume
        except Exception:
            saved_volume = None

    if saved_volume is None:
        try:
            current_volume = get_current_pi_volume()
            current_percent = int(current_volume.get("volume_percent", 0))

            # Do not save 0 as restore volume.
            # If current volume is already 0, restore later to default 70%.
            if current_percent > 0:
                saved_volume = current_percent
            else:
                saved_volume = NETWORK_AUDIO_DEFAULT_RESTORE_VOLUME_PERCENT

            network_audio_restore_volume = saved_volume
        except Exception:
            saved_volume = NETWORK_AUDIO_DEFAULT_RESTORE_VOLUME_PERCENT
            network_audio_restore_volume = saved_volume

    try:
        set_pi_volume(0)
    except Exception as exc:
        update_state(lambda s: s["system"].update({
            "last_error": f"Network auto mute volume failed: {exc}"
        }))

    try:
        stop_current_audio_process()
    except Exception:
        pass

    cleared_count = clear_audio_queue()

    update_network_audio_state(
        muted=True,
        reason=reason,
        iface=iface,
        saved_volume=saved_volume
    )

    update_state(lambda s: s.update({
        "last_audio": {
            "file": None,
            "source_path": None,
            "time": now_str(),
            "status": f"auto_muted_network_offline_queue_cleared_{cleared_count}"
        }
    }), force_flush=True)

    add_event("network_audio_auto_muted", {
        "reason": reason,
        "iface": iface,
        "saved_volume": saved_volume,
        "cleared_count": cleared_count
    })


def unmute_audio_for_network_online(reason: str, iface: Optional[str]) -> None:
    global network_audio_restore_volume

    restore_volume = network_audio_restore_volume

    if restore_volume is None:
        try:
            state = load_state()
            saved_volume = state.get("system", {}).get("network_audio_saved_volume")
            if saved_volume is not None:
                restore_volume = int(saved_volume)
        except Exception:
            restore_volume = None

    # Never restore to 0 when network is online.
    if restore_volume is None or int(restore_volume) <= 0:
        restore_volume = NETWORK_AUDIO_DEFAULT_RESTORE_VOLUME_PERCENT

    restore_volume = max(1, min(100, int(restore_volume)))
    restore_status = "not_restored"

    try:
        result = set_pi_volume(restore_volume)
        restore_status = f"restored_{result['volume_percent']}%"
    except Exception as exc:
        restore_status = f"restore_failed: {exc}"
        update_state(lambda s: s["system"].update({
            "last_error": f"Network auto unmute volume restore failed: {exc}"
        }))

    network_audio_restore_volume = None

    update_network_audio_state(
        muted=False,
        reason=reason,
        iface=iface,
        saved_volume=None
    )

    update_state(lambda s: s.update({
        "last_audio": {
            "file": None,
            "source_path": None,
            "time": now_str(),
            "status": f"auto_unmuted_network_online_{restore_status}"
        }
    }), force_flush=True)

    add_event("network_audio_auto_unmuted", {
        "reason": reason,
        "iface": iface,
        "restore_status": restore_status
    })

    try:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "network_audio_auto_unmuted",
            "message": "Network is online. Audio volume restored.",
            "restore_status": restore_status,
            "time": now_str()
        })
    except Exception:
        pass


def network_audio_monitor_loop() -> None:
    global network_audio_last_online

    while not stop_event.is_set():
        try:
            online, reason, iface = is_network_reachable_for_audio()

            update_state(lambda s: s["system"].update({
                "network_audio_last_check_at": now_str(),
                "network_audio_iface": iface
            }))

            if network_audio_last_online is None:
                network_audio_last_online = online

                if online:
                    should_restore = False

                    try:
                        state = load_state()
                        system_state = state.get("system", {})
                        should_restore = (
                            bool(system_state.get("network_audio_muted", False))
                            or system_state.get("network_audio_saved_volume") is not None
                        )
                    except Exception:
                        should_restore = False

                    try:
                        current_volume = get_current_pi_volume()
                        current_percent = int(current_volume.get("volume_percent", 0))

                        # First boot self-heal:
                        # If app starts while network is already online but ALSA stayed at 0%,
                        # restore once instead of leaving audio muted forever.
                        if current_percent <= 0:
                            should_restore = True
                    except Exception:
                        pass

                    if should_restore:
                        unmute_audio_for_network_online(reason, iface)
                    else:
                        update_network_audio_state(
                            muted=False,
                            reason=reason,
                            iface=iface,
                            saved_volume=None
                        )
                else:
                    mute_audio_for_network_offline(reason, iface)

            elif online != network_audio_last_online:
                network_audio_last_online = online

                if online:
                    unmute_audio_for_network_online(reason, iface)
                else:
                    mute_audio_for_network_offline(reason, iface)

            elif online:
                try:
                    state = load_state()
                    system_state = state.get("system", {})

                    # Self-heal state mismatch:
                    # If state still says muted while network is online, force unmute.
                    if (
                        bool(system_state.get("network_audio_muted", False))
                        or system_state.get("network_audio_saved_volume") is not None
                    ):
                        unmute_audio_for_network_online(reason, iface)
                except Exception:
                    pass

            elif not online and is_network_audio_muted():
                # Keep device silent only while network is truly offline.
                try:
                    set_pi_volume(0)
                except Exception:
                    pass

                try:
                    stop_current_audio_process()
                except Exception:
                    pass

        except Exception as exc:
            update_state(lambda s: s["system"].update({
                "last_error": f"Network audio monitor error: {exc}"
            }))

        for _ in range(NETWORK_AUDIO_CHECK_INTERVAL_SEC):
            if stop_event.is_set():
                return
            time.sleep(1)

def live_talk_token_valid(req) -> bool:
    expected_token = str(MQTT_COMMAND_TOKEN or "").strip()

    if not expected_token:
        return True

    token = ""

    try:
        token = str(req.headers.get("X-GCam-Token") or "").strip()
    except Exception:
        token = ""

    if not token:
        try:
            token = str(req.args.get("token") or "").strip()
        except Exception:
            token = ""

    if not token:
        try:
            token = str(req.form.get("token") or "").strip()
        except Exception:
            token = ""

    if not token:
        try:
            data = req.get_json(force=False, silent=True) or {}
            token = str(data.get("token") or "").strip()
        except Exception:
            token = ""

    return token == expected_token


def is_live_talk_active() -> bool:
    with live_talk_lock:
        return bool(live_talk_active)


def set_live_talk_active(active: bool) -> None:
    global live_talk_active

    with live_talk_lock:
        live_talk_active = bool(active)


def is_live_talk_stopping() -> bool:
    with live_talk_lock:
        return bool(live_talk_stopping)


def set_live_talk_stopping(stopping: bool) -> None:
    global live_talk_stopping

    with live_talk_lock:
        live_talk_stopping = bool(stopping)


def clear_live_talk_queue() -> int:
    cleared = 0

    while True:
        try:
            live_talk_queue.get_nowait()
        except queue.Empty:
            break

        try:
            live_talk_queue.task_done()
        except Exception:
            pass

        cleared += 1

    update_state(lambda s: s["system"].update({
        "live_talk_queue_size": live_talk_queue.qsize()
    }))

    return cleared


def is_live_talk_pipeline_running() -> bool:
    with live_talk_lock:
        ffmpeg_running = (
            live_talk_ffmpeg_process is not None
            and live_talk_ffmpeg_process.poll() is None
        )
        aplay_running = (
            live_talk_aplay_process is not None
            and live_talk_aplay_process.poll() is None
        )

    return ffmpeg_running and aplay_running


def stop_live_talk_processes(graceful: bool = False) -> None:
    global live_talk_ffmpeg_process, live_talk_aplay_process

    with live_talk_lock:
        ffmpeg_proc = live_talk_ffmpeg_process
        aplay_proc = live_talk_aplay_process
        live_talk_ffmpeg_process = None
        live_talk_aplay_process = None

    if ffmpeg_proc is not None:
        try:
            if ffmpeg_proc.stdin:
                try:
                    ffmpeg_proc.stdin.close()
                except Exception:
                    pass
        except Exception:
            pass

    for proc in [ffmpeg_proc, aplay_proc]:
        if proc is None:
            continue

        try:
            if proc.poll() is None:
                if graceful:
                    try:
                        proc.wait(timeout=LIVE_TALK_STOP_TIMEOUT_SEC)
                        continue
                    except Exception:
                        pass

                proc.terminate()

                try:
                    proc.wait(timeout=LIVE_TALK_STOP_TIMEOUT_SEC)
                except Exception:
                    proc.kill()
        except Exception:
            pass


def finish_live_talk_after_drain() -> None:
    deadline = time.time() + LIVE_TALK_GRACEFUL_DRAIN_TIMEOUT_SEC

    while not stop_event.is_set() and time.time() < deadline:
        if live_talk_queue.qsize() <= 0:
            time.sleep(LIVE_TALK_GRACEFUL_IDLE_DELAY_SEC)
            break

        time.sleep(0.1)

    set_live_talk_active(False)
    set_live_talk_stopping(False)

    cleared_count = clear_live_talk_queue()
    stop_live_talk_processes(graceful=True)

    update_state(lambda s: s["system"].update({
        "live_talk_active": False,
        "live_talk_draining": False,
        "live_talk_last_stopped_at": now_str(),
        "live_talk_queue_size": live_talk_queue.qsize()
    }), force_flush=True)

    add_event("live_talk_stopped_after_drain", {
        "device_id": DEVICE_ID,
        "cleared_count": cleared_count,
        "time": now_str()
    })


def start_live_talk_pipeline() -> bool:
    global live_talk_ffmpeg_process, live_talk_aplay_process

    with live_talk_lock:
        existing_ffmpeg_ok = (
            live_talk_ffmpeg_process is not None
            and live_talk_ffmpeg_process.poll() is None
        )
        existing_aplay_ok = (
            live_talk_aplay_process is not None
            and live_talk_aplay_process.poll() is None
        )

        if existing_ffmpeg_ok and existing_aplay_ok:
            return True

    stop_live_talk_processes()

    ffmpeg_cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-fflags",
        "nobuffer",
        "-flags",
        "low_delay",
        "-probesize",
        "32768",
        "-analyzeduration",
        "0",
        "-i",
        "pipe:0",
        "-vn",
        "-af",
        LIVE_TALK_VOLUME_FILTER,
        "-acodec",
        "pcm_s16le",
        "-ac",
        "1",
        "-ar",
        "16000",
        "-f",
        "s16le",
        "pipe:1"
    ]

    aplay_cmd = [
        "aplay",
        "-q",
        "-f",
        "S16_LE",
        "-c",
        "1",
        "-r",
        "16000",
        "-t",
        "raw",
        "-"
    ]

    try:
        ffmpeg_proc = subprocess.Popen(
            ffmpeg_cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=0
        )

        if ffmpeg_proc.stdout is None:
            raise RuntimeError("ffmpeg_stdout_not_available")

        aplay_proc = subprocess.Popen(
            aplay_cmd,
            stdin=ffmpeg_proc.stdout,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            bufsize=0
        )

        try:
            ffmpeg_proc.stdout.close()
        except Exception:
            pass

        with live_talk_lock:
            live_talk_ffmpeg_process = ffmpeg_proc
            live_talk_aplay_process = aplay_proc

        update_state(lambda s: s["system"].update({
            "live_talk_last_error": None
        }))

        return True

    except Exception as exc:
        stop_live_talk_processes()
        update_state(lambda s: s["system"].update({
            "live_talk_last_error": f"pipeline_start_failed: {exc}"
        }))
        return False


def enqueue_live_talk_chunk(audio_bytes: bytes) -> Tuple[bool, str]:
    if not audio_bytes:
        return False, "empty_audio_chunk"

    if len(audio_bytes) > LIVE_TALK_MAX_CHUNK_BYTES:
        return False, "audio_chunk_too_large"

    try:
        live_talk_queue.put({
            "audio_bytes": audio_bytes,
            "created_at": now_str()
        }, timeout=1.5)

        update_state(lambda s: s["system"].update({
            "live_talk_queue_size": live_talk_queue.qsize(),
            "live_talk_last_chunk_at": now_str(),
            "live_talk_last_error": None
        }))

        return True, "queued"

    except queue.Full:
        return False, "live_talk_queue_full"


def write_live_talk_chunk_to_pipeline(audio_bytes: bytes) -> None:
    if not is_live_talk_active():
        return

    if is_power_saving_active():
        return

    if is_network_audio_muted():
        return

    if not start_live_talk_pipeline():
        return

    with live_talk_lock:
        ffmpeg_proc = live_talk_ffmpeg_process

    if ffmpeg_proc is None or ffmpeg_proc.poll() is not None or ffmpeg_proc.stdin is None:
        update_state(lambda s: s["system"].update({
            "live_talk_last_error": "ffmpeg_pipeline_not_running"
        }))
        set_live_talk_active(False)
        return

    try:
        ffmpeg_proc.stdin.write(audio_bytes)
        ffmpeg_proc.stdin.flush()

    except BrokenPipeError:
        update_state(lambda s: s["system"].update({
            "live_talk_last_error": "ffmpeg_broken_pipe"
        }))
        set_live_talk_active(False)
        stop_live_talk_processes()

    except Exception as exc:
        update_state(lambda s: s["system"].update({
            "live_talk_last_error": f"pipeline_write_failed: {exc}"
        }))
        set_live_talk_active(False)
        stop_live_talk_processes()


def live_talk_worker_loop() -> None:
    LIVE_TALK_DIR.mkdir(parents=True, exist_ok=True)

    while not stop_event.is_set():
        try:
            job = live_talk_queue.get(timeout=1)
        except queue.Empty:
            continue

        try:
            audio_bytes = job.get("audio_bytes", b"")

            if is_live_talk_active():
                write_live_talk_chunk_to_pipeline(audio_bytes)

        finally:
            try:
                live_talk_queue.task_done()
            except Exception:
                pass

            update_state(lambda s: s["system"].update({
                "live_talk_queue_size": live_talk_queue.qsize()
            }))

def main_upload_buffer_loop() -> None:
    """
    MAIN-stream reader for high-quality SFTP uploads.
    It does not run AI detection and it does not feed the live dashboard.
    It only maintains:
      1. latest_main_frame for uploaded JPG snapshots
      2. rolling_video_buffer for uploaded MP4 event clips

    To protect Pi 5 1GB RAM/CPU, the main stream is sampled at
    ROLLING_BUFFER_TARGET_FPS instead of copying/encoding every RTSP frame.
    """
    global latest_main_frame, latest_main_frame_ts

    min_store_gap = 1.0 / max(float(ROLLING_BUFFER_TARGET_FPS), 1.0)
    last_main_store_ts = 0.0

    while not stop_event.is_set():
        if is_power_saving_active():
            with frame_lock:
                latest_main_frame = None
                latest_main_frame_ts = 0.0

            update_state(lambda s: s["system"].update({
                "main_stream_connected": False,
                "main_stream_last_error": "Power saving mode active"
            }))
            time.sleep(1)
            continue

        cap = open_main_rtsp()

        if not cap.isOpened():
            update_state(lambda s: s["system"].update({
                "main_stream_connected": False,
                "main_stream_last_error": "Unable to open MAIN RTSP stream"
            }))
            time.sleep(3)
            continue

        update_state(lambda s: s["system"].update({
            "main_stream_connected": True,
            "main_stream_last_error": None
        }))

        while not stop_event.is_set():
            if is_power_saving_active():
                with frame_lock:
                    latest_main_frame = None
                    latest_main_frame_ts = 0.0

                update_state(lambda s: s["system"].update({
                    "main_stream_connected": False,
                    "main_stream_last_error": "Power saving mode active"
                }))
                break

            ok, raw_frame = cap.read()
            if not ok or raw_frame is None:
                update_state(lambda s: s["system"].update({
                    "main_stream_connected": False,
                    "main_stream_last_error": "MAIN RTSP read failed, reconnecting"
                }))
                break

            frame_ts = time.time()

            if (frame_ts - last_main_store_ts) < min_store_gap:
                continue

            last_main_store_ts = frame_ts

            with frame_lock:
                latest_main_frame = raw_frame.copy()
                latest_main_frame_ts = frame_ts

            # High-quality video upload buffer uses MAIN stream.
            add_frame_to_rolling_buffer(raw_frame, frame_ts)

            update_state(lambda s: s["system"].update({
                "main_stream_connected": True,
                "main_stream_last_frame_at": now_str(),
                "main_stream_last_error": None
            }))

        cap.release()
        time.sleep(2)


def reader_loop() -> None:
    global latest_frame, latest_live_frame, latest_frame_ts

    last_live_update_ts = 0.0
    live_update_gap = 1.0 / max(float(LIVE_FRAME_UPDATE_FPS), 1.0)

    while not stop_event.is_set():
        if is_power_saving_active():
            clear_latest_frame()
            update_state(lambda s: s["system"].update({
                "camera_connected": False,
                "last_error": "Power saving mode active"
            }))
            time.sleep(1)
            continue

        cap = open_rtsp()

        if not cap.isOpened():
            update_state(lambda s: s["system"].update({
                "camera_connected": False,
                "last_error": "Unable to open SUB RTSP stream"
            }))
            time.sleep(3)
            continue

        update_state(lambda s: s["system"].update({
            "camera_connected": True,
            "last_error": None
        }))

        while not stop_event.is_set():
            if is_power_saving_active():
                clear_latest_frame()
                update_state(lambda s: s["system"].update({
                    "camera_connected": False,
                    "last_error": "Power saving mode active"
                }))
                break

            ok, raw_frame = cap.read()
            if not ok or raw_frame is None:
                update_state(lambda s: s["system"].update({
                    "camera_connected": False,
                    "last_error": "RTSP read failed, reconnecting"
                }))
                break

            frame_ts = time.time()

            # Detection/process frame.
            # Keep this at 640 width to preserve old detection output.
            process_frame = resize_frame_to_width(raw_frame, PROCESS_FRAME_WIDTH)

            live_frame = None

            # Do not create high-resolution live frame on every camera frame.
            # This is the main lag fix.
            if (frame_ts - last_live_update_ts) >= live_update_gap:
                live_frame = resize_frame_to_width(raw_frame, LIVE_FRAME_WIDTH)
                last_live_update_ts = frame_ts

            with frame_lock:
                latest_frame = process_frame

                if live_frame is not None:
                    latest_live_frame = live_frame

                latest_frame_ts = frame_ts

            # Event image/video upload buffer is handled by main_upload_buffer_loop()
            # using the MAIN stream, not this SUB stream.

            update_state(lambda s: s["system"].update({
                "camera_connected": True,
                "last_frame_at": now_str(),
                "last_error": None
            }))

        cap.release()
        time.sleep(2)


def detector_loop() -> None:
    last_person_event_ts = 0.0
    last_audio_ts = 0.0
    last_vehicle_audio_ts = 0.0
    last_seen_person_ts = 0.0
    person_inside_started_ts = 0.0
    person_inside_last_seen_ts = 0.0
    person_inside_hit_count = 0
    consecutive_hits = 0
    consecutive_misses = 0
    counter = 0
    person_present_latch = False

    last_vehicle_event_ts = 0.0
    last_seen_vehicle_ts = 0.0
    vehicle_present_latch = False
    vehicle_confirm_hits = 0

    # Vehicle stable-inside-marking confirmation state.
    vehicle_inside_started_ts = 0.0
    vehicle_inside_last_seen_ts = 0.0
    vehicle_inside_hit_count = 0

    # Per marked-area visit event state.
    # Event 1 fires after editable vehicle_static_stay_sec.
    # Event 2 fires once after VEHICLE_SECOND_EVENT_DELAY_SEC from Event 1.
    vehicle_first_event_fired = False
    vehicle_second_event_fired = False
    vehicle_first_event_ts = 0.0

    previous_motion_frame: Optional[np.ndarray] = None
    last_person_static_stay_sec = load_person_static_stay_sec()
    last_vehicle_detection_mode = load_vehicle_detection_mode()
    last_vehicle_static_stay_sec = load_vehicle_static_stay_sec()
    last_disabled_state_update_ts = 0.0
    last_processed_frame_ts = 0.0

    while not stop_event.is_set():
        if is_power_saving_active():
            consecutive_hits = 0
            consecutive_misses = 0
            person_present_latch = False
            person_inside_started_ts = 0.0
            person_inside_last_seen_ts = 0.0
            person_inside_hit_count = 0

            vehicle_present_latch = False
            vehicle_confirm_hits = 0
            vehicle_inside_started_ts = 0.0
            vehicle_inside_last_seen_ts = 0.0
            vehicle_inside_hit_count = 0
            vehicle_first_event_fired = False
            vehicle_second_event_fired = False
            vehicle_first_event_ts = 0.0

            previous_motion_frame = None

            update_state(lambda s: s.update({
                "last_person": {
                    "detected": False,
                    "time": s["last_person"].get("time"),
                    "image": s["last_person"].get("image"),
                    "image_file": s["last_person"].get("image_file"),
                    "image_status": s["last_person"].get("image_status"),
                    "image_uploaded_path": s["last_person"].get("image_uploaded_path"),
                    "count": s["last_person"].get("count", 0),
                    "best_confidence": s["last_person"].get("best_confidence", 0),
                    "stable_inside_sec": 0.0,
                    "stable_required_sec": load_person_static_stay_sec(),
                    "stable_hit_count": 0
                },
                "last_vehicle": {
                    "detected": False,
                    "time": s["last_vehicle"].get("time"),
                    "image": s["last_vehicle"].get("image"),
                    "count": s["last_vehicle"].get("count", 0),
                    "best_confidence": s["last_vehicle"].get("best_confidence", 0.0),
                    "labels": s["last_vehicle"].get("labels", []),
                    "image_status": s["last_vehicle"].get("image_status"),
                    "image_file": s["last_vehicle"].get("image_file"),
                    "image_uploaded_path": s["last_vehicle"].get("image_uploaded_path"),
                    "mode": load_vehicle_detection_mode(),
                    "geofence_overlap": s["last_vehicle"].get("geofence_overlap", 0.0),
                    "stable_inside_sec": 0.0,
                    "stable_required_sec": load_vehicle_static_stay_sec(),
                    "stable_hit_count": 0,
                    "stable_vehicle_count": 0,
                    "first_event_fired": False,
                    "second_event_fired": False,
                    "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                    "first_event_elapsed_sec": 0.0,
                }
            }))

            time.sleep(1)
            continue

        frame, frame_ts = get_frame_copy_with_ts()
        if frame is None:
            time.sleep(0.02)
            continue

        if frame_ts <= last_processed_frame_ts:
            time.sleep(0.005)
            continue

        last_processed_frame_ts = frame_ts

        flags = load_feature_flags()
        person_detection_enabled = bool(flags.get("person_detection_enabled", True))
        vehicle_detection_enabled = bool(flags.get("vehicle_detection_enabled", True))
        person_video_recording_enabled = bool(flags.get("person_video_recording_enabled", True))
        vehicle_video_recording_enabled = bool(flags.get("vehicle_video_recording_enabled", True))
        person_static_stay_sec = load_person_static_stay_sec()
        vehicle_detection_mode = load_vehicle_detection_mode()
        vehicle_static_stay_sec = load_vehicle_static_stay_sec()

        if abs(person_static_stay_sec - last_person_static_stay_sec) >= 0.01:
            consecutive_hits = 0
            consecutive_misses = 0
            person_present_latch = False
            person_inside_started_ts = 0.0
            person_inside_last_seen_ts = 0.0
            person_inside_hit_count = 0
            last_person_static_stay_sec = person_static_stay_sec

        if (
            vehicle_detection_mode != last_vehicle_detection_mode or
            abs(vehicle_static_stay_sec - last_vehicle_static_stay_sec) >= 0.01
        ):
            vehicle_present_latch = False
            vehicle_confirm_hits = 0
            vehicle_inside_started_ts = 0.0
            vehicle_inside_last_seen_ts = 0.0
            vehicle_inside_hit_count = 0
            vehicle_first_event_fired = False
            vehicle_second_event_fired = False
            vehicle_first_event_ts = 0.0
            previous_motion_frame = None
            last_vehicle_detection_mode = vehicle_detection_mode
            last_vehicle_static_stay_sec = vehicle_static_stay_sec

        if not person_detection_enabled:
            consecutive_hits = 0
            consecutive_misses = 0
            person_present_latch = False
            person_inside_started_ts = 0.0
            person_inside_last_seen_ts = 0.0
            person_inside_hit_count = 0

        if not vehicle_detection_enabled:
            vehicle_present_latch = False
            vehicle_confirm_hits = 0
            vehicle_inside_started_ts = 0.0
            vehicle_inside_last_seen_ts = 0.0
            vehicle_inside_hit_count = 0
            vehicle_first_event_fired = False
            vehicle_second_event_fired = False
            vehicle_first_event_ts = 0.0
            previous_motion_frame = None

        if (not person_detection_enabled or not vehicle_detection_enabled) and (time.time() - last_disabled_state_update_ts) >= 1.0:
            def mark_disabled_detection_state(state):
                if not person_detection_enabled:
                    state["last_person"] = {
                        "detected": False,
                        "time": state["last_person"].get("time"),
                        "image": state["last_person"].get("image"),
                        "count": state["last_person"].get("count", 0),
                        "best_confidence": state["last_person"].get("best_confidence", 0),
                        "stable_inside_sec": 0.0,
                        "stable_required_sec": load_person_static_stay_sec(),
                        "stable_hit_count": 0,
                    }

                if not vehicle_detection_enabled:
                    state["last_vehicle"] = {
                        "detected": False,
                        "time": state["last_vehicle"].get("time"),
                        "image": state["last_vehicle"].get("image"),
                        "count": state["last_vehicle"].get("count", 0),
                        "best_confidence": state["last_vehicle"].get("best_confidence", 0.0),
                        "labels": state["last_vehicle"].get("labels", []),
                        "image_status": state["last_vehicle"].get("image_status"),
                        "image_file": state["last_vehicle"].get("image_file"),
                        "image_uploaded_path": state["last_vehicle"].get("image_uploaded_path"),
                        "mode": vehicle_detection_mode,
                        "geofence_overlap": state["last_vehicle"].get("geofence_overlap", 0.0),
                        "stable_inside_sec": 0.0,
                        "stable_required_sec": vehicle_static_stay_sec,
                        "stable_hit_count": 0,
                        "stable_vehicle_count": 0,
                        "first_event_fired": False,
                        "second_event_fired": False,
                        "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                        "first_event_elapsed_sec": 0.0,
                    }

                state["feature_flags"] = flags

            update_state(mark_disabled_detection_state)
            last_disabled_state_update_ts = time.time()

        if not person_detection_enabled and not vehicle_detection_enabled:
            time.sleep(0.05)
            continue

        counter += 1
        persons: List[Dict[str, Any]] = []
        vehicles: List[Dict[str, Any]] = []

        try:
            motion_mask = None

            if vehicle_detection_enabled:
                # Build motion mask for both static and moving modes.
                # Moving mode needs this continuously.
                motion_mask = create_motion_mask(previous_motion_frame, frame)
                previous_motion_frame = frame.copy()
            else:
                previous_motion_frame = None

            if person_detection_enabled and (PERSON_DETECT_EVERY_N_FRAMES <= 1 or counter % PERSON_DETECT_EVERY_N_FRAMES == 0):
                persons = detect_persons(frame)
                print(
                    f"[PERSON DEBUG] raw_detected={len(persons)} "
                    f"hits={consecutive_hits}",
                    flush=True
                )

            if vehicle_detection_enabled and (VEHICLE_DETECT_EVERY_N_FRAMES <= 1 or counter % VEHICLE_DETECT_EVERY_N_FRAMES == 0):
                vehicles = detect_vehicles(frame, motion_mask, vehicle_detection_mode)
                print(
                    f"[VEHICLE DEBUG] mode={vehicle_detection_mode} "
                    f"detected={len(vehicles)} "
                    f"hits={vehicle_confirm_hits} "
                    f"stay={vehicle_static_stay_sec}s",
                    flush=True
                )

            # ---------------- PERSON FLOW ----------------
            if person_detection_enabled:
                if persons:
                    now_ts = time.time()
                    consecutive_hits += 1
                    consecutive_misses = 0
                    last_seen_person_ts = now_ts

                    confirmed_person = consecutive_hits >= PERSON_CONFIRMATION_FRAMES

                    if confirmed_person:
                        if person_inside_started_ts <= 0.0:
                            person_inside_started_ts = now_ts
                            person_inside_hit_count = 0

                        person_inside_last_seen_ts = now_ts
                        person_inside_hit_count += 1

                    person_stable_inside_sec = (
                        max(0.0, now_ts - person_inside_started_ts)
                        if person_inside_started_ts > 0.0 else 0.0
                    )
                    stable_person = (
                        confirmed_person and
                        person_stable_inside_sec >= person_static_stay_sec
                    )

                    best_conf = round(max(p["confidence"] for p in persons), 3)

                    update_state(lambda s: s.update({
                        "last_person": {
                            "detected": stable_person,
                            "time": now_str(),
                            "image": s["last_person"].get("image"),
                            "image_file": s["last_person"].get("image_file"),
                            "image_status": s["last_person"].get("image_status"),
                            "image_uploaded_path": s["last_person"].get("image_uploaded_path"),
                            "count": len(persons),
                            "best_confidence": best_conf,
                            "stable_inside_sec": round(person_stable_inside_sec, 1),
                            "stable_required_sec": person_static_stay_sec,
                            "stable_hit_count": person_inside_hit_count
                        }
                    }))

                    is_new_person = stable_person and (not person_present_latch)

                    # Warning audio trigger:
                    # Old logic played only once for a "new person".
                    # New logic repeats warning every AUDIO_COOLDOWN_SEC while person remains visible.
                    should_trigger_warning = (
                        stable_person and
                        (now_ts - last_audio_ts) >= AUDIO_COOLDOWN_SEC
                    )

                    if should_trigger_warning:
                        allowed, reason = is_warning_audio_allowed("person")

                        update_state(lambda s: s["warning_audio"].update({
                            "last_status": reason,
                            "last_person_status": reason,
                            "last_checked_at": now_str(),
                            "last_person_checked_at": now_str()
                        }))

                        if allowed:
                            update_state(lambda s: s.update({
                                "last_audio": {
                                    "file": "warning.wav",
                                    "source_path": str(ASSET_DIR / "warning.wav"),
                                    "time": now_str(),
                                    "status": "person_warning_triggered"
                                }
                            }))

                            add_event("warning_audio_triggered", {
                                "target": "person",
                                "reason": reason,
                                "mode": "stable_person_repeat",
                                "confirmation_frames": PERSON_CONFIRMATION_FRAMES,
                                "stable_inside_sec": round(person_stable_inside_sec, 1),
                                "stable_required_sec": person_static_stay_sec,
                                "person_count": len(persons),
                                "best_confidence": best_conf
                            })

                            print(
                                "[WARNING AUDIO] Triggered "
                                f"person_count={len(persons)} "
                                f"best_conf={best_conf} "
                                f"reason={reason}",
                                flush=True
                            )

                            threading.Thread(
                                target=play_warning_audio,
                                args=("person",),
                                daemon=True
                            ).start()

                            last_audio_ts = now_ts
                        else:
                            print(
                                f"[WARNING AUDIO] Skipped reason={reason}",
                                flush=True
                            )

                            add_event("warning_audio_skipped", {
                                "target": "person",
                                "reason": reason,
                                "person_count": len(persons),
                                "best_confidence": best_conf
                            })

                    should_fire_event = (
                        is_new_person and
                        (now_ts - last_person_event_ts) >= PERSON_COOLDOWN_SEC
                    )

                    if should_fire_event:
                        now = now_dt()
                        event_ts = time.time()

                        filename = f"{DEVICE_ID}_Person_{now.strftime('%Y%m%d_%H%M%S')}.jpg"
                        marked, persons_for_upload, image_source_stream = build_high_quality_event_image(
                            detection_frame=frame,
                            detections=persons,
                            draw_fn=draw_person_annotations,
                            refine_fn=detect_persons,
                            strict_refine=True,
                        )

                        if not persons_for_upload:
                            add_event("person_event_cancelled_no_main_redetect", {
                                "reason": "person not confirmed on exact event image frame",
                                "source_stream": image_source_stream,
                                "substream_person_count": len(persons),
                                "best_confidence": best_conf,
                            })
                            print(
                                "[PERSON EVENT] Cancelled: person was not confirmed "
                                f"on event image frame source={image_source_stream}",
                                flush=True
                            )
                            person_present_latch = False
                            person_inside_started_ts = 0.0
                            person_inside_last_seen_ts = 0.0
                            person_inside_hit_count = 0
                            consecutive_hits = 0
                            update_state(lambda s: s.update({
                                "last_person": {
                                    "detected": False,
                                    "time": s["last_person"].get("time"),
                                    "image": s["last_person"].get("image"),
                                    "image_file": s["last_person"].get("image_file"),
                                    "image_status": s["last_person"].get("image_status"),
                                    "image_uploaded_path": s["last_person"].get("image_uploaded_path"),
                                    "count": 0,
                                    "best_confidence": 0,
                                    "stable_inside_sec": 0.0,
                                    "stable_required_sec": person_static_stay_sec,
                                    "stable_hit_count": 0,
                                    "image_source_stream": image_source_stream,
                                }
                            }))
                            continue

                        best_conf_for_upload = round(max(float(p.get("confidence", 0.0) or 0.0) for p in persons_for_upload), 3)

                        rel_img, path = save_capture(marked, filename, garbage=False)
                        remote_image_path = f"{SFTP_PERSON_DIR.rstrip('/')}/{filename}"

                        update_state(lambda s: s.update({
                            "last_person": {
                                "detected": True,
                                "time": now.strftime("%Y-%m-%d %H:%M:%S"),
                                "image": rel_img,
                                "image_file": filename,
                                "image_status": "saved_local_uploading",
                                "image_uploaded_path": remote_image_path,
                                "count": len(persons_for_upload),
                                "best_confidence": best_conf_for_upload,
                                "stable_inside_sec": round(person_stable_inside_sec, 1),
                                "stable_required_sec": person_static_stay_sec,
                                "stable_hit_count": person_inside_hit_count,
                                "image_source_stream": image_source_stream
                            }
                        }))

                        async_upload_person_image(path, SFTP_PERSON_DIR, filename, remote_image_path)

                        if person_video_recording_enabled:
                            threading.Thread(
                                target=handle_person_video_event,
                                args=(now, event_ts, len(persons_for_upload), best_conf_for_upload, filename, remote_image_path),
                                daemon=True
                            ).start()
                        else:
                            update_state(lambda s: s.update({
                                "last_video": {
                                    "file": None,
                                    "time": now.strftime("%Y-%m-%d %H:%M:%S"),
                                    "status": "skipped_disabled_by_mqtt",
                                    "duration_sec": 0,
                                    "person_count": len(persons_for_upload),
                                    "best_confidence": best_conf_for_upload,
                                }
                            }))

                            add_event("person_video_recording_skipped", {
                                "reason": "person video recording disabled by mqtt command",
                                "image_file": filename,
                                "image_path": remote_image_path,
                                "person_count": len(persons_for_upload),
                                "best_confidence": best_conf_for_upload,
                            })

                            try:
                                mqtt_publish(MQTT_CAMERA_EVENT_TOPIC, {
                                    "date": now.strftime("%Y-%m-%d"),
                                    "time": now.strftime("%H:%M:%S"),
                                    "event": "person_detected",
                                    "device_id": DEVICE_ID,
                                    "image_file": filename,
                                    "video_file": None,
                                    "image_path": remote_image_path,
                                    "video_path": None,
                                    "camera_name": CAMERA_NAME,
                                    "duration_sec": 0,
                                    "person_count": len(persons_for_upload),
                                    "video_status": "skipped",
                                    "video_message": "Person video recording disabled by MQTT command",
                                    "best_confidence": best_conf_for_upload,
                                    "video_uploaded_at": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
                                    **build_common_links_payload(),
                                })
                                update_state(lambda s: s["system"].update({
                                    "mqtt_last_ok": now_str(),
                                    "mqtt_last_error": None,
                                }))
                            except Exception as mqtt_exc:
                                update_state(lambda s: s["system"].update({
                                    "mqtt_last_error": str(mqtt_exc),
                                }))

                        last_person_event_ts = now_ts

                    if stable_person:
                        person_present_latch = True

                else:
                    consecutive_hits = 0
                    consecutive_misses += 1

                    if (time.time() - last_seen_person_ts) >= PERSON_LOST_TIMEOUT_SEC:
                        person_present_latch = False
                        person_inside_started_ts = 0.0
                        person_inside_last_seen_ts = 0.0
                        person_inside_hit_count = 0
                        update_state(lambda s: s.update({
                            "last_person": {
                                "detected": False,
                                "time": s["last_person"].get("time"),
                                "image": s["last_person"].get("image"),
                                "image_file": s["last_person"].get("image_file"),
                                "image_status": s["last_person"].get("image_status"),
                                "image_uploaded_path": s["last_person"].get("image_uploaded_path"),
                                "count": s["last_person"].get("count", 0),
                                "best_confidence": s["last_person"].get("best_confidence", 0),
                                "stable_inside_sec": 0.0,
                                "stable_required_sec": person_static_stay_sec,
                                "stable_hit_count": 0
                            }
                        }))

            # ---------------- VEHICLE FLOW ----------------
            if vehicle_detection_enabled:
                now_ts = time.time()

                def get_vehicle_overlap(vehicle: Dict[str, Any]) -> float:
                    try:
                        return float(
                            vehicle.get(
                                "geofence_overlap",
                                vehicle.get(
                                    "overlap_ratio",
                                    vehicle.get("overlap", 0.0)
                                )
                            ) or 0.0
                        )
                    except Exception:
                        return 0.0

                stable_vehicle_candidates = []
                vehicle_event_overlap_threshold = load_vehicle_geofence_overlap_threshold()

                for vehicle in vehicles:
                    vehicle_conf = float(vehicle.get("confidence", 0.0) or 0.0)
                    vehicle_overlap = get_vehicle_overlap(vehicle)

                    if (
                        vehicle_conf >= VEHICLE_EVENT_MIN_CONF and
                        vehicle_overlap >= vehicle_event_overlap_threshold
                    ):
                        stable_vehicle_candidates.append(vehicle)

                raw_vehicle_count = len(vehicles)
                stable_vehicle_count = len(stable_vehicle_candidates)

                if vehicles:
                    best_vehicle_conf = round(
                        max(float(v.get("confidence", 0.0) or 0.0) for v in vehicles),
                        3
                    )
                    vehicle_labels = sorted({
                        str(v.get("label", "vehicle")).strip() or "vehicle"
                        for v in vehicles
                    })
                    best_geofence_overlap = round(
                        max(get_vehicle_overlap(v) for v in vehicles),
                        3
                    )
                else:
                    best_vehicle_conf = 0.0
                    vehicle_labels = []
                    best_geofence_overlap = 0.0

                if stable_vehicle_candidates:
                    last_seen_vehicle_ts = now_ts
                    vehicle_confirm_hits += 1

                    if (
                        vehicle_inside_started_ts <= 0.0 or
                        (now_ts - vehicle_inside_last_seen_ts) > VEHICLE_STABLE_GRACE_SEC
                    ):
                        vehicle_inside_started_ts = now_ts
                        vehicle_inside_hit_count = 0

                    vehicle_inside_last_seen_ts = now_ts
                    vehicle_inside_hit_count += 1

                else:
                    # Do not clear vehicle_inside_last_seen_ts immediately.
                    # It is needed to know when the vehicle has really exited the marked area.
                    if (
                        vehicle_inside_last_seen_ts > 0.0 and
                        (now_ts - vehicle_inside_last_seen_ts) > VEHICLE_STABLE_GRACE_SEC
                    ):
                        vehicle_inside_started_ts = 0.0
                        vehicle_inside_hit_count = 0
                        vehicle_confirm_hits = max(0, vehicle_confirm_hits - 1)

                vehicle_stable_inside_sec = 0.0

                if vehicle_inside_started_ts > 0.0 and stable_vehicle_candidates:
                    vehicle_stable_inside_sec = max(0.0, now_ts - vehicle_inside_started_ts)

                if vehicle_detection_mode == "moving":
                    # Moving mode still waits for the editable stay time before Event 1.
                    # This prevents immediate event spam when a vehicle touches the geofence.
                    confirmed_vehicle = (
                        stable_vehicle_count > 0 and
                        vehicle_stable_inside_sec >= vehicle_static_stay_sec and
                        vehicle_inside_hit_count >= 1
                    )
                else:
                    # Static vehicle must remain inside geofence for editable stay time.
                    confirmed_vehicle = (
                        stable_vehicle_count > 0 and
                        vehicle_stable_inside_sec >= vehicle_static_stay_sec and
                        vehicle_inside_hit_count >= VEHICLE_MIN_STABLE_HITS
                    )

                display_detected = confirmed_vehicle

                first_event_elapsed_sec = 0.0
                if vehicle_first_event_fired and vehicle_first_event_ts > 0.0:
                    first_event_elapsed_sec = max(0.0, now_ts - vehicle_first_event_ts)

                update_state(lambda s: s.update({
                    "last_vehicle": {
                        "detected": display_detected,
                        "time": now_str() if raw_vehicle_count > 0 else s["last_vehicle"].get("time"),
                        "image": s["last_vehicle"].get("image"),
                        "count": raw_vehicle_count,
                        "best_confidence": best_vehicle_conf,
                        "labels": vehicle_labels,
                        "image_status": s["last_vehicle"].get("image_status"),
                        "image_file": s["last_vehicle"].get("image_file"),
                        "image_uploaded_path": s["last_vehicle"].get("image_uploaded_path"),
                        "mode": vehicle_detection_mode,
                        "geofence_overlap": best_geofence_overlap,
                        "stable_inside_sec": round(vehicle_stable_inside_sec, 1),
                        "stable_hit_count": vehicle_inside_hit_count,
                        "stable_required_sec": vehicle_static_stay_sec,
                        "stable_vehicle_count": stable_vehicle_count,
                        "first_event_fired": vehicle_first_event_fired,
                        "second_event_fired": vehicle_second_event_fired,
                        "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                        "first_event_elapsed_sec": round(first_event_elapsed_sec, 1),
                    }
                }))

                def fire_vehicle_event(vehicle_event_type: str) -> None:
                    nonlocal last_vehicle_audio_ts

                    now = now_dt()
                    event_ts = time.time()

                    vehicles_for_event = stable_vehicle_candidates
                    marked_vehicle, vehicles_for_upload, image_source_stream = build_high_quality_event_image(
                        detection_frame=frame,
                        detections=vehicles_for_event,
                        draw_fn=draw_vehicle_annotations,
                    )

                    if marked_vehicle is None:
                        add_event("vehicle_event_image_cancelled_no_main_stream", {
                            "reason": "MAIN stream unavailable; SUB/D1 image upload disabled",
                            "source_stream": image_source_stream,
                            "vehicle_count": len(vehicles_for_event),
                            "best_confidence": best_vehicle_conf,
                        })
                        update_state(lambda s: s.update({
                            "last_vehicle": {
                                "detected": True,
                                "time": now.strftime("%Y-%m-%d %H:%M:%S"),
                                "image": s["last_vehicle"].get("image"),
                                "count": len(vehicles_for_event),
                                "best_confidence": best_vehicle_conf,
                                "labels": vehicle_labels,
                                "image_status": "cancelled_no_main_stream",
                                "image_file": s["last_vehicle"].get("image_file"),
                                "image_uploaded_path": s["last_vehicle"].get("image_uploaded_path"),
                                "mode": vehicle_detection_mode,
                                "geofence_overlap": best_geofence_overlap,
                                "stable_inside_sec": round(vehicle_stable_inside_sec, 1),
                                "stable_hit_count": vehicle_inside_hit_count,
                                "stable_required_sec": vehicle_static_stay_sec,
                                "stable_vehicle_count": len(vehicles_for_event),
                                "vehicle_event_type": vehicle_event_type,
                                "first_event_fired": vehicle_first_event_fired,
                                "second_event_fired": vehicle_second_event_fired,
                                "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                                "first_event_elapsed_sec": round(first_event_elapsed_sec, 1),
                                "image_source_stream": image_source_stream,
                            }
                        }))
                        return

                    vehicle_snapshot = f"{DEVICE_ID}_Vehicle_{now.strftime('%Y%m%d_%H%M%S')}.jpg"
                    rel_img, path = save_capture(marked_vehicle, vehicle_snapshot, garbage=False)
                    remote_vehicle_image_path = f"{SFTP_VEHICLE_DIR.rstrip('/')}/{vehicle_snapshot}"

                    update_state(lambda s: s.update({
                        "last_vehicle": {
                            "detected": True,
                            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
                            "image": rel_img,
                            "count": len(vehicles_for_event),
                            "best_confidence": best_vehicle_conf,
                            "labels": vehicle_labels,
                            "image_status": "uploading",
                            "image_file": vehicle_snapshot,
                            "image_uploaded_path": remote_vehicle_image_path,
                            "mode": vehicle_detection_mode,
                            "geofence_overlap": best_geofence_overlap,
                            "stable_inside_sec": round(vehicle_stable_inside_sec, 1),
                            "stable_hit_count": vehicle_inside_hit_count,
                            "stable_required_sec": vehicle_static_stay_sec,
                            "stable_vehicle_count": len(vehicles_for_event),
                            "vehicle_event_type": vehicle_event_type,
                            "first_event_fired": vehicle_first_event_fired,
                            "second_event_fired": vehicle_second_event_fired,
                            "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                            "first_event_elapsed_sec": round(first_event_elapsed_sec, 1),
                            "image_source_stream": image_source_stream,
                        }
                    }))

                    event_key = init_vehicle_event_result(
                        event_time=now,
                        vehicle_count=len(vehicles_for_event),
                        best_confidence=best_vehicle_conf,
                        vehicle_labels=vehicle_labels,
                    )

                    async_upload_vehicle_image(
                        local_path=path,
                        remote_dir=SFTP_VEHICLE_DIR,
                        remote_name=vehicle_snapshot,
                        event_time=now,
                        vehicle_count=len(vehicles_for_event),
                        best_confidence=best_vehicle_conf,
                        vehicle_labels=vehicle_labels,
                        rel_img=rel_img,
                        vehicle_mode=vehicle_detection_mode,
                        geofence_overlap=best_geofence_overlap,
                    )

                    if vehicle_video_recording_enabled:
                        threading.Thread(
                            target=handle_vehicle_video_event,
                            args=(
                                now,
                                event_ts,
                                len(vehicles_for_event),
                                best_vehicle_conf,
                                vehicle_labels
                            ),
                            daemon=True
                        ).start()
                    else:
                        update_state(lambda s: s.update({
                            "last_vehicle_video": {
                                "file": None,
                                "time": now.strftime("%Y-%m-%d %H:%M:%S"),
                                "status": "skipped_disabled_by_mqtt",
                                "duration_sec": 0,
                                "vehicle_count": len(vehicles_for_event),
                                "best_confidence": best_vehicle_conf,
                                "labels": vehicle_labels,
                            }
                        }))

                        update_vehicle_event_result(
                            event_key,
                            video_done=True,
                            video_ok=False,
                            video_file=None,
                            video_path=None,
                            video_status="skipped",
                            video_message="Vehicle video recording disabled by MQTT command",
                            duration_sec=0,
                        )
                        maybe_publish_vehicle_combined_response(event_key)

                        add_event("vehicle_video_recording_skipped", {
                            "reason": "vehicle video recording disabled by mqtt command",
                            "vehicle_count": len(vehicles_for_event),
                            "vehicle_labels": vehicle_labels,
                            "best_confidence": best_vehicle_conf,
                        })

                    should_trigger_vehicle_warning = (
                        (event_ts - last_vehicle_audio_ts) >= AUDIO_COOLDOWN_SEC
                    )

                    if should_trigger_vehicle_warning:
                        allowed, reason = is_warning_audio_allowed("vehicle")

                        update_state(lambda s: s["warning_audio"].update({
                            "last_status": reason,
                            "last_vehicle_status": reason,
                            "last_checked_at": now_str(),
                            "last_vehicle_checked_at": now_str()
                        }))

                        if allowed:
                            update_state(lambda s: s.update({
                                "last_audio": {
                                    "file": "warning.wav",
                                    "source_path": str(ASSET_DIR / "warning.wav"),
                                    "time": now_str(),
                                    "status": "vehicle_warning_triggered"
                                }
                            }))

                            add_event("warning_audio_triggered", {
                                "target": "vehicle",
                                "reason": reason,
                                "mode": "stable_vehicle_event",
                                "vehicle_event_type": vehicle_event_type,
                                "stable_inside_sec": round(vehicle_stable_inside_sec, 1),
                                "stable_required_sec": vehicle_static_stay_sec,
                                "vehicle_count": len(vehicles_for_event),
                                "best_confidence": best_vehicle_conf,
                                "labels": vehicle_labels
                            })

                            print(
                                "[WARNING AUDIO] Triggered vehicle "
                                f"count={len(vehicles_for_event)} "
                                f"best_conf={best_vehicle_conf} "
                                f"reason={reason}",
                                flush=True
                            )

                            threading.Thread(
                                target=play_warning_audio,
                                args=("vehicle",),
                                daemon=True
                            ).start()

                            last_vehicle_audio_ts = event_ts
                        else:
                            print(
                                f"[WARNING AUDIO] Skipped vehicle reason={reason}",
                                flush=True
                            )

                            add_event("warning_audio_skipped", {
                                "target": "vehicle",
                                "reason": reason,
                                "vehicle_event_type": vehicle_event_type,
                                "vehicle_count": len(vehicles_for_event),
                                "best_confidence": best_vehicle_conf,
                                "labels": vehicle_labels
                            })

                    add_event("vehicle_detected", {
                        "event_type": vehicle_event_type,
                        "mode": vehicle_detection_mode,
                        "count": len(vehicles_for_event),
                        "raw_count": raw_vehicle_count,
                        "stable_count": stable_vehicle_count,
                        "labels": vehicle_labels,
                        "best_confidence": best_vehicle_conf,
                        "geofence_overlap": best_geofence_overlap,
                        "stable_inside_sec": round(vehicle_stable_inside_sec, 1),
                        "stable_required_sec": vehicle_static_stay_sec,
                        "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                        "snapshot": rel_img,
                        "image_path": remote_vehicle_image_path,
                    })

                should_fire_first_vehicle_event = (
                    confirmed_vehicle and
                    not vehicle_first_event_fired
                )

                should_fire_second_vehicle_event = (
                    confirmed_vehicle and
                    vehicle_first_event_fired and
                    not vehicle_second_event_fired and
                    vehicle_first_event_ts > 0.0 and
                    (now_ts - vehicle_first_event_ts) >= VEHICLE_SECOND_EVENT_DELAY_SEC
                )

                if should_fire_first_vehicle_event:
                    vehicle_first_event_fired = True
                    vehicle_first_event_ts = now_ts
                    fire_vehicle_event("first_stay_event")
                    last_vehicle_event_ts = now_ts
                    vehicle_present_latch = True

                elif should_fire_second_vehicle_event:
                    vehicle_second_event_fired = True
                    fire_vehicle_event("second_fixed_delay_event")
                    last_vehicle_event_ts = now_ts
                    vehicle_present_latch = True

                if confirmed_vehicle:
                    vehicle_present_latch = True

                vehicle_outside_marked_area = (
                    stable_vehicle_count <= 0 and
                    vehicle_inside_last_seen_ts > 0.0 and
                    (now_ts - vehicle_inside_last_seen_ts) >= VEHICLE_LOST_TIMEOUT_SEC
                )

                if vehicle_outside_marked_area:
                    vehicle_present_latch = False
                    vehicle_confirm_hits = 0
                    vehicle_inside_started_ts = 0.0
                    vehicle_inside_last_seen_ts = 0.0
                    vehicle_inside_hit_count = 0
                    vehicle_first_event_fired = False
                    vehicle_second_event_fired = False
                    vehicle_first_event_ts = 0.0

                    update_state(lambda s: s.update({
                        "last_vehicle": {
                            "detected": False,
                            "time": s["last_vehicle"].get("time"),
                            "image": s["last_vehicle"].get("image"),
                            "count": s["last_vehicle"].get("count", 0),
                            "best_confidence": s["last_vehicle"].get("best_confidence", 0.0),
                            "labels": s["last_vehicle"].get("labels", []),
                            "image_status": s["last_vehicle"].get("image_status"),
                            "image_file": s["last_vehicle"].get("image_file"),
                            "image_uploaded_path": s["last_vehicle"].get("image_uploaded_path"),
                            "mode": vehicle_detection_mode,
                            "geofence_overlap": s["last_vehicle"].get("geofence_overlap", 0.0),
                            "stable_inside_sec": 0.0,
                            "stable_hit_count": 0,
                            "stable_required_sec": vehicle_static_stay_sec,
                            "stable_vehicle_count": 0,
                            "first_event_fired": False,
                            "second_event_fired": False,
                            "second_event_delay_sec": VEHICLE_SECOND_EVENT_DELAY_SEC,
                            "first_event_elapsed_sec": 0.0,
                        }
                    }))
            time.sleep(0.005)

        except Exception as exc:
            update_state(lambda s: s["system"].update({"last_error": f"Detector loop error: {exc}"}))
            time.sleep(0.1)
		
		
def run_garbage_detection_normal_mode(
    triggered_by: str = "manual",
    create_live_link: bool = True
) -> Optional[Dict[str, Any]]:
    global garbage_clean_streak

    frame = get_frame_copy()
    if frame is None:
        return None

    reference_frame = _load_reference_frame()
    reference_ready = reference_frame is not None

    _, roi_box = get_garbage_roi(frame)

    marked_frame = draw_garbage_boxes(
        frame=frame,
        roi_box=roi_box,
        detections=[],
        severity="NONE",
        change_boxes=[]
    )

    if not reference_ready:
        cv2.putText(
            marked_frame,
            "Reference Missing - Send Garbage Sample Capture",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (0, 0, 255),
            2,
            cv2.LINE_AA
        )

    now = now_dt()
    filename = f"{DEVICE_ID}_{now.strftime('%Y%m%d_%H%M%S')}.jpg"
    rel_img, path = save_capture(marked_frame, filename, garbage=True)

    garbage_clean_streak = 0
    live_payload = build_live_links_payload(force_new=create_live_link)

    mqtt_payload = {
        "device_id": DEVICE_ID,
        "timestamp": now.isoformat(),
        "triggered_by": triggered_by,
        "garbage_detection_mode": "normal",
        "mode": "normal",
        "ai_mode": False,
        "normal_mode": True,
        "severity": "NONE",
        "diff_ratio": 0.0,
        "edge_ratio": 0.0,
        "blob_area_ratio": 0.0,
        "blob_count": 0,
        "garbage_count": 0,
        "garbage_labels": [],
        "reference_ready": reference_ready,
        "image_file": filename,
        "camera_name": CAMERA_NAME,
        **build_common_links_payload(),
        **live_payload
    }

    async_send(path, SFTP_GARBAGE_DIR, filename, MQTT_GARBAGE_TOPIC, mqtt_payload)

    update_state(lambda s: s.update({
        "counts": {
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0
        },
        "last_garbage": {
            "detected": False,
            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "image": rel_img,
            "severity": "NONE" if reference_ready else "REFERENCE_MISSING",
            "diff_ratio": 0.0,
            "edge_ratio": 0.0,
            "blob_area_ratio": 0.0,
            "blob_count": 0,
            "triggered_by": triggered_by,
            "reference_items": [],
            "mode": "normal"
        }
    }))

    add_event("garbage_normal_capture", {
        "image": rel_img,
        "severity": "NONE" if reference_ready else "REFERENCE_MISSING",
        "blob_count": 0,
        "triggered_by": triggered_by,
        "mode": "normal",
        "reference_ready": reference_ready
    })

    return mqtt_payload


def run_garbage_detection(triggered_by: str = "manual", create_live_link: bool = True) -> Optional[Dict[str, Any]]:
    global garbage_clean_streak

    if is_power_saving_active():
        return None

    if not is_feature_enabled("garbage_detection_enabled"):
        add_event("garbage_detection_skipped", {
            "triggered_by": triggered_by,
            "reason": "garbage detection disabled by mqtt command"
        })
        return None

    garbage_mode = load_garbage_detection_mode()

    if garbage_mode == "normal":
        return run_garbage_detection_normal_mode(
            triggered_by=triggered_by,
            create_live_link=create_live_link
        )

    result = analyze_garbage_stable()
    if result is None:
        return None

    now = now_dt()
    filename = f"{DEVICE_ID}_{now.strftime('%Y%m%d_%H%M%S')}.jpg"
    rel_img, path = save_capture(result["marked_frame"], filename, garbage=True)

    if result.get("ref_missing"):
        severity = "NONE"
        garbage_clean_streak = 0
    else:
        severity = result["severity"]
        if severity == "NONE":
            garbage_clean_streak += 1
        else:
            garbage_clean_streak = 0

    live_payload = build_live_links_payload(force_new=create_live_link)

    mqtt_payload = {
        "device_id": DEVICE_ID,
        "timestamp": now.isoformat(),
        "triggered_by": triggered_by,
        "garbage_detection_mode": "ai",
        "mode": "ai",
        "ai_mode": True,
        "normal_mode": False,
        "severity": severity,
        "diff_ratio": result["diff_ratio"],
        "edge_ratio": result["edge_ratio"],
        "blob_area_ratio": result["blob_area_ratio"],
        "blob_count": result["blob_count"],
        "garbage_count": result["blob_count"],
        "garbage_labels": result.get("garbage_labels", []),
        "reference_ready": not bool(result.get("ref_missing", False)),
        "image_file": filename,
        "camera_name": CAMERA_NAME,
        **build_common_links_payload(),
        **live_payload
    }

    async_send(path, SFTP_GARBAGE_DIR, filename, MQTT_GARBAGE_TOPIC, mqtt_payload)

    update_state(lambda s: s.update({
        "counts": {
            "HIGH": 1 if severity == "HIGH" else 0,
            "MEDIUM": 1 if severity == "MEDIUM" else 0,
            "LOW": 1 if severity == "LOW" else 0
        },
        "last_garbage": {
            "detected": (severity != "NONE") and (not result.get("ref_missing", False)),
            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "image": rel_img,
            "severity": severity if not result.get("ref_missing", False) else "REFERENCE_MISSING",
            "diff_ratio": result["diff_ratio"],
            "edge_ratio": result["edge_ratio"],
            "blob_area_ratio": result["blob_area_ratio"],
            "blob_count": result["blob_count"],
            "triggered_by": triggered_by,
            "reference_items": result.get("garbage_labels", []),
            "mode": "ai"
        }
    }))

    add_event("garbage", {
        "image": rel_img,
        "severity": severity,
        "blob_count": result["blob_count"],
        "triggered_by": triggered_by,
        "mode": "ai"
    })

    return mqtt_payload


def garbage_loop() -> None:
    last_interval_sec = max(60, int(GARBAGE_INTERVAL_SEC))
    next_run_ts = time.monotonic() + last_interval_sec

    while not stop_event.is_set():
        current_interval_sec = max(60, int(GARBAGE_INTERVAL_SEC))

        if current_interval_sec != last_interval_sec:
            last_interval_sec = current_interval_sec
            next_run_ts = time.monotonic() + current_interval_sec

        if is_power_saving_active():
            next_run_ts = time.monotonic() + current_interval_sec
            time.sleep(1)
            continue

        if not is_feature_enabled("garbage_detection_enabled"):
            next_run_ts = time.monotonic() + current_interval_sec
            time.sleep(1)
            continue

        remaining_sec = next_run_ts - time.monotonic()

        if remaining_sec > 0:
            time.sleep(min(1.0, remaining_sec))
            continue

        result, error = run_garbage_detection_guarded(
            triggered_by="scheduled",
            create_live_link=True,
            wait_for_frame_sec=5.0,
            wait_for_lock_sec=0.0
        )

        if result is None:
            message = error or "Scheduled garbage detection skipped."
            print(f"Scheduled garbage detection skipped: {message}", flush=True)

            try:
                add_event("scheduled_garbage_skipped", {
                    "reason": message
                })
            except Exception:
                pass

        next_run_ts = time.monotonic() + max(60, int(GARBAGE_INTERVAL_SEC))


def cleanup_loop() -> None:
    while not stop_event.is_set():
        cutoff = time.time() - RETENTION_SECONDS

        for folder in [FILES_DIR, GARBAGE_DIR, AUDIO_DIR, TMP_DIR]:
            if folder.exists():
                for p in folder.glob("*"):
                    try:
                        if p.is_file() and p.stat().st_mtime < cutoff:
                            p.unlink(missing_ok=True)
                    except Exception:
                        pass

        for _ in range(CLEANUP_INTERVAL_SEC):
            if stop_event.is_set():
                return
            time.sleep(1)


def heartbeat_loop() -> None:
    while not stop_event.is_set():
        try:
            refresh_runtime_links_in_state()
            refresh_device_metrics_in_state()
        except Exception:
            pass

        for _ in range(HEARTBEAT_INTERVAL_SEC):
            if stop_event.is_set():
                return
            time.sleep(1)


def state_flusher_loop() -> None:
    while not stop_event.is_set():
        try:
            flush_state(False)
        except Exception:
            pass
        time.sleep(5)


def validate_command(payload: Dict[str, Any]) -> bool:
    if not MQTT_COMMAND_TOKEN:
        return True
    return str(payload.get("token", "")).strip() == MQTT_COMMAND_TOKEN


def normalize_command(raw: str) -> str:
    original = str(raw or "").strip()
    cmd = re.sub(r"\s+", " ", original.lower())

    if cmd.startswith("play default audio - "):
        return cmd

    mapping = {
        "live stream": LIVE_LINK_COMMAND,
        "garbage detect": MANUAL_GARBAGE_COMMAND,
        "garbage sample capture": GARBAGE_SAMPLE_CAPTURE_COMMAND,

        "garbage ai mode": GARBAGE_AI_MODE_COMMAND,
        "garbage ai": GARBAGE_AI_MODE_COMMAND,
        "garbage detection ai mode": GARBAGE_AI_MODE_COMMAND,
        "garbage detection ai": GARBAGE_AI_MODE_COMMAND,
        "ai garbage mode": GARBAGE_AI_MODE_COMMAND,

        "garbage normal mode": GARBAGE_NORMAL_MODE_COMMAND,
        "garbage normal": GARBAGE_NORMAL_MODE_COMMAND,
        "garbage detection normal mode": GARBAGE_NORMAL_MODE_COMMAND,
        "garbage detection normal": GARBAGE_NORMAL_MODE_COMMAND,
        "normal garbage mode": GARBAGE_NORMAL_MODE_COMMAND,

        "audio file play": AUDIO_PLAY_COMMAND,
        "import default audio": IMPORT_DEFAULT_AUDIO_COMMAND,
        "erase default audio in pi": ERASE_DEFAULT_AUDIO_IN_PI_COMMAND,
        "data status": DATA_STATUS_COMMAND,
        "storage status": STORAGE_STATUS_COMMAND,
        "storage": STORAGE_STATUS_COMMAND,
        "storage details": STORAGE_STATUS_COMMAND,
        "sd card status": STORAGE_STATUS_COMMAND,
        "recording storage": STORAGE_STATUS_COMMAND,
        "playback": PLAYBACK_URL_COMMAND,
        "playback url": PLAYBACK_URL_COMMAND,
        "playback link": PLAYBACK_URL_COMMAND,
        "recording playback": PLAYBACK_URL_COMMAND,
        "recording playback url": PLAYBACK_URL_COMMAND,
        "software version": SOFTWARE_VERSION_COMMAND,
        "device restart": DEVICE_RESTART_COMMAND,
        "cloudflare restart": CLOUDFLARE_RESTART_COMMAND,
        "restart cloudflare": CLOUDFLARE_RESTART_COMMAND,
        "cloudflare service restart": CLOUDFLARE_RESTART_COMMAND,
        "restart cloudflare service": CLOUDFLARE_RESTART_COMMAND,
        "cloudflare tunnel restart": CLOUDFLARE_RESTART_COMMAND,
        "restart cloudflare tunnel": CLOUDFLARE_RESTART_COMMAND,
        "permanent cloudflare restart": CLOUDFLARE_RESTART_COMMAND,
        "cloudflare status": CLOUDFLARE_STATUS_COMMAND,
        "cloudflare service status": CLOUDFLARE_STATUS_COMMAND,
        "cloudflare tunnel status": CLOUDFLARE_STATUS_COMMAND,
        "camera temp url": "camera temp url",
        "camera temporary url": "camera temp url",
        "camera temp access url": "camera temp url",
        "camera temporary access url": "camera temp url",
        "temp camera url": "camera temp url",
        "temporary camera url": "camera temp url",
        "temp camera access url": "camera temp url",
        "temporary camera access url": "camera temp url",
        "camera config temp url": "camera temp url",
        "camera temporary config url": "camera temp url",
        "camera access url": "camera temp url",
        "cloudflare camera url": "camera temp url",
        "cloudflare temp camera url": "camera temp url",
        "cloudflare temporary camera url": "camera temp url",
        "cloudflare temp camera access url": "camera temp url",
        "cloudflare temporary camera access url": "camera temp url",
        "camera permanent url": "camera permanent url",
        "camera config url": "camera permanent url",
        "camera url": "camera permanent url",
        "camera live url": "camera permanent url",
        "warning audio disable": WARNING_AUDIO_DISABLE_COMMAND,
        "warning audio enable": WARNING_AUDIO_ENABLE_COMMAND,
        "person warning audio disable": PERSON_WARNING_AUDIO_DISABLE_COMMAND,
        "person warning audio enable": PERSON_WARNING_AUDIO_ENABLE_COMMAND,
        "vehicle warning audio disable": VEHICLE_WARNING_AUDIO_DISABLE_COMMAND,
        "vehicle warning audio enable": VEHICLE_WARNING_AUDIO_ENABLE_COMMAND,
        "scheduled warning audio": WARNING_AUDIO_SCHEDULE_COMMAND,
        "scheduled warning disabled": WARNING_AUDIO_SCHEDULE_DISABLE_COMMAND,
        "power saving enable": POWER_SAVING_ENABLE_COMMAND,
        "enable power saving": POWER_SAVING_ENABLE_COMMAND,
        "power saving disable": POWER_SAVING_DISABLE_COMMAND,
        "disable power saving": POWER_SAVING_DISABLE_COMMAND,
        "power saving status": POWER_SAVING_STATUS_COMMAND,
        "scheduled power saving": POWER_SAVING_SCHEDULE_COMMAND,
        "power saving schedule": POWER_SAVING_SCHEDULE_COMMAND,
        "scheduled power saving disabled": POWER_SAVING_SCHEDULE_DISABLE_COMMAND,
        "power saving schedule disabled": POWER_SAVING_SCHEDULE_DISABLE_COMMAND,

        "person detection enable": PERSON_DETECTION_ENABLE_COMMAND,
        "enable person detection": PERSON_DETECTION_ENABLE_COMMAND,
        "person detection disable": PERSON_DETECTION_DISABLE_COMMAND,
        "disable person detection": PERSON_DETECTION_DISABLE_COMMAND,

        "vehicle detection enable": VEHICLE_DETECTION_ENABLE_COMMAND,
        "enable vehicle detection": VEHICLE_DETECTION_ENABLE_COMMAND,
        "vehicle detection disable": VEHICLE_DETECTION_DISABLE_COMMAND,
        "disable vehicle detection": VEHICLE_DETECTION_DISABLE_COMMAND,

        "garbage detection enable": GARBAGE_DETECTION_ENABLE_COMMAND,
        "enable garbage detection": GARBAGE_DETECTION_ENABLE_COMMAND,
        "garbage detection disable": GARBAGE_DETECTION_DISABLE_COMMAND,
        "disable garbage detection": GARBAGE_DETECTION_DISABLE_COMMAND,

        "person video recording enable": PERSON_VIDEO_RECORDING_ENABLE_COMMAND,
        "enable person video recording": PERSON_VIDEO_RECORDING_ENABLE_COMMAND,
        "person video recording disable": PERSON_VIDEO_RECORDING_DISABLE_COMMAND,
        "disable person video recording": PERSON_VIDEO_RECORDING_DISABLE_COMMAND,

        "vehicle video recording enable": VEHICLE_VIDEO_RECORDING_ENABLE_COMMAND,
        "enable vehicle video recording": VEHICLE_VIDEO_RECORDING_ENABLE_COMMAND,
        "vehicle video recording disable": VEHICLE_VIDEO_RECORDING_DISABLE_COMMAND,
        "disable vehicle video recording": VEHICLE_VIDEO_RECORDING_DISABLE_COMMAND,

    }
    return mapping.get(cmd, cmd)


def extract_garbage_interval_sec(command_text: str) -> Optional[int]:
    text = re.sub(r"\s+", " ", str(command_text or "").strip().lower())

    m = re.match(
        r"^garbage detection set to (\d+)\s*(second|seconds|sec|secs|minute|minutes|min|mins|hour|hours|hr|hrs)$",
        text
    )
    if not m:
        return None

    value = int(m.group(1))
    unit = m.group(2)

    if value <= 0:
        return None

    if unit in {"second", "seconds", "sec", "secs"}:
        sec = value
    elif unit in {"minute", "minutes", "min", "mins"}:
        sec = value * 60
    else:
        sec = value * 3600

    return max(60, sec)


def save_garbage_interval_sec(interval_sec: int) -> None:
    global CONFIG, GARBAGE_INTERVAL_SEC

    interval_sec = max(60, int(interval_sec))
    cfg = load_config()
    cfg["garbage_interval_sec"] = interval_sec
    safe_write_json(CONFIG_FILE, cfg)

    CONFIG = cfg
    GARBAGE_INTERVAL_SEC = interval_sec

    update_state(lambda s: s["system"].update({
        "garbage_interval_sec": interval_sec
    }), force_flush=True)


def resolve_audio_remote_path(payload: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    audio_path = str(payload.get("audio_path", "")).strip()
    audio_name = str(payload.get("audio_name", "")).strip()

    if audio_path:
        base_name = Path(audio_path).name
        return audio_path, base_name

    if audio_name:
        return f"{SFTP_AUDIO_DIR.rstrip('/')}/{audio_name}", audio_name

    return None, None

def parse_clock_time(value: str) -> Optional[dt.time]:
    raw = re.sub(r"\s+", "", str(value or "").strip().upper())
    if not raw:
        return None

    for fmt in ("%I%p", "%I:%M%p", "%H:%M", "%H%M"):
        try:
            return dt.datetime.strptime(raw, fmt).time()
        except ValueError:
            continue
    return None


def extract_warning_schedule(payload: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    start_time = str(payload.get("start_time", "")).strip()
    end_time = str(payload.get("end_time", "")).strip()

    if start_time and end_time:
        return start_time, end_time

    schedule_text = str(
        payload.get("schedule", "") or
        payload.get("time_range", "") or
        payload.get("value", "")
    ).strip()

    if schedule_text:
        m = re.match(r"(.+?)\s+to\s+(.+)", schedule_text, flags=re.IGNORECASE)
        if m:
            return m.group(1).strip(), m.group(2).strip()

    return None, None


def is_current_time_in_range(start_t: dt.time, end_t: dt.time, now_t: Optional[dt.time] = None) -> bool:
    current = now_t or now_dt().time()

    if start_t <= end_t:
        return start_t <= current <= end_t

    return current >= start_t or current <= end_t


def normalize_warning_audio_target(target: str) -> str:
    normalized = str(target or "person").strip().lower()
    if normalized in {"vehicle", "car", "bike", "motorbike", "motorcycle", "truck", "bus"}:
        return "vehicle"
    return "person"


def is_warning_audio_allowed(target: str = "person") -> Tuple[bool, str]:
    warning_target = normalize_warning_audio_target(target)
    state = load_state()
    warning_cfg = state.get("warning_audio", {})

    global_enabled = bool(warning_cfg.get("enabled", True))
    target_key = f"{warning_target}_enabled"
    target_enabled = bool(warning_cfg.get(target_key, global_enabled))

    if not global_enabled:
        return False, "warning audio disabled"

    if not target_enabled:
        return False, f"{warning_target} warning audio disabled"

    if not bool(warning_cfg.get("schedule_enabled", False)):
        return True, f"{warning_target} warning audio enabled without schedule"

    start_raw = str(warning_cfg.get("start_time", "10:00"))
    end_raw = str(warning_cfg.get("end_time", "18:00"))
    start_t = parse_clock_time(start_raw)
    end_t = parse_clock_time(end_raw)

    if start_t is None or end_t is None:
        return False, "warning audio schedule invalid"

    if is_current_time_in_range(start_t, end_t):
        return True, f"{warning_target} warning audio within scheduled range {start_raw} to {end_raw}"

    return False, f"{warning_target} warning audio outside scheduled range {start_raw} to {end_raw}"


def enqueue_audio_job(job: Dict[str, Any]) -> int:
    audio_queue.put(job)
    try:
        return audio_queue.qsize()
    except NotImplementedError:
        return -1


def play_audio_file(local_source: Path) -> None:
    ext = local_source.suffix.lower()
    playable_wav = local_source

    if ext != ".wav":
        playable_wav = TMP_DIR / f"{local_source.stem}.wav"
        subprocess.check_call([
            "ffmpeg", "-y", "-i", str(local_source),
            "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
            str(playable_wav)
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    ok = play_with_aplay(playable_wav, timeout_sec=120)
    if not ok:
        raise RuntimeError(f"failed to play audio: {local_source.name}")

    if playable_wav != local_source and playable_wav.exists():
        playable_wav.unlink(missing_ok=True)


def audio_worker_loop() -> None:
    while not stop_event.is_set():
        if is_live_talk_active():
            try:
                stop_current_audio_process()
            except Exception:
                pass

            cleared_count = clear_audio_queue()
            if cleared_count > 0:
                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": None,
                        "source_path": None,
                        "time": now_str(),
                        "status": f"queue_cleared_live_talk_active ({cleared_count})"
                    }
                }))

            time.sleep(1)
            continue

        if is_power_saving_active():
            try:
                stop_current_audio_process()
            except Exception:
                pass

            cleared_count = clear_audio_queue()
            if cleared_count > 0:
                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": None,
                        "source_path": None,
                        "time": now_str(),
                        "status": f"queue_cleared_power_saving ({cleared_count})"
                    }
                }))

            time.sleep(1)
            continue

        if is_network_audio_muted():
            try:
                stop_current_audio_process()
            except Exception:
                pass

            cleared_count = clear_audio_queue()
            if cleared_count > 0:
                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": None,
                        "source_path": None,
                        "time": now_str(),
                        "status": f"queue_cleared_network_offline ({cleared_count})"
                    }
                }))

            time.sleep(1)
            continue

        try:
            job = audio_queue.get(timeout=1)
        except queue.Empty:
            continue

        if is_live_talk_active() or is_power_saving_active() or is_network_audio_muted():
            audio_queue.task_done()
            continue

        local_file: Optional[Path] = None
        cleanup_local_file = False

        try:
            job_type = str(job.get("job_type", "")).strip().lower()

            if job_type == "warning":
                wav = ASSET_DIR / "warning.wav"
                if not wav.exists():
                    raise RuntimeError(f"Missing warning file: {wav}")

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": wav.name,
                        "source_path": str(wav),
                        "time": now_str(),
                        "status": "playing_warning"
                    }
                }))

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "warning_audio_started",
                    "file": wav.name
                })

                ok = play_with_aplay(wav, timeout_sec=20)
                if not ok:
                    raise RuntimeError("warning audio play failed")

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": wav.name,
                        "source_path": str(wav),
                        "time": now_str(),
                        "status": "warning_completed"
                    }
                }))
                add_event("warning_audio", {"file": wav.name, "status": "completed"})

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "warning_audio_completed",
                    "file": wav.name
                })

            elif job_type == "file":
                remote_path = str(job["remote_path"])
                file_name = str(job["file_name"])
                local_file = AUDIO_DIR / file_name
                cleanup_local_file = True

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": file_name,
                        "source_path": remote_path,
                        "time": now_str(),
                        "status": "downloading"
                    }
                }))

                sftp_download(remote_path, local_file)

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": file_name,
                        "source_path": remote_path,
                        "time": now_str(),
                        "status": "playing"
                    }
                }))

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "audio_play_started",
                    "file": file_name,
                    "source_path": remote_path
                })

                play_audio_file(local_file)

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": file_name,
                        "source_path": remote_path,
                        "time": now_str(),
                        "status": "completed"
                    }
                }))

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "audio_play_completed",
                    "file": file_name,
                    "source_path": remote_path
                })
                add_event("audio_play", {
                    "file": file_name,
                    "source_path": remote_path,
                    "status": "completed"
                })

            elif job_type == "local_default":
                file_name = str(job["file_name"])
                local_file = Path(str(job["local_path"]))
                cleanup_local_file = False

                if not local_file.exists() or not local_file.is_file():
                    raise RuntimeError(f"default audio file not found: {local_file}")

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": file_name,
                        "source_path": str(local_file),
                        "time": now_str(),
                        "status": "playing_default_audio"
                    }
                }))

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "default_audio_play_started",
                    "file": file_name,
                    "local_path": str(local_file)
                })

                play_audio_file(local_file)

                update_state(lambda s: s.update({
                    "last_audio": {
                        "file": file_name,
                        "source_path": str(local_file),
                        "time": now_str(),
                        "status": "default_audio_completed"
                    }
                }))

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "default_audio_play_completed",
                    "file": file_name,
                    "local_path": str(local_file)
                })

                add_event("default_audio_play", {
                    "file": file_name,
                    "local_path": str(local_file),
                    "status": "completed"
                })

            else:
                raise RuntimeError(f"unknown audio job type: {job_type}")

        except Exception as exc:
            update_state(lambda s: s.update({
                "last_audio": {
                    "file": job.get("file_name"),
                    "source_path": job.get("remote_path") or job.get("local_path"),
                    "time": now_str(),
                    "status": f"failed: {exc}"
                }
            }))

            event_name = "warning_audio_failed"
            if str(job.get("job_type", "")).lower() == "file":
                event_name = "audio_play_failed"
            elif str(job.get("job_type", "")).lower() == "local_default":
                event_name = "default_audio_play_failed"

            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": event_name,
                "file": job.get("file_name"),
                "source_path": job.get("remote_path") or job.get("local_path"),
                "message": str(exc)
            })
        finally:
            try:
                if cleanup_local_file and local_file and local_file.exists():
                    local_file.unlink(missing_ok=True)
            except Exception:
                pass
            audio_queue.task_done()


def handle_audio_play(payload: Dict[str, Any]) -> None:
    remote_path, file_name = resolve_audio_remote_path(payload)
    if not remote_path or not file_name:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "audio_play_failed",
            "message": "audio_name or audio_path required"
        })
        return

    queue_size = enqueue_audio_job({
        "job_type": "file",
        "remote_path": remote_path,
        "file_name": file_name,
        "requested_at": now_str()
    })

    update_state(lambda s: s.update({
        "last_audio": {
            "file": file_name,
            "source_path": remote_path,
            "time": now_str(),
            "status": f"queued ({queue_size})"
        }
    }))

    mqtt_publish(MQTT_RESPONSE_TOPIC, {
        "device_id": DEVICE_ID,
        "event": "audio_play_queued",
        "file": file_name,
        "source_path": remote_path,
        "queue_size": queue_size
    })

    add_event("audio_play_queued", {
        "file": file_name,
        "source_path": remote_path,
        "queue_size": queue_size
    })

def is_allowed_audio_file(file_name: str) -> bool:
    ext = Path(file_name).suffix.lower()
    return ext in {".mp3", ".wav", ".aac", ".m4a", ".flac", ".ogg"}


def list_sftp_files(remote_dir: str) -> List[str]:
    transport = None
    sftp = None
    try:
        transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
        transport.connect(username=SFTP_USERNAME, password=SFTP_PASSWORD)
        sftp = paramiko.SFTPClient.from_transport(transport)

        names: List[str] = []
        for entry in sftp.listdir_attr(remote_dir):
            if not is_allowed_audio_file(entry.filename):
                continue
            names.append(entry.filename)

        names.sort()
        update_state(lambda s: s["system"].update({
            "sftp_last_ok": now_str(),
            "sftp_last_error": None
        }))
        return names

    except Exception as exc:
        update_state(lambda s: s["system"].update({
            "sftp_last_error": str(exc)
        }))
        raise
    finally:
        try:
            if sftp:
                sftp.close()
        except Exception:
            pass
        try:
            if transport:
                transport.close()
        except Exception:
            pass


def import_default_audio_to_pi() -> None:
    DEFAULT_AUDIO_DIR.mkdir(parents=True, exist_ok=True)

    try:
        remote_files = list_sftp_files(SFTP_DEFAULT_AUDIO_DIR)
        if not remote_files:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "default_audio_import_completed",
                "imported_count": 0,
                "files": [],
                "message": f"No audio files found in {SFTP_DEFAULT_AUDIO_DIR}"
            })
            add_event("default_audio_import_completed", {
                "imported_count": 0,
                "files": []
            })
            return

        imported_files: List[str] = []
        skipped_files: List[str] = []

        for file_name in remote_files:
            remote_path = f"{SFTP_DEFAULT_AUDIO_DIR.rstrip('/')}/{file_name}"
            local_path = DEFAULT_AUDIO_DIR / file_name

            if local_path.exists() and local_path.is_file():
                skipped_files.append(file_name)
                continue

            sftp_download(remote_path, local_path)
            imported_files.append(file_name)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "default_audio_import_completed",
            "imported_count": len(imported_files),
            "skipped_count": len(skipped_files),
            "imported_files": imported_files,
            "skipped_files": skipped_files,
            "message": "Default audio imported to PI successfully"
        })

        add_event("default_audio_import_completed", {
            "imported_count": len(imported_files),
            "skipped_count": len(skipped_files),
            "imported_files": imported_files,
            "skipped_files": skipped_files
        })

    except Exception as exc:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "default_audio_import_failed",
            "message": str(exc)
        })
        add_event("default_audio_import_failed", {
            "message": str(exc)
        })


def erase_default_audio_in_pi() -> None:
    DEFAULT_AUDIO_DIR.mkdir(parents=True, exist_ok=True)

    deleted_files: List[str] = []
    failed_files: List[str] = []

    for path in sorted(DEFAULT_AUDIO_DIR.iterdir()):
        if not path.is_file():
            continue
        if not is_allowed_audio_file(path.name):
            continue

        try:
            path.unlink()
            deleted_files.append(path.name)
        except Exception:
            failed_files.append(path.name)

    mqtt_publish(MQTT_RESPONSE_TOPIC, {
        "device_id": DEVICE_ID,
        "event": "default_audio_erase_completed",
        "deleted_count": len(deleted_files),
        "failed_count": len(failed_files),
        "deleted_files": deleted_files,
        "failed_files": failed_files,
        "message": "Default audio files erased from PI"
    })

    add_event("default_audio_erase_completed", {
        "deleted_count": len(deleted_files),
        "failed_count": len(failed_files),
        "deleted_files": deleted_files,
        "failed_files": failed_files
    })


def extract_default_audio_name(command_text: str) -> str:
    raw = str(command_text or "").strip()
    lower_raw = raw.lower()
    if not lower_raw.startswith(PLAY_DEFAULT_AUDIO_COMMAND_PREFIX):
        return ""
    file_name = raw[len("Play Default Audio - "):].strip()
    return Path(file_name).name.strip()


def handle_play_default_audio(payload: Dict[str, Any]) -> None:
    command_text = str(payload.get("command", "")).strip()
    file_name = extract_default_audio_name(command_text)

    if not file_name:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "default_audio_play_failed",
            "message": "Command format: Play Default Audio - Alert_Aud-1.mp3"
        })
        return

    if not is_allowed_audio_file(file_name):
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "default_audio_play_failed",
            "file": file_name,
            "message": "Unsupported audio file extension"
        })
        return

    local_file = DEFAULT_AUDIO_DIR / file_name
    if not local_file.exists() or not local_file.is_file():
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "default_audio_play_failed",
            "file": file_name,
            "message": "File not found in PI default audio folder. Run 'Import Default Audio' first."
        })
        return

    queue_size = enqueue_audio_job({
        "job_type": "local_default",
        "local_path": str(local_file),
        "file_name": file_name,
        "requested_at": now_str()
    })

    update_state(lambda s: s.update({
        "last_audio": {
            "file": file_name,
            "source_path": str(local_file),
            "time": now_str(),
            "status": f"default_audio_queued ({queue_size})"
        }
    }))

    mqtt_publish(MQTT_RESPONSE_TOPIC, {
        "device_id": DEVICE_ID,
        "event": "default_audio_play_queued",
        "file": file_name,
        "local_path": str(local_file),
        "queue_size": queue_size
    })

    add_event("default_audio_play_queued", {
        "file": file_name,
        "local_path": str(local_file),
        "queue_size": queue_size
    })


def delayed_reboot() -> None:
    requested_at = now_str()

    update_state(
        lambda state: state.setdefault("system", {}).update({
            "last_restart_request_at": requested_at,
            "last_restart_status": "requested"
        }),
        force_flush=True
    )

    time.sleep(2)

    try:
        flush_state(True)
    except Exception:
        pass

    try:
        stop_live_tunnel()
    except Exception:
        pass

    try:
        result = subprocess.run(
            [
                "sudo",
                "-n",
                "/usr/local/bin/gcam-force-reboot.sh"
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            timeout=15
        )

        if result.returncode != 0:
            error_message = (
                result.stderr.strip()
                or f"Reboot helper returned exit code {result.returncode}"
            )

            raise RuntimeError(error_message)

        update_state(
            lambda state: state.setdefault("system", {}).update({
                "last_restart_status": "reboot_command_accepted"
            }),
            force_flush=True
        )

    except Exception as exc:
        error_message = str(exc)

        update_state(
            lambda state: state.setdefault("system", {}).update({
                "last_restart_status": "failed",
                "last_restart_error": error_message
            }),
            force_flush=True
        )

        try:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "device_restart_failed",
                "message": error_message,
                "time": now_str()
            })
        except Exception:
            pass

        try:
            add_event("device_restart_failed", {
                "message": error_message,
                "time": now_str()
            })
        except Exception:
            pass

        raise


router_reboot_gpio_initialized = False


def run_pinctrl_set(level: int) -> None:
    # active-low setup:
    # level 1 => drive HIGH
    # level 0 => drive LOW
    drive = "dh" if level == 1 else "dl"

    result = subprocess.run(
        [
            "pinctrl",
            "set",
            str(ROUTER_REBOOT_GPIO),
            "op",
            drive,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"pinctrl failed for GPIO {ROUTER_REBOOT_GPIO}="
            f"{level}: {result.stderr.strip()}"
        )


def init_router_reboot_gpio() -> None:
    global router_reboot_gpio_initialized

    # Put GPIO in known idle state at startup
    run_pinctrl_set(ROUTER_REBOOT_INACTIVE_VALUE)
    router_reboot_gpio_initialized = True


def pulse_router_reboot_gpio() -> None:
    if not router_reboot_gpio_initialized:
        init_router_reboot_gpio()

    # Ensure idle state first
    run_pinctrl_set(ROUTER_REBOOT_INACTIVE_VALUE)
    time.sleep(0.2)

    # Stage 1
    run_pinctrl_set(ROUTER_REBOOT_ACTIVE_VALUE)
    time.sleep(ROUTER_REBOOT_PULSE_SEC)
    run_pinctrl_set(ROUTER_REBOOT_INACTIVE_VALUE)

    # Gap between stage 1 and stage 2
    time.sleep(ROUTER_REBOOT_STAGE_GAP_SEC)

    # Stage 2
    run_pinctrl_set(ROUTER_REBOOT_ACTIVE_VALUE)
    time.sleep(ROUTER_REBOOT_PULSE_SEC)
    run_pinctrl_set(ROUTER_REBOOT_INACTIVE_VALUE)

def trigger_router_reboot_gpio(triggered_by: str) -> bool:
    if not router_reboot_lock.acquire(blocking=False):
        try:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "router_reboot_trigger_skipped",
                "triggered_by": triggered_by,
                "message": "GPIO trigger already in progress"
            })
        except Exception:
            pass
        return False

    try:
        init_router_reboot_gpio()

        try:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "router_reboot_trigger_started",
                "triggered_by": triggered_by,
                "gpio": ROUTER_REBOOT_GPIO,
                "duration_sec": ROUTER_REBOOT_PULSE_SEC,
                "time": now_str()
            })
        except Exception:
            pass

        pulse_router_reboot_gpio()

        try:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "router_reboot_trigger_completed",
                "triggered_by": triggered_by,
                "gpio": ROUTER_REBOOT_GPIO,
                "duration_sec": ROUTER_REBOOT_PULSE_SEC,
                "time": now_str()
            })
        except Exception:
            pass

        try:
            add_event("router_reboot_triggered", {
                "triggered_by": triggered_by,
                "gpio": ROUTER_REBOOT_GPIO,
                "duration_sec": ROUTER_REBOOT_PULSE_SEC
            })
        except Exception:
            pass

        return True

    except Exception as exc:
        try:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "router_reboot_trigger_failed",
                "triggered_by": triggered_by,
                "message": str(exc),
                "time": now_str()
            })
        except Exception:
            pass
        return False

    finally:
        router_reboot_lock.release()


def trigger_router_reboot_async(triggered_by: str) -> None:
    threading.Thread(
        target=trigger_router_reboot_gpio,
        args=(triggered_by,),
        daemon=True
    ).start()


def router_reboot_schedule_loop() -> None:
    global last_router_reboot_schedule_key

    while not stop_event.is_set():
        now = dt.datetime.now()
        hhmm = now.strftime("%H:%M")
        schedule_key = now.strftime("%Y-%m-%d %H:%M")

        if hhmm in ROUTER_REBOOT_SCHEDULE_TIMES and last_router_reboot_schedule_key != schedule_key:
            last_router_reboot_schedule_key = schedule_key
            trigger_router_reboot_async(triggered_by=f"schedule_{hhmm}")

        time.sleep(1)


def power_saving_schedule_loop() -> None:
    while not stop_event.is_set():
        try:
            state = load_state()
            ps = state.get("power_saving", {})

            if not bool(ps.get("schedule_enabled", False)):
                time.sleep(POWER_SAVING_SCHEDULE_CHECK_SEC)
                continue

            start_t = parse_clock_time(str(ps.get("start_time", "22:00")))
            end_t = parse_clock_time(str(ps.get("end_time", "06:00")))

            if start_t is None or end_t is None:
                update_state(lambda s: s["system"].update({
                    "last_error": "Invalid power saving schedule time"
                }))
                time.sleep(POWER_SAVING_SCHEDULE_CHECK_SEC)
                continue

            now_time = dt.datetime.now().time().replace(second=0, microsecond=0)
            should_be_active = is_time_inside_range(now_time, start_t, end_t)

            currently_active = bool(ps.get("enabled", False))
            current_source = ps.get("source")

            update_state(lambda s: s["power_saving"].update({
                "last_schedule_check": now_str()
            }), force_flush=True)

            if should_be_active and not currently_active:
                status = set_power_saving_enabled(
                    enabled=True,
                    reason=f"scheduled power saving active from {start_t.strftime('%H:%M')} to {end_t.strftime('%H:%M')}",
                    source="schedule"
                )

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "power_saving_schedule_started",
                    "message": "Scheduled power saving mode started.",
                    **status
                })

            elif (not should_be_active) and currently_active and current_source == "schedule":
                status = set_power_saving_enabled(
                    enabled=False,
                    reason="scheduled power saving window ended",
                    source="schedule"
                )

                mqtt_publish(MQTT_RESPONSE_TOPIC, {
                    "device_id": DEVICE_ID,
                    "event": "power_saving_schedule_ended",
                    "message": "Scheduled power saving mode ended. Normal functions resumed.",
                    **status
                })

        except Exception as exc:
            update_state(lambda s: s["system"].update({
                "last_error": f"Power saving schedule loop error: {exc}"
            }))

        time.sleep(POWER_SAVING_SCHEDULE_CHECK_SEC)


def handle_command(payload: Dict[str, Any]) -> None:
    if not validate_command(payload):
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "command_rejected",
            "message": "Invalid token"
        })
        return

    raw_command = str(payload.get("command", "")).strip()
    cmd = normalize_command(raw_command)

    removed_commands = {
        MANUAL_GARBAGE_COMMAND,
        GARBAGE_SAMPLE_CAPTURE_COMMAND,
        GARBAGE_AI_MODE_COMMAND,
        GARBAGE_NORMAL_MODE_COMMAND,
        GARBAGE_DETECTION_ENABLE_COMMAND,
        GARBAGE_DETECTION_DISABLE_COMMAND,
        AUDIO_PLAY_COMMAND,
        IMPORT_DEFAULT_AUDIO_COMMAND,
        ERASE_DEFAULT_AUDIO_IN_PI_COMMAND,
    }
    if cmd in removed_commands or str(raw_command).strip().lower().startswith(PLAY_DEFAULT_AUDIO_COMMAND_PREFIX):
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "command_removed",
            "command": raw_command,
            "message": "Garbage detection and live/upload audio are removed in this Person + Vehicle only build",
            "time": now_str(),
        })
        return

    if cmd == POWER_SAVING_ENABLE_COMMAND:
        status = set_power_saving_enabled(
            enabled=True,
            reason="enabled by mqtt command",
            source="manual"
        )
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "power_saving_enabled",
            "message": "Power saving mode enabled. Camera, detection, live stream, audio and uploads are paused.",
            **status
        })
        return

    if cmd == POWER_SAVING_DISABLE_COMMAND:
        status = set_power_saving_enabled(
            enabled=False,
            reason="disabled by mqtt command",
            source="manual",
            disable_schedule=True
        )
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "power_saving_disabled",
            "message": "Power saving mode disabled. Normal camera and detection functions will resume.",
            **status
        })
        return

    if cmd == POWER_SAVING_STATUS_COMMAND:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "power_saving_status",
            **power_saving_status_payload(),
            "time": now_str()
        })
        return

    if cmd == POWER_SAVING_SCHEDULE_DISABLE_COMMAND:
        previous = load_state().get("power_saving", {})
        was_schedule_active = bool(previous.get("enabled", False)) and previous.get("source") == "schedule"

        def mutate(state):
            state.setdefault("power_saving", default_state()["power_saving"])
            state["power_saving"]["schedule_enabled"] = False
            state["power_saving"]["last_schedule_check"] = now_str()

        update_state(mutate, force_flush=True)

        if was_schedule_active:
            status = set_power_saving_enabled(
                enabled=False,
                reason="scheduled power saving disabled by mqtt command",
                source="manual"
            )
        else:
            status = power_saving_status_payload()

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "power_saving_schedule_disabled",
            "message": "Scheduled power saving disabled successfully.",
            **status
        })
        add_event("power_saving_schedule_disabled", {})
        return

    if cmd == POWER_SAVING_SCHEDULE_COMMAND:
        start_raw, end_raw = parse_power_saving_schedule(payload)
        start_t = parse_clock_time(start_raw or "")
        end_t = parse_clock_time(end_raw or "")

        if start_t is None or end_t is None:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "power_saving_schedule_failed",
                "message": "start_time and end_time are required. Example: 10PM / 6AM or 22:00 / 06:00"
            })
            return

        normalized_start = start_t.strftime("%H:%M")
        normalized_end = end_t.strftime("%H:%M")

        def mutate(state):
            state.setdefault("power_saving", default_state()["power_saving"])
            state["power_saving"]["schedule_enabled"] = True
            state["power_saving"]["start_time"] = normalized_start
            state["power_saving"]["end_time"] = normalized_end
            state["power_saving"]["last_schedule_check"] = now_str()

        update_state(mutate, force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "power_saving_schedule_updated",
            "start_time": normalized_start,
            "end_time": normalized_end,
            "message": f"Power saving scheduled from {normalized_start} to {normalized_end}",
            **power_saving_status_payload()
        })
        add_event("power_saving_schedule_updated", {
            "start_time": normalized_start,
            "end_time": normalized_end
        })
        return

    if is_power_saving_active() and not power_saving_command_allowed(cmd):
        mqtt_publish(MQTT_RESPONSE_TOPIC, build_power_saving_blocked_response(cmd))
        return

    if cmd in GARBAGE_MODE_COMMANDS:
        mode = "ai" if cmd == GARBAGE_AI_MODE_COMMAND else "normal"
        status = set_garbage_detection_mode(mode, source="mqtt command")

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "garbage_detection_mode_changed",
            "command": raw_command,
            "garbage_detection_mode": status["garbage_detection_mode"],
            "garbage_detection_mode_label": status["garbage_detection_mode_label"],
            "message": f"Garbage detection mode changed to {status['garbage_detection_mode_label']}",
            "time": now_str(),
        })
        return

    feature_command_map = {
        PERSON_DETECTION_ENABLE_COMMAND: ("person_detection_enabled", True, "person_detection_enabled"),
        PERSON_DETECTION_DISABLE_COMMAND: ("person_detection_enabled", False, "person_detection_disabled"),

        VEHICLE_DETECTION_ENABLE_COMMAND: ("vehicle_detection_enabled", True, "vehicle_detection_enabled"),
        VEHICLE_DETECTION_DISABLE_COMMAND: ("vehicle_detection_enabled", False, "vehicle_detection_disabled"),

        GARBAGE_DETECTION_ENABLE_COMMAND: ("garbage_detection_enabled", True, "garbage_detection_enabled"),
        GARBAGE_DETECTION_DISABLE_COMMAND: ("garbage_detection_enabled", False, "garbage_detection_disabled"),

        PERSON_VIDEO_RECORDING_ENABLE_COMMAND: ("person_video_recording_enabled", True, "person_video_recording_enabled"),
        PERSON_VIDEO_RECORDING_DISABLE_COMMAND: ("person_video_recording_enabled", False, "person_video_recording_disabled"),

        VEHICLE_VIDEO_RECORDING_ENABLE_COMMAND: ("vehicle_video_recording_enabled", True, "vehicle_video_recording_enabled"),
        VEHICLE_VIDEO_RECORDING_DISABLE_COMMAND: ("vehicle_video_recording_enabled", False, "vehicle_video_recording_disabled"),

    }

    if cmd in feature_command_map:
        flag_name, enabled, event_name = feature_command_map[cmd]
        flags = set_feature_flag(flag_name, enabled, source="mqtt command")

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": event_name,
            "command": raw_command,
            "flag": flag_name,
            "enabled": bool(enabled),
            "status": "enabled" if enabled else "disabled",
            "message": f"{flag_name} set to {'enabled' if enabled else 'disabled'}",
            "feature_flags": flags,
            "time": now_str(),
        })
        return

    if cmd == LIVE_LINK_COMMAND:
        live_payload = build_live_links_payload(force_new=True)
        mqtt_publish(MQTT_RESPONSE_TOPIC, {"device_id": DEVICE_ID, "event": "live_link_created", **live_payload})
        add_event("live_link_created", live_payload)
        return

    if cmd == MANUAL_GARBAGE_COMMAND:
        if not is_feature_enabled("garbage_detection_enabled"):
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "manual_garbage_blocked",
                "status": "disabled",
                "message": "Garbage detection is disabled by MQTT command",
                **feature_flags_payload(),
                "time": now_str(),
            })
            return

        result, error = run_garbage_detection_guarded(
            triggered_by="manual",
            create_live_link=True,
            wait_for_frame_sec=8.0,
            wait_for_lock_sec=20.0
        )

        if result is not None:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "manual_garbage_detected",
                **result
            })
        else:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "manual_garbage_failed",
                "message": error or "No frame available",
                "time": now_str()
            })
        return

    if cmd == GARBAGE_SAMPLE_CAPTURE_COMMAND:
        try:
            capture_result = capture_garbage_reference_from_live()
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "garbage_sample_captured",
                **capture_result
            })
        except Exception as exc:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "garbage_sample_capture_failed",
                "message": str(exc)
            })
        return

    garbage_interval_sec = extract_garbage_interval_sec(raw_command)
    if garbage_interval_sec is not None:
        save_garbage_interval_sec(garbage_interval_sec)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "garbage_interval_updated",
            "garbage_interval_sec": garbage_interval_sec,
            "garbage_interval_minutes": round(garbage_interval_sec / 60, 2),
            "garbage_interval_hours": round(garbage_interval_sec / 3600, 2),
            "message": f"Scheduled garbage detection set to {garbage_interval_sec} seconds"
        })
        add_event("garbage_interval_updated", {
            "garbage_interval_sec": garbage_interval_sec
        })
        return

    if cmd == AUDIO_PLAY_COMMAND:
        handle_audio_play(payload)
        return

    if cmd == IMPORT_DEFAULT_AUDIO_COMMAND:
        import_default_audio_to_pi()
        return

    if cmd == ERASE_DEFAULT_AUDIO_IN_PI_COMMAND:
        erase_default_audio_in_pi()
        return

    if cmd == QUEUE_CLEAR_COMMAND:
        stop_current_audio_process()
        cleared_count = clear_audio_queue()

        update_state(lambda s: s.update({
            "last_audio": {
                "file": None,
                "source_path": None,
                "time": now_str(),
                "status": f"queue_cleared ({cleared_count})"
            }
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "queue_cleared",
            "cleared_count": cleared_count,
            "message": "Audio queue cleared successfully"
        })

        add_event("queue_cleared", {
            "cleared_count": cleared_count
        })
        return

    if str(raw_command).strip().lower().startswith(PLAY_DEFAULT_AUDIO_COMMAND_PREFIX):
        handle_play_default_audio(payload)
        return

    if cmd == CURRENT_VOLUME_COMMAND:
        handle_current_pi_volume_command(payload)
        return

    if extract_volume_percent(raw_command) is not None:
        handle_pi_volume_command(payload)
        return

    if cmd == WARNING_AUDIO_DISABLE_COMMAND:
        update_state(lambda s: s["warning_audio"].update({
            "enabled": False,
            "person_enabled": False,
            "vehicle_enabled": False,
            "last_status": "person and vehicle warning audio disabled by mqtt command",
            "last_person_status": "disabled by mqtt command",
            "last_vehicle_status": "disabled by mqtt command"
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "warning_audio_disabled",
            "targets": ["person", "vehicle"],
            "message": "Person and vehicle warning audio disabled successfully"
        })
        add_event("warning_audio_disabled", {"targets": ["person", "vehicle"]})
        return

    if cmd == WARNING_AUDIO_ENABLE_COMMAND:
        update_state(lambda s: s["warning_audio"].update({
            "enabled": True,
            "person_enabled": True,
            "vehicle_enabled": True,
            "schedule_enabled": False,
            "last_status": "person and vehicle warning audio enabled for 24 hours by mqtt command",
            "last_person_status": "enabled by mqtt command",
            "last_vehicle_status": "enabled by mqtt command"
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "warning_audio_enabled",
            "targets": ["person", "vehicle"],
            "message": "Person and vehicle warning audio enabled successfully in 24 hours mode"
        })
        add_event("warning_audio_enabled", {"targets": ["person", "vehicle"], "schedule_enabled": False})
        return

    separate_warning_command_map = {
        PERSON_WARNING_AUDIO_DISABLE_COMMAND: ("person", False, "person_warning_audio_disabled"),
        PERSON_WARNING_AUDIO_ENABLE_COMMAND: ("person", True, "person_warning_audio_enabled"),
        VEHICLE_WARNING_AUDIO_DISABLE_COMMAND: ("vehicle", False, "vehicle_warning_audio_disabled"),
        VEHICLE_WARNING_AUDIO_ENABLE_COMMAND: ("vehicle", True, "vehicle_warning_audio_enabled"),
    }

    if cmd in separate_warning_command_map:
        target_name, target_enabled, event_name = separate_warning_command_map[cmd]
        target_key = f"{target_name}_enabled"
        status_key = f"last_{target_name}_status"
        status = f"{target_name} warning audio {'enabled' if target_enabled else 'disabled'} by mqtt command"

        def mutate_warning_target(state):
            warning_cfg = state.setdefault("warning_audio", {})
            warning_cfg.setdefault("enabled", True)
            warning_cfg[target_key] = bool(target_enabled)
            warning_cfg[status_key] = status
            warning_cfg["last_status"] = status

            if target_enabled:
                warning_cfg["enabled"] = True
                warning_cfg["schedule_enabled"] = False

        update_state(mutate_warning_target, force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": event_name,
            "target": target_name,
            "enabled": bool(target_enabled),
            "message": status.capitalize()
        })
        add_event(event_name, {"target": target_name, "enabled": bool(target_enabled)})
        return

    if cmd == WARNING_AUDIO_SCHEDULE_DISABLE_COMMAND:
        update_state(lambda s: s["warning_audio"].update({
            "enabled": True,
            "person_enabled": True,
            "vehicle_enabled": True,
            "schedule_enabled": False,
            "last_status": "schedule disabled, person and vehicle warning audio set to 24 hours mode",
            "last_person_status": "schedule disabled, enabled 24 hours",
            "last_vehicle_status": "schedule disabled, enabled 24 hours"
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "warning_audio_schedule_disabled",
            "message": "Scheduled warning disabled successfully. Warning audio is now active for 24 hours"
        })
        add_event("warning_audio_schedule_disabled", {"schedule_enabled": False})
        return

    if cmd == WARNING_AUDIO_SCHEDULE_COMMAND:
        start_raw, end_raw = extract_warning_schedule(payload)
        start_t = parse_clock_time(start_raw or "")
        end_t = parse_clock_time(end_raw or "")

        if start_t is None or end_t is None:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "warning_audio_schedule_failed",
                "message": "start_time and end_time are required. Example: 10AM / 6PM or 10:00 / 18:00"
            })
            return

        normalized_start = start_t.strftime("%H:%M")
        normalized_end = end_t.strftime("%H:%M")

        update_state(lambda s: s["warning_audio"].update({
            "enabled": True,
            "person_enabled": True,
            "vehicle_enabled": True,
            "schedule_enabled": True,
            "start_time": normalized_start,
            "end_time": normalized_end,
            "last_status": f"person and vehicle scheduled {normalized_start} to {normalized_end}",
            "last_person_status": f"scheduled {normalized_start} to {normalized_end}",
            "last_vehicle_status": f"scheduled {normalized_start} to {normalized_end}"
        }), force_flush=True)

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "warning_audio_schedule_updated",
            "start_time": normalized_start,
            "end_time": normalized_end,
            "message": f"Warning audio scheduled from {normalized_start} to {normalized_end}"
        })
        add_event("warning_audio_schedule_updated", {
            "start_time": normalized_start,
            "end_time": normalized_end
        })
        return

    if cmd == PLAYBACK_URL_COMMAND:
        start_at, parse_error = parse_mqtt_playback_start(payload)
        if start_at is None:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "playback_url_failed",
                "message": parse_error or "Invalid playback start date/time.",
                "time": now_str(),
            })
            return

        result, playback_error = build_start_to_live_playback_url(start_at)
        if result is None:
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "playback_url_failed",
                "start_datetime": start_at.strftime("%Y-%m-%d %H:%M:%S"),
                "message": playback_error or "Playback is not available for the requested start time.",
                "time": now_str(),
            })
            return

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "playback_url",
            **result,
            "message": "Open playback_url to play from the requested start time and continue following each newly completed clip at the live edge.",
            "time": now_str(),
        })
        add_event("playback_url_requested", {
            "start_datetime": result.get("start_datetime"),
            "latest_completed_end": result.get("latest_completed_end"),
            "mode": result.get("mode"),
        })
        return

    if cmd == STORAGE_STATUS_COMMAND:
        status = collect_storage_status()
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "storage_status",
            **status
        })
        add_event("storage_status_requested", {
            "sd_free_gb": status.get("sd_free_gb"),
            "recordings_used_gb": status.get("recordings_used_gb"),
            "available_recording_gb": status.get("available_recording_gb"),
            "estimated_remaining_hours": status.get("estimated_remaining_hours"),
            "estimated_capacity_hours": status.get("estimated_capacity_hours")
        })
        return

    if cmd == DATA_STATUS_COMMAND:
        status = collect_device_status(include_cloudflare_server_check=True)
        mqtt_publish(MQTT_RESPONSE_TOPIC, {"device_id": DEVICE_ID, "event": "data_status", **status})
        add_event("data_status_requested", {
            "network_status": status["network_status"],
            "ram_percent": status["ram_percent"],
            "software_version": status["software_version"],
            "power_saving_enabled": status.get("power_saving_enabled"),
            "cloudflare_server_response_code": status.get("cloudflare_server_response_code"),
            "cloudflare_server_status": status.get("cloudflare_server_status")
        })
        return

    if cmd == SOFTWARE_VERSION_COMMAND:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "software_version",
            "software_version": SOFTWARE_VERSION,
            "software_features": SOFTWARE_FEATURES,
            "time": now_str()
        })
        add_event("software_version_requested", {
            "software_version": SOFTWARE_VERSION
        })
        return

    if cmd == ROUTER_REBOOT_COMMAND:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "router_reboot_trigger_started",
            "triggered_by": "manual_mqtt",
            "gpio": ROUTER_REBOOT_GPIO,
            "duration_sec": ROUTER_REBOOT_PULSE_SEC,
            "time": now_str()
        })
        trigger_router_reboot_async(triggered_by="manual_mqtt")
        return

    if cmd == DEVICE_RESTART_COMMAND:
        if not device_restart_lock.acquire(blocking=False):
            mqtt_publish(MQTT_RESPONSE_TOPIC, {
                "device_id": DEVICE_ID,
                "event": "device_restart_ignored",
                "message": "A device restart is already in progress.",
                "time": now_str()
            })
            return

        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "device_restart_started",
            "time": now_str()
        })
        add_event("device_restart_requested", {"source": "mqtt"})

        def run_mqtt_restart() -> None:
            try:
                delayed_reboot()
            finally:
                try:
                    device_restart_lock.release()
                except RuntimeError:
                    pass

        threading.Thread(
            target=run_mqtt_restart,
            daemon=True,
            name="mqtt-device-restart"
        ).start()
        return

    if cmd in {
        "close the software",
        "open the software",
        "camera permanent url",
        "camera temp url",
        CLOUDFLARE_RESTART_COMMAND,
        CLOUDFLARE_STATUS_COMMAND,
    }:
        mqtt_publish(MQTT_RESPONSE_TOPIC, {
            "device_id": DEVICE_ID,
            "event": "command_forwarded_to_controller",
            "message": cmd
        })
        return

    mqtt_publish(MQTT_RESPONSE_TOPIC, {"device_id": DEVICE_ID, "event": "unknown_command", "message": cmd})


def mqtt_command_loop() -> None:
    def on_connect(client, userdata, flags, reason_code, properties=None):
        client.subscribe(MQTT_COMMAND_TOPIC, qos=1)
        update_state(lambda s: s["system"].update({"command_listener": True}))

    def on_message(client, userdata, msg):
        try:
            # A retained command is replayed every time the Pi reconnects to MQTT.
            # Never execute retained commands, especially "Device Restart".
            if bool(getattr(msg, "retain", False)):
                print(
                    f"Ignored retained MQTT command on {msg.topic}; clearing stale retained payload.",
                    flush=True
                )
                try:
                    client.publish(msg.topic, payload=b"", qos=1, retain=True)
                except Exception as clear_exc:
                    print(f"Failed to clear retained MQTT command: {clear_exc}", flush=True)
                return

            raw = msg.payload.decode("utf-8", errors="ignore").strip()
            if not raw:
                return

            payload = json.loads(raw) if raw.startswith("{") else {"command": raw}
            handle_command(payload)
        except Exception as exc:
            print(f"MQTT command processing failed: {exc}", flush=True)

    while not stop_event.is_set():
        client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"{DEVICE_ID}-app"
        )
        client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
        client.on_connect = on_connect
        client.on_message = on_message

        try:
            client.connect(MQTT_HOST, MQTT_PORT, 20)
            client.loop_start()

            while not stop_event.is_set():
                time.sleep(1)

        except Exception as exc:
            update_state(lambda s: s["system"].update({"command_listener": False, "mqtt_last_error": str(exc)}))
        finally:
            try:
                client.loop_stop()
            except Exception:
                pass
            try:
                client.disconnect()
            except Exception:
                pass

        time.sleep(5)


def mjpeg_stream(
    frame_width: int = LIVE_FRAME_WIDTH,
    jpeg_quality: int = MJPEG_QUALITY,
    target_fps: float = LIVE_STREAM_TARGET_FPS
):
    min_gap = 1.0 / max(float(target_fps), 1.0)

    while not stop_event.is_set():
        loop_started = time.time()

        if is_power_saving_active():
            time.sleep(1)
            continue

        # Dashboard live frame.
        # Detection still uses get_frame_copy_with_ts(), not this frame.
        # Public Cloudflare streaming uses the same shared SUB-stream frame
        # instead of opening another RTSP connection per viewer.
        frame = get_live_frame_copy()
        if frame is None:
            time.sleep(0.2)
            continue

        frame = resize_frame_to_width(frame, frame_width)

        ok, jpg = cv2.imencode(
            ".jpg",
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)]
        )

        if ok:
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n"
                b"Cache-Control: no-cache, no-store, must-revalidate\r\n"
                b"Pragma: no-cache\r\n"
                b"Expires: 0\r\n"
                b"X-Accel-Buffering: no\r\n\r\n" + jpg.tobytes() + b"\r\n"
            )

        elapsed = time.time() - loop_started
        sleep_left = min_gap - elapsed
        if sleep_left > 0:
            time.sleep(sleep_left)


def make_mjpeg_response(generator):
    response = Response(
        generator,
        mimetype="multipart/x-mixed-replace; boundary=frame",
        direct_passthrough=True,
    )
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    response.headers["X-Accel-Buffering"] = "no"
    return response


def find_latest_local_person_image() -> Optional[Path]:
    try:
        patterns = [f"{DEVICE_ID}_Person_*.jpg", "*_Person_*.jpg"]
        latest: Optional[Path] = None
        latest_mtime = 0.0

        for pattern in patterns:
            for path in FILES_DIR.glob(pattern):
                try:
                    if (
                        path.is_file() and
                        path.stat().st_size > 1024 and
                        path.stat().st_mtime > latest_mtime
                    ):
                        latest = path
                        latest_mtime = path.stat().st_mtime
                except Exception:
                    continue

        return latest
    except Exception:
        return None


def repair_last_person_media_state() -> None:
    try:
        state = load_state()
        person = state.get("last_person", {}) or {}
        image_name = str(person.get("image") or person.get("image_file") or "").strip()

        if image_name and not image_name.startswith("/") and not image_name.startswith("garbage/"):
            image_path = FILES_DIR / image_name
            if image_path.exists() and image_path.stat().st_size > 1024:
                if not person.get("image") or not person.get("image_file"):
                    update_state(lambda s: s.setdefault("last_person", {}).update({
                        "image": image_name,
                        "image_file": image_name,
                    }))
                return

        latest = find_latest_local_person_image()
        if latest is None:
            return

        rel_name = latest.name

        def mut(state_obj):
            p = state_obj.setdefault("last_person", {})
            p["image"] = rel_name
            p["image_file"] = rel_name
            p.setdefault("image_status", "local_recovered_for_dashboard")
            p.setdefault("time", dt.datetime.fromtimestamp(latest.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"))

        update_state(mut)
    except Exception as exc:
        print(f"[PERSON MEDIA REPAIR] {exc}", flush=True)




def find_latest_local_vehicle_image() -> Optional[Path]:
    try:
        latest = None
        latest_mtime = 0.0

        if not FILES_DIR.exists():
            return None

        for path in FILES_DIR.glob("*.jpg"):
            try:
                name_lower = path.name.lower()
                if (
                    "_vehicle_" in name_lower and
                    path.is_file() and
                    path.stat().st_size > 1024 and
                    path.stat().st_mtime > latest_mtime
                ):
                    latest = path
                    latest_mtime = path.stat().st_mtime
            except Exception:
                continue

        return latest
    except Exception:
        return None


def repair_last_vehicle_media_state() -> None:
    try:
        state = load_state()
        vehicle = state.get("last_vehicle", {}) or {}
        image_name = str(vehicle.get("image") or vehicle.get("image_file") or "").strip()

        if image_name and not image_name.startswith("/") and not image_name.startswith("garbage/"):
            image_path = FILES_DIR / image_name
            if image_path.exists() and image_path.stat().st_size > 1024:
                if not vehicle.get("image") or not vehicle.get("image_file"):
                    update_state(lambda s: s.setdefault("last_vehicle", {}).update({
                        "image": image_name,
                        "image_file": image_name,
                    }))
                return

        latest = find_latest_local_vehicle_image()
        if latest is None:
            return

        rel_name = latest.name

        def mut(state_obj):
            v = state_obj.setdefault("last_vehicle", {})
            v["image"] = rel_name
            v["image_file"] = rel_name
            v.setdefault("image_status", "local_recovered_for_dashboard")
            v.setdefault("time", dt.datetime.fromtimestamp(latest.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"))

        update_state(mut)
    except Exception as exc:
        print(f"[VEHICLE MEDIA REPAIR] {exc}", flush=True)

def render_dashboard(initial_tab: str = "live", geofence_page_only: bool = False):
    repair_last_person_media_state()
    repair_last_vehicle_media_state()
    state = load_state()
    state.setdefault("system", {})
    state.setdefault("last_vehicle", {})
    state["system"].setdefault("vehicle_detection_mode", load_vehicle_detection_mode())
    state["system"].setdefault("vehicle_static_stay_sec", load_vehicle_static_stay_sec())
    state["last_vehicle"].setdefault("image", state["last_vehicle"].get("image_file"))
    state["last_vehicle"].setdefault("image_file", state["last_vehicle"].get("image"))
    state["last_vehicle"].setdefault("image_status", None)
    state["last_vehicle"].setdefault("image_uploaded_path", None)
    state["last_vehicle"].setdefault("mode", load_vehicle_detection_mode())
    state["last_vehicle"].setdefault("geofence_overlap", 0.0)
    state["last_vehicle"].setdefault("stable_inside_sec", 0.0)
    state["last_vehicle"].setdefault("stable_required_sec", load_vehicle_static_stay_sec())
    state["last_vehicle"].setdefault("stable_hit_count", 0)
    state["last_vehicle"].setdefault("stable_vehicle_count", 0)
    state.setdefault("links", {})
    state["links"].setdefault("dashboard_local", local_dashboard_url())
    state["links"].setdefault("stream_local", local_stream_url())
    state["links"].setdefault("dashboard_public", PERMANENT_DASHBOARD_URL)
    state["links"].setdefault("stream_public", PERMANENT_LIVE_URL)

    host = request.host or ""
    dashboard_public_request = is_cloudflare_live_request(host)
    dashboard_stream_endpoint = "/video_feed_cloudflare" if dashboard_public_request else "/video_feed"
    dashboard_snapshot_endpoint = "/snapshot.jpg"

    return render_template(
        "index.html",
        state=state,
        ts=int(time.time()),
        local_dashboard=local_dashboard_url(),
        local_stream=local_stream_url(),
        sftp_base_dir=SFTP_BASE_DIR,
        sftp_person_dir=SFTP_PERSON_DIR,
        sftp_person_video_dir=SFTP_PERSON_VIDEO_DIR,
        sftp_garbage_dir=SFTP_GARBAGE_DIR,
        sftp_audio_dir=SFTP_AUDIO_DIR,
        initial_tab=initial_tab,
        geofence_page_only=geofence_page_only,
        dashboard_public_request=dashboard_public_request,
        dashboard_stream_endpoint=dashboard_stream_endpoint,
        dashboard_snapshot_endpoint=dashboard_snapshot_endpoint
    )


@app.route("/")
def index():
    return render_dashboard("live", geofence_page_only=False)


@app.route("/garbage_geofencing")
def garbage_geofencing_page():
    return Response("Garbage geofencing removed in Person + Vehicle only build.", status=404)


@app.route("/person_geofencing")
def person_geofencing_page():
    return render_dashboard("person_geofence", geofence_page_only=True)


@app.route("/vehicle_geofencing")
def vehicle_geofencing_page():
    return render_dashboard("vehicle_geofence", geofence_page_only=True)


@app.route("/live_talk")
def live_talk_page():
    return Response("Live audio system removed in Person + Vehicle only build.", status=404)


@app.route("/api/live_talk/start", methods=["POST"])
def api_live_talk_start():
    return jsonify({"ok": False, "error": "live_audio_removed"}), 410


@app.route("/api/live_talk/chunk", methods=["POST"])
def api_live_talk_chunk():
    return jsonify({"ok": False, "error": "live_audio_removed"}), 410


@app.route("/api/live_talk/stop", methods=["POST"])
def api_live_talk_stop():
    return jsonify({"ok": True, "active": False, "message": "Live audio removed"})


@app.route("/api/live_talk/status", methods=["GET"])
def api_live_talk_status():
    return jsonify({"ok": True, "active": False, "removed": True})


def is_cloudflare_live_request(host: str) -> bool:
    host = (host or "").split(":")[0].strip().lower()
    permanent_host = ""

    if PERMANENT_LIVE_BASE_URL:
        permanent_host = PERMANENT_LIVE_BASE_URL.replace("https://", "").replace("http://", "").strip().lower().rstrip("/")

    return (
        host.endswith(".trycloudflare.com") or
        (permanent_host and host == permanent_host)
    )



CAMERA_PROXY_TIMEOUT_SEC = 20
CAMERA_PROXY_HOP_BY_HOP_HEADERS = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "content-encoding"
}


def _rewrite_camera_location(location: str) -> str:
    if not location:
        return location
    target = CAMERA_CONFIG_TARGET_URL.rstrip("/")
    if location.startswith(target):
        suffix = location[len(target):]
        return "/camera" + (suffix if suffix.startswith("/") else f"/{suffix}")
    if location.startswith("/"):
        return "/camera" + location
    return location


@app.route("/camera", defaults={"camera_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@app.route("/camera/<path:camera_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
def camera_config_proxy(camera_path: str):
    """Permanent /camera proxy for the local camera configuration page."""
    target_url = f"{CAMERA_CONFIG_TARGET_URL.rstrip('/')}/{camera_path.lstrip('/')}"
    if request.query_string:
        target_url += "?" + request.query_string.decode("utf-8", errors="ignore")

    headers = {
        key: value for key, value in request.headers.items()
        if key.lower() not in CAMERA_PROXY_HOP_BY_HOP_HEADERS and key.lower() != "host"
    }

    try:
        upstream = requests.request(
            method=request.method,
            url=target_url,
            headers=headers,
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False,
            verify=False,
            stream=True,
            timeout=CAMERA_PROXY_TIMEOUT_SEC,
        )
    except requests.RequestException as exc:
        return Response(
            f"Camera configuration page is unreachable: {exc}",
            status=502,
            mimetype="text/plain",
        )

    response_headers = []
    for key, value in upstream.headers.items():
        lower_key = key.lower()
        if lower_key in CAMERA_PROXY_HOP_BY_HOP_HEADERS:
            continue
        if lower_key == "location":
            value = _rewrite_camera_location(value)
        response_headers.append((key, value))

    return Response(
        stream_with_context(upstream.iter_content(chunk_size=8192)),
        status=upstream.status_code,
        headers=response_headers,
    )

@app.route("/live")
def live():
    host = request.host or ""
    stream_endpoint = "/video_feed_cloudflare" if is_cloudflare_live_request(host) else "/video_feed"
    return render_template("live.html", stream_endpoint=stream_endpoint)


@app.route("/video_feed")
def video_feed():
    if is_power_saving_active():
        return Response("Power saving mode active. Live stream disabled.", status=503)
    return make_mjpeg_response(mjpeg_stream())


@app.route("/video_feed_cloudflare")
def video_feed_cloudflare():
    if is_power_saving_active():
        return Response("Power saving mode active. Cloudflare live stream disabled.", status=503)

    return make_mjpeg_response(
        mjpeg_stream(
            frame_width=CLOUDFLARE_LIVE_FRAME_WIDTH,
            jpeg_quality=CLOUDFLARE_MJPEG_QUALITY,
            target_fps=CLOUDFLARE_STREAM_TARGET_FPS
        )
    )


@app.route("/snapshot.jpg")
def snapshot_jpg():
    if is_power_saving_active():
        return Response("Power saving mode active. Snapshot disabled.", status=503)

    frame = get_live_frame_copy()
    if frame is None:
        return Response("No live frame available", status=503, mimetype="text/plain")

    host = request.host or ""
    if is_cloudflare_live_request(host):
        frame_width = CLOUDFLARE_LIVE_FRAME_WIDTH
        jpeg_quality = CLOUDFLARE_MJPEG_QUALITY
    else:
        frame_width = LIVE_FRAME_WIDTH
        jpeg_quality = MJPEG_QUALITY

    frame = resize_frame_to_width(frame, frame_width)
    ok, jpg = cv2.imencode(
        ".jpg",
        frame,
        [int(cv2.IMWRITE_JPEG_QUALITY), int(jpeg_quality)]
    )

    if not ok:
        return Response("Snapshot encode failed", status=500, mimetype="text/plain")

    response = Response(jpg.tobytes(), mimetype="image/jpeg")
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


@app.route("/playback/live")
def playback_live_page():
    """Video-only DVR playback that follows newly completed segments indefinitely."""
    start_date_text = str(request.args.get("start_date", "")).strip()
    start_time_text = str(request.args.get("start_time", "")).strip()

    playback = None
    playback_error = None

    if not start_date_text or not start_time_text:
        playback_error = "start_date and start_time are required."
    else:
        try:
            range_start = dt.datetime.strptime(
                f"{start_date_text} {start_time_text}",
                "%Y-%m-%d %H:%M:%S",
            )
        except ValueError:
            playback_error = "Invalid start date/time format."
        else:
            playback, playback_error = find_recording_for_datetime(range_start)

    response = make_response(render_template(
        "playback_live.html",
        playback=playback,
        playback_error=playback_error,
    ))
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


@app.route("/playback")
def playback_page():
    now = now_dt()
    default_start = now - dt.timedelta(minutes=5)
    default_end = now

    start_date_text = str(request.args.get("start_date", "")).strip()
    start_time_text = str(request.args.get("start_time", "")).strip()
    end_date_text = str(request.args.get("end_date", "")).strip()
    end_time_text = str(request.args.get("end_time", "")).strip()
    to_latest = str(request.args.get("to_latest", "")).strip().lower() in {"1", "true", "yes", "on"}

    # Backward compatibility for old /playback?date=...&time=... links.
    legacy_date_text = str(request.args.get("date", "")).strip()
    legacy_time_text = str(request.args.get("time", "")).strip()
    if not start_date_text and not start_time_text and legacy_date_text and legacy_time_text:
        start_date_text = legacy_date_text
        start_time_text = legacy_time_text
        try:
            legacy_start = dt.datetime.strptime(
                f"{legacy_date_text} {legacy_time_text}",
                "%Y-%m-%d %H:%M:%S",
            )
            legacy_end = legacy_start + dt.timedelta(minutes=5)
            end_date_text = legacy_end.strftime("%Y-%m-%d")
            end_time_text = legacy_end.strftime("%H:%M:%S")
        except ValueError:
            pass

    # MQTT start-only links use the newest completed recording as their end point
    # at the moment the URL is opened. This keeps the link simple and avoids requiring
    # the MQTT sender to know the current latest recording timestamp.
    if to_latest and start_date_text and start_time_text:
        latest_end = latest_completed_recording_end()
        if latest_end is not None:
            end_date_text = latest_end.strftime("%Y-%m-%d")
            end_time_text = latest_end.strftime("%H:%M:%S")

    selected_start_date = start_date_text or default_start.strftime("%Y-%m-%d")
    selected_start_time = start_time_text or default_start.strftime("%H:%M:%S")
    selected_end_date = end_date_text or default_end.strftime("%Y-%m-%d")
    selected_end_time = end_time_text or default_end.strftime("%H:%M:%S")

    requested_start = None
    requested_end = None
    playback = None
    playback_error = None

    any_range_input = any([
        start_date_text,
        start_time_text,
        end_date_text,
        end_time_text,
    ])

    if any_range_input:
        if to_latest and start_date_text and start_time_text and not end_date_text and not end_time_text:
            playback_error = "No completed recording files are available yet."
        elif not all([
            start_date_text,
            start_time_text,
            end_date_text,
            end_time_text,
        ]):
            playback_error = "Start date/time and end date/time are all required."
        else:
            requested_start = f"{start_date_text} {start_time_text}"
            requested_end = f"{end_date_text} {end_time_text}"

            try:
                range_start = dt.datetime.strptime(requested_start, "%Y-%m-%d %H:%M:%S")
                range_end = dt.datetime.strptime(requested_end, "%Y-%m-%d %H:%M:%S")

                if range_end <= range_start:
                    playback_error = "End date/time must be later than start date/time."
                else:
                    playback, playback_error = find_recording_for_range(range_start, range_end)
            except ValueError:
                playback_error = "Invalid date/time format."

    storage = collect_storage_status()
    return render_template(
        "playback.html",
        selected_start_date=selected_start_date,
        selected_start_time=selected_start_time,
        selected_end_date=selected_end_date,
        selected_end_time=selected_end_time,
        requested_start=requested_start,
        requested_end=requested_end,
        playback=playback,
        playback_error=playback_error,
        storage=storage,
        available_dates=storage.get("available_dates", []),
    )


@app.route("/playback/video/<path:filename>")
def playback_video(filename):
    response = send_from_directory(str(RECORDING_DIR), filename, conditional=True)
    response.headers["Cache-Control"] = "private, no-cache, max-age=0"
    return response


@app.route("/api/playback/find")
def api_playback_find():
    start_date_text = str(request.args.get("start_date", "")).strip()
    start_time_text = str(request.args.get("start_time", "")).strip()
    end_date_text = str(request.args.get("end_date", "")).strip()
    end_time_text = str(request.args.get("end_time", "")).strip()

    if all([start_date_text, start_time_text, end_date_text, end_time_text]):
        try:
            range_start = dt.datetime.strptime(
                f"{start_date_text} {start_time_text}",
                "%Y-%m-%d %H:%M:%S",
            )
            range_end = dt.datetime.strptime(
                f"{end_date_text} {end_time_text}",
                "%Y-%m-%d %H:%M:%S",
            )
        except ValueError:
            return jsonify({
                "ok": False,
                "error": "start/end date/time must be YYYY-MM-DD and HH:MM:SS",
            }), 400

        if range_end <= range_start:
            return jsonify({
                "ok": False,
                "error": "End date/time must be later than start date/time.",
            }), 400

        playback, error = find_recording_for_range(range_start, range_end)
        if playback is None:
            return jsonify({"ok": False, "available": False, "error": error}), 404

        return jsonify({
            "ok": True,
            "available": True,
            "range_start": range_start.strftime("%Y-%m-%d %H:%M:%S"),
            "range_end": range_end.strftime("%Y-%m-%d %H:%M:%S"),
            "playback": playback,
        })

    # Legacy single timestamp API compatibility.
    date_text = str(request.args.get("date", "")).strip()
    time_text = str(request.args.get("time", "")).strip()
    try:
        target = dt.datetime.strptime(f"{date_text} {time_text}", "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return jsonify({
            "ok": False,
            "error": (
                "Use start_date/start_time/end_date/end_time for range playback, "
                "or date/time for legacy single-timestamp lookup."
            ),
        }), 400

    playback, error = find_recording_for_datetime(target)
    if playback is None:
        return jsonify({"ok": False, "available": False, "error": error}), 404
    return jsonify({"ok": True, "available": True, "playback": playback})


@app.route("/api/playback/next")
def api_playback_next():
    relative_path = str(request.args.get("file", "")).strip()
    end_text = str(request.args.get("end", "")).strip()

    if end_text:
        try:
            range_end = dt.datetime.strptime(end_text, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return jsonify({
                "ok": False,
                "playback": None,
                "error": "end must be YYYY-MM-DD HH:MM:SS",
            }), 400

        playback, error = find_next_recording_for_range(relative_path, range_end)
        if playback is None:
            return jsonify({"ok": False, "playback": None, "error": error}), 404
        return jsonify({"ok": True, "playback": playback})

    # Legacy next-segment behavior.
    playback = find_next_recording(relative_path)
    if playback is None:
        return jsonify({"ok": False, "playback": None}), 404
    return jsonify({"ok": True, "playback": playback})


@app.route("/api/playback/next_live")
def api_playback_next_live():
    relative_path = str(request.args.get("file", "")).strip()
    if not relative_path:
        return jsonify({"ok": False, "playback": None, "waiting": True}), 400

    playback = find_next_recording_live(relative_path)
    if playback is None:
        # 204-like waiting semantics encoded as JSON because browser polling wants
        # a simple response body. This is normal when playback has reached live edge.
        return jsonify({"ok": False, "playback": None, "waiting": True}), 404

    return jsonify({"ok": True, "playback": playback, "waiting": False})


@app.route("/api/playback/previous_live")
def api_playback_previous_live():
    relative_path = str(request.args.get("file", "")).strip()
    if not relative_path:
        return jsonify({"ok": False, "playback": None}), 400

    playback = find_previous_recording_live(relative_path)
    if playback is None:
        return jsonify({"ok": False, "playback": None}), 404

    return jsonify({"ok": True, "playback": playback})


@app.route("/api/storage")
def api_storage():
    return jsonify(collect_storage_status())


@app.route("/api/state")
def api_state():
    repair_last_person_media_state()
    repair_last_vehicle_media_state()
    payload = load_state()

    payload.setdefault("links", {})
    payload["links"]["dashboard_local"] = local_dashboard_url()
    payload["links"]["stream_local"] = local_stream_url()
    payload["links"]["dashboard_public"] = PERMANENT_DASHBOARD_URL
    payload["links"]["stream_public"] = PERMANENT_LIVE_URL
    payload["sftp_base_dir"] = SFTP_BASE_DIR
    payload["sftp_person_dir"] = SFTP_PERSON_DIR
    payload["sftp_person_video_dir"] = SFTP_PERSON_VIDEO_DIR
    payload["sftp_garbage_dir"] = SFTP_GARBAGE_DIR
    payload["sftp_audio_dir"] = SFTP_AUDIO_DIR
    payload["public_ip"] = detect_public_ip()
    payload["local_ip"] = detect_local_ip()
    payload["camera_config_url"] = PERMANENT_CAMERA_CONFIG_URL
    payload["garbage_detection_mode"] = load_garbage_detection_mode()
    payload["garbage_detection_mode_label"] = garbage_detection_mode_label(payload["garbage_detection_mode"])
    payload["person_static_stay_sec"] = load_person_static_stay_sec()
    payload["vehicle_detection_mode"] = load_vehicle_detection_mode()
    payload["vehicle_static_stay_sec"] = load_vehicle_static_stay_sec()
    payload["vehicle_geofence_overlap_threshold"] = load_vehicle_geofence_overlap_threshold()

    payload.setdefault("system", {})
    payload["system"]["garbage_detection_mode"] = payload["garbage_detection_mode"]
    payload["system"]["garbage_mode"] = payload["garbage_detection_mode_label"]
    payload["system"]["person_static_stay_sec"] = payload["person_static_stay_sec"]
    payload["system"]["vehicle_detection_mode"] = payload["vehicle_detection_mode"]
    payload["system"]["vehicle_static_stay_sec"] = payload["vehicle_static_stay_sec"]
    payload["system"]["vehicle_geofence_overlap_threshold"] = payload["vehicle_geofence_overlap_threshold"]

    payload.setdefault("last_person", {})
    payload["last_person"].setdefault("image", payload["last_person"].get("image_file"))
    payload["last_person"].setdefault("image_file", payload["last_person"].get("image"))
    payload["last_person"].setdefault("image_status", None)
    payload["last_person"].setdefault("image_uploaded_path", None)
    payload["last_person"].setdefault("stable_inside_sec", 0.0)
    payload["last_person"].setdefault("stable_required_sec", payload["person_static_stay_sec"])
    payload["last_person"].setdefault("stable_hit_count", 0)

    payload.setdefault("last_vehicle", {})
    payload["last_vehicle"].setdefault("image", payload["last_vehicle"].get("image_file"))
    payload["last_vehicle"].setdefault("image_file", payload["last_vehicle"].get("image"))
    payload["last_vehicle"].setdefault("image_status", None)
    payload["last_vehicle"].setdefault("image_uploaded_path", None)
    payload["last_vehicle"].setdefault("mode", payload["vehicle_detection_mode"])
    payload["last_vehicle"].setdefault("geofence_overlap", 0.0)
    payload["last_vehicle"].setdefault("stable_inside_sec", 0.0)
    payload["last_vehicle"].setdefault("stable_required_sec", payload["vehicle_static_stay_sec"])
    payload["last_vehicle"].setdefault("stable_hit_count", 0)
    payload["last_vehicle"].setdefault("stable_vehicle_count", 0)
    payload["last_vehicle"].setdefault("first_event_fired", False)
    payload["last_vehicle"].setdefault("second_event_fired", False)
    payload["last_vehicle"].setdefault("second_event_delay_sec", VEHICLE_SECOND_EVENT_DELAY_SEC)
    payload["last_vehicle"].setdefault("first_event_elapsed_sec", 0.0)

    if PERMANENT_LIVE_URL:
        payload["live_link"] = {
            "active": True,
            "url": PERMANENT_LIVE_URL,
            "expires_at": "Never"
        }

    return jsonify(payload)


def dashboard_bool_from_payload(data: Dict[str, Any], default: bool = False) -> bool:
    raw = data.get("enabled", data.get("value", default))

    if isinstance(raw, bool):
        return raw

    if isinstance(raw, (int, float)):
        return bool(raw)

    text = str(raw).strip().lower()
    return text in {"1", "true", "yes", "on", "enable", "enabled"}


def dashboard_controls_payload(include_volume: bool = True) -> Dict[str, Any]:
    state = load_state()
    payload = {
        "ok": True,
        **feature_flags_payload(),
        **garbage_detection_mode_payload(),
        "warning_audio": state.get("warning_audio", {}),
        "power_saving": state.get("power_saving", {}),
        **power_saving_status_payload(),
        "audio_queue_size": audio_queue.qsize() if hasattr(audio_queue, "qsize") else None,
    }

    if include_volume:
        try:
            payload["volume"] = {
                "ok": True,
                **get_current_pi_volume()
            }
        except Exception as exc:
            payload["volume"] = {
                "ok": False,
                "error": str(exc)
            }

    return payload


@app.route("/api/controls/state", methods=["GET"])
def api_controls_state():
    return jsonify(dashboard_controls_payload(include_volume=True))


@app.route("/api/controls/feature", methods=["POST"])
def api_controls_feature_set():
    data = request.get_json(force=True, silent=True) or {}
    flag_name = str(data.get("flag", "")).strip()
    enabled = dashboard_bool_from_payload(data)

    if flag_name not in DEFAULT_FEATURE_FLAGS:
        return jsonify({
            "ok": False,
            "error": f"Unknown feature flag: {flag_name}",
            "allowed_flags": sorted(DEFAULT_FEATURE_FLAGS.keys())
        }), 400

    flags = set_feature_flag(flag_name, enabled, source="dashboard controls")

    return jsonify({
        "ok": True,
        "flag": flag_name,
        "enabled": bool(enabled),
        "feature_flags": flags,
        **dashboard_controls_payload(include_volume=False)
    })


@app.route("/api/controls/warning_audio", methods=["POST"])
def api_controls_warning_audio_set():
    data = request.get_json(force=True, silent=True) or {}
    enabled = dashboard_bool_from_payload(data)
    target = normalize_warning_audio_target(str(data.get("target", "person")))
    target_key = f"{target}_enabled"
    status_key = f"last_{target}_status"
    status = f"{target} warning audio {'enabled' if enabled else 'disabled'} by dashboard controls"
    event_name = f"{target}_warning_audio_{'enabled' if enabled else 'disabled'}"

    def mutate_warning_audio(state):
        warning_cfg = state.setdefault("warning_audio", {})
        warning_cfg.setdefault("enabled", True)
        warning_cfg.setdefault("person_enabled", True)
        warning_cfg.setdefault("vehicle_enabled", True)
        warning_cfg[target_key] = bool(enabled)
        warning_cfg[status_key] = status
        warning_cfg["last_status"] = status

        # Re-enable global warning audio when either target is enabled.
        # Disabling one target does not disable the other target.
        if enabled:
            warning_cfg["enabled"] = True
            warning_cfg["schedule_enabled"] = False

    update_state(mutate_warning_audio, force_flush=True)
    add_event(event_name, {
        "source": "dashboard controls",
        "target": target,
        "enabled": bool(enabled)
    })

    return jsonify({
        "ok": True,
        "target": target,
        "enabled": bool(enabled),
        "status": status,
        **dashboard_controls_payload(include_volume=False)
    })
@app.route("/api/controls/garbage/mode", methods=["POST"])
def api_controls_garbage_mode_set():
    data = request.get_json(force=True, silent=True) or {}
    raw_mode = str(data.get("mode", data.get("garbage_detection_mode", ""))).strip().lower()

    if raw_mode not in GARBAGE_DETECTION_MODES:
        return jsonify({
            "ok": False,
            "error": f"Unknown garbage detection mode: {raw_mode}",
            "allowed_modes": sorted(GARBAGE_DETECTION_MODES)
        }), 400

    status = set_garbage_detection_mode(raw_mode, source="dashboard controls")

    return jsonify({
        "ok": True,
        "message": f"Garbage detection mode changed to {status['garbage_detection_mode_label']}",
        **status,
        **dashboard_controls_payload(include_volume=False)
    })


@app.route("/api/controls/garbage/manual_detect", methods=["POST"])
def api_controls_garbage_manual_detect():
    if is_power_saving_active():
        return jsonify({
            "ok": False,
            "error": "Power saving mode is active. Disable power saving before manual garbage detection."
        }), 409

    if not is_feature_enabled("garbage_detection_enabled"):
        return jsonify({
            "ok": False,
            "error": "Garbage detection is disabled. Enable garbage detection first.",
            **feature_flags_payload()
        }), 409

    result, error = run_garbage_detection_guarded(
        triggered_by="dashboard_manual",
        create_live_link=True,
        wait_for_frame_sec=8.0,
        wait_for_lock_sec=20.0
    )

    if result is None:
        error_text = error or "Manual garbage detection failed."

        if "already running" in error_text.lower():
            status_code = 409
        elif "no live frame" in error_text.lower() or "no frame" in error_text.lower():
            status_code = 503
        else:
            status_code = 500

        return jsonify({
            "ok": False,
            "error": error_text,
            **dashboard_controls_payload(include_volume=False)
        }), status_code

    return jsonify({
        "ok": True,
        "message": "Manual garbage detection completed",
        "result": result,
        **dashboard_controls_payload(include_volume=False)
    })


@app.route("/api/controls/garbage/sample_capture", methods=["POST"])
def api_controls_garbage_sample_capture():
    if is_power_saving_active():
        return jsonify({
            "ok": False,
            "error": "Power saving mode is active. Disable power saving before sample capture."
        }), 409

    try:
        result = capture_garbage_reference_from_live()
        return jsonify({
            "ok": True,
            "message": "Garbage sample captured successfully",
            "result": result,
            **dashboard_controls_payload(include_volume=False)
        })
    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc)
        }), 500


@app.route("/api/controls/garbage/reference_upload", methods=["POST"])
def api_controls_garbage_reference_upload():
    upload_file = request.files.get("reference_image")

    try:
        result = upload_garbage_reference_from_request(upload_file)
        return jsonify({
            "ok": True,
            "message": "Garbage reference image uploaded successfully",
            "result": result,
            **dashboard_controls_payload(include_volume=False)
        })
    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc)
        }), 400


@app.route("/api/controls/audio/clear_queue", methods=["POST"])
def api_controls_audio_clear_queue():
    try:
        stop_current_audio_process()
    except Exception:
        pass

    cleared_count = clear_audio_queue()

    update_state(lambda s: s.update({
        "last_audio": {
            "file": None,
            "source_path": None,
            "time": now_str(),
            "status": f"queue_cleared_dashboard ({cleared_count})"
        }
    }), force_flush=True)

    add_event("queue_cleared", {
        "source": "dashboard controls",
        "cleared_count": cleared_count
    })

    return jsonify({
        "ok": True,
        "cleared_count": cleared_count,
        "message": "Audio queue cleared successfully",
        **dashboard_controls_payload(include_volume=False)
    })


@app.route("/api/controls/power_saving", methods=["POST"])
def api_controls_power_saving_set():
    data = request.get_json(force=True, silent=True) or {}
    enabled = dashboard_bool_from_payload(data)

    result = set_power_saving_enabled(
        enabled=enabled,
        reason="dashboard controls",
        source="dashboard controls",
        disable_schedule=True
    )

    return jsonify({
        "ok": True,
        "enabled": enabled,
        **result,
        **dashboard_controls_payload(include_volume=False)
    })

@app.route("/api/controls/device/restart", methods=["POST"])
def api_controls_device_restart():
    data = request.get_json(force=True, silent=True) or {}

    if not validate_command(data):
        add_event("device_restart_rejected", {
            "source": "dashboard controls",
            "reason": "invalid_token",
            "remote_address": request.remote_addr
        })

        return jsonify({
            "ok": False,
            "error": "Invalid MQTT command token."
        }), 403

    confirmed_device_id = str(
        data.get("confirm_device_id", "")
    ).strip()

    if confirmed_device_id != DEVICE_ID:
        add_event("device_restart_rejected", {
            "source": "dashboard controls",
            "reason": "device_id_mismatch",
            "provided_device_id": confirmed_device_id,
            "remote_address": request.remote_addr
        })

        return jsonify({
            "ok": False,
            "error": "Device ID confirmation does not match."
        }), 400

    if not device_restart_lock.acquire(blocking=False):
        return jsonify({
            "ok": False,
            "error": "A device restart is already in progress."
        }), 409

    requested_at = now_str()

    try:
        update_state(
            lambda state: state["system"].update({
                "last_restart_request_at": requested_at,
                "last_restart_request_source": "dashboard controls"
            }),
            force_flush=True
        )

        add_event("device_restart_requested", {
            "source": "dashboard controls",
            "requested_at": requested_at,
            "remote_address": request.remote_addr
        })

        def run_restart() -> None:
            try:
                delayed_reboot()
            finally:
                try:
                    device_restart_lock.release()
                except RuntimeError:
                    pass

        threading.Thread(
            target=run_restart,
            daemon=True,
            name="dashboard-device-restart"
        ).start()

        return jsonify({
            "ok": True,
            "message": (
                f"Device {DEVICE_ID} restart accepted. "
                "The reboot will begin in approximately 2 seconds."
            ),
            "device_id": DEVICE_ID,
            "requested_at": requested_at,
            "restart_delay_seconds": 2
        }), 202

    except Exception as exc:
        try:
            device_restart_lock.release()
        except RuntimeError:
            pass

        add_event("device_restart_failed", {
            "source": "dashboard controls",
            "message": str(exc),
            "remote_address": request.remote_addr
        })

        return jsonify({
            "ok": False,
            "error": str(exc)
        }), 500


@app.route("/api/controls/volume", methods=["GET", "POST"])
def api_controls_volume():
    if request.method == "GET":
        try:
            result = get_current_pi_volume()
            return jsonify({
                "ok": True,
                **result
            })
        except Exception as exc:
            return jsonify({
                "ok": False,
                "error": str(exc)
            }), 500

    data = request.get_json(force=True, silent=True) or {}
    percent = data.get("volume_percent", data.get("percent", data.get("volume")))

    try:
        percent = int(percent)
    except Exception:
        return jsonify({
            "ok": False,
            "error": "volume_percent must be a number from 0 to 100"
        }), 400

    try:
        result = set_pi_volume(percent)

        update_state(lambda s: s.update({
            "last_audio": {
                "file": None,
                "source_path": None,
                "time": now_str(),
                "status": f"pi_volume_set_to_{result['volume_percent']}%_dashboard"
            }
        }), force_flush=True)

        add_event("pi_volume_set", {
            "source": "dashboard controls",
            "volume_percent": result["volume_percent"],
            "requested_volume_percent": result["requested_volume_percent"]
        })

        return jsonify({
            "ok": True,
            **result
        })

    except Exception as exc:
        add_event("pi_volume_set_failed", {
            "source": "dashboard controls",
            "volume_percent": percent,
            "message": str(exc)
        })

        return jsonify({
            "ok": False,
            "error": str(exc)
        }), 500


@app.route("/api/geofence", methods=["GET"])
def api_geofence_get():
    """Return current garbage polygon geofence as ratios."""
    polygon = load_garbage_polygon()
    roi_box = ratio_polygon_to_box(polygon)

    return jsonify({
        "garbage_polygon": round_ratio_polygon(polygon),
        "garbage_roi": [round(v, 4) for v in roi_box],
        "min_points": POLYGON_MIN_POINTS,
        "max_points": POLYGON_MAX_POINTS,
        "source": "config"
    })


@app.route("/api/geofence", methods=["POST"])
def api_geofence_set():
    """Save garbage polygon geofence to config.json. Hot reload, no restart."""
    data = request.get_json(force=True, silent=True) or {}

    polygon = sanitize_ratio_polygon(data.get("garbage_polygon"))

    # Backward compatibility: accept old rectangle ROI also.
    if polygon is None:
        old_box = _valid_ratio_box(data.get("garbage_roi"))
        if old_box is not None:
            polygon = ratio_box_to_polygon(old_box)

    if polygon is None:
        return jsonify({
            "ok": False,
            "error": f"garbage_polygon must contain {POLYGON_MIN_POINTS} to {POLYGON_MAX_POINTS} points. Example: [[0.1,0.2],[0.8,0.2],[0.8,0.8],[0.1,0.8]]"
        }), 400

    cfg = load_config()
    cfg["garbage_polygon"] = round_ratio_polygon(polygon)

    # Keep old ROI key for backward compatibility with old dashboard/app versions.
    roi_box = ratio_polygon_to_box(polygon)
    cfg["garbage_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "garbage_polygon": cfg["garbage_polygon"],
        "garbage_roi": cfg["garbage_roi"]
    })


@app.route("/api/geofence/reset", methods=["POST"])
def api_geofence_reset():
    """Reset garbage polygon geofence to default."""
    polygon = [(float(x), float(y)) for x, y in DEFAULT_GARBAGE_POLYGON]

    cfg = load_config()
    cfg["garbage_polygon"] = round_ratio_polygon(polygon)

    roi_box = ratio_polygon_to_box(polygon)
    cfg["garbage_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "garbage_polygon": cfg["garbage_polygon"],
        "garbage_roi": cfg["garbage_roi"]
    })


@app.route("/api/person_geofence", methods=["GET"])
def api_person_geofence_get():
    """Return current person polygon geofence as ratios."""
    polygon = load_person_polygon()
    roi_box = ratio_polygon_to_box(polygon)

    return jsonify({
        "person_polygon": round_ratio_polygon(polygon),
        "person_roi": [round(v, 4) for v in roi_box],
        "min_points": POLYGON_MIN_POINTS,
        "max_points": POLYGON_MAX_POINTS,
        "source": "config"
    })


@app.route("/api/person_geofence", methods=["POST"])
def api_person_geofence_set():
    """Save person polygon geofence to config.json. Hot reload, no restart."""
    data = request.get_json(force=True, silent=True) or {}

    polygon = sanitize_ratio_polygon(data.get("person_polygon"))

    # Backward compatibility: accept old rectangle ROI also.
    if polygon is None:
        old_box = _valid_ratio_box(data.get("person_roi"))
        if old_box is not None:
            polygon = ratio_box_to_polygon(old_box)

    if polygon is None:
        return jsonify({
            "ok": False,
            "error": f"person_polygon must contain {POLYGON_MIN_POINTS} to {POLYGON_MAX_POINTS} points. Example: [[0.1,0.2],[0.8,0.2],[0.8,0.8],[0.1,0.8]]"
        }), 400

    cfg = load_config()
    cfg["person_polygon"] = round_ratio_polygon(polygon)

    # Keep old ROI key for backward compatibility with old dashboard/app versions.
    roi_box = ratio_polygon_to_box(polygon)
    cfg["person_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "person_polygon": cfg["person_polygon"],
        "person_roi": cfg["person_roi"]
    })


@app.route("/api/person_geofence/reset", methods=["POST"])
def api_person_geofence_reset():
    """Reset person polygon geofence to default."""
    polygon = [(float(x), float(y)) for x, y in DEFAULT_PERSON_POLYGON]

    cfg = load_config()
    cfg["person_polygon"] = round_ratio_polygon(polygon)

    roi_box = ratio_polygon_to_box(polygon)
    cfg["person_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "person_polygon": cfg["person_polygon"],
        "person_roi": cfg["person_roi"]
    })


@app.route("/api/vehicle_geofence", methods=["GET"])
def api_vehicle_geofence_get():
    """Return current vehicle polygon geofence as ratios."""
    polygon = load_vehicle_polygon()
    roi_box = ratio_polygon_to_box(polygon)

    return jsonify({
        "vehicle_polygon": round_ratio_polygon(polygon),
        "vehicle_roi": [round(v, 4) for v in roi_box],
        "min_points": POLYGON_MIN_POINTS,
        "max_points": POLYGON_MAX_POINTS,
        "overlap_threshold": load_vehicle_geofence_overlap_threshold(),
        "source": "config"
    })


@app.route("/api/vehicle_geofence", methods=["POST"])
def api_vehicle_geofence_set():
    """Save vehicle polygon geofence to config.json. Hot reload, no restart."""
    data = request.get_json(force=True, silent=True) or {}

    polygon = sanitize_ratio_polygon(data.get("vehicle_polygon"))

    # Backward compatibility: accept old rectangle ROI also.
    if polygon is None:
        old_box = _valid_ratio_box(data.get("vehicle_roi"))
        if old_box is not None:
            polygon = ratio_box_to_polygon(old_box)

    if polygon is None:
        return jsonify({
            "ok": False,
            "error": f"vehicle_polygon must contain {POLYGON_MIN_POINTS} to {POLYGON_MAX_POINTS} points. Example: [[0.1,0.2],[0.8,0.2],[0.8,0.8],[0.1,0.8]]"
        }), 400

    cfg = load_config()
    cfg["vehicle_polygon"] = round_ratio_polygon(polygon)

    # Keep old ROI key for backward compatibility with old dashboard/app versions.
    roi_box = ratio_polygon_to_box(polygon)
    cfg["vehicle_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "vehicle_polygon": cfg["vehicle_polygon"],
        "vehicle_roi": cfg["vehicle_roi"],
        "overlap_threshold": load_vehicle_geofence_overlap_threshold()
    })


@app.route("/api/vehicle_geofence/reset", methods=["POST"])
def api_vehicle_geofence_reset():
    """Reset vehicle polygon geofence to default."""
    polygon = [(float(x), float(y)) for x, y in DEFAULT_VEHICLE_POLYGON]

    cfg = load_config()
    cfg["vehicle_polygon"] = round_ratio_polygon(polygon)

    roi_box = ratio_polygon_to_box(polygon)
    cfg["vehicle_roi"] = [round(v, 4) for v in roi_box]

    safe_write_json(CONFIG_FILE, cfg)

    return jsonify({
        "ok": True,
        "vehicle_polygon": cfg["vehicle_polygon"],
        "vehicle_roi": cfg["vehicle_roi"],
        "overlap_threshold": load_vehicle_geofence_overlap_threshold()
    })
	
@app.route("/api/person_static_stay", methods=["POST"])
def api_person_static_stay_set():
    data = request.get_json(force=True, silent=True) or {}

    seconds = (
        data.get("seconds") or
        data.get("person_static_stay_sec") or
        data.get("value")
    )

    result = set_person_static_stay_sec(
        seconds,
        source="dashboard"
    )

    return jsonify({
        "ok": True,
        **result,
        **person_static_stay_payload()
    })

@app.route("/api/vehicle_static_stay", methods=["POST"])
def api_vehicle_static_stay_set():
    data = request.get_json(force=True, silent=True) or {}

    seconds = (
        data.get("seconds") or
        data.get("vehicle_static_stay_sec") or
        data.get("value")
    )

    result = set_vehicle_static_stay_sec(
        seconds,
        source="dashboard"
    )

    return jsonify({
        "ok": True,
        **result,
        **vehicle_detection_mode_payload()
    })

@app.route("/api/vehicle_detection_mode", methods=["GET"])
def api_vehicle_detection_mode_get():
    return jsonify({
        "ok": True,
        **vehicle_detection_mode_payload()
    })


@app.route("/api/vehicle_detection_mode", methods=["POST"])
def api_vehicle_detection_mode_set():
    data = request.get_json(force=True, silent=True) or {}
    mode = data.get("mode") or data.get("vehicle_detection_mode")
    normalized_mode = normalize_vehicle_detection_mode(mode)

    result = set_vehicle_detection_mode(normalized_mode, source="dashboard")

    return jsonify({
        "ok": True,
        **result
    })

@app.route("/api/snapshot")
def api_snapshot():
    """Return a single JPEG frame for the geofence editor."""
    if is_power_saving_active():
        return Response("Power saving mode active. Snapshot disabled.", status=503)

    frame = get_frame_copy()
    if frame is None:
        return Response("No frame", status=503)
    ok, jpg = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
    if not ok:
        return Response("Encode failed", status=500)
    return Response(jpg.tobytes(), mimetype="image/jpeg")


@app.route("/media/<path:filename>")
def media(filename):
    if filename.startswith("garbage/"):
        return send_from_directory(str(GARBAGE_DIR), filename.replace("garbage/", "", 1))
    return send_from_directory(str(FILES_DIR), filename)


def startup() -> None:
    load_state()

    try:
        init_models()
    except Exception as exc:
        update_state(lambda s: s["system"].update({"last_error": f"Model init failed: {exc}"}), True)

    try:
        init_router_reboot_gpio()
    except Exception as exc:
        update_state(lambda s: s["system"].update({"last_error": f"GPIO init failed: {exc}"}), True)

    try:
        refresh_runtime_links_in_state()
        refresh_device_metrics_in_state()
        update_state(
            lambda s: s["live_link"].update({
                "active": True if PERMANENT_LIVE_URL else False,
                "url": PERMANENT_LIVE_URL,
                "expires_at": "Never" if PERMANENT_LIVE_URL else None
            }),
            force_flush=True
        )
    except Exception:
        pass

    threading.Thread(target=main_upload_buffer_loop, daemon=True).start()
    threading.Thread(target=reader_loop, daemon=True).start()
    threading.Thread(target=recording_manager_loop, daemon=True, name="gcam-storage-recorder").start()
    threading.Thread(target=detector_loop, daemon=True).start()
    # Garbage loop removed in Person + Vehicle only build.
    threading.Thread(target=cleanup_loop, daemon=True).start()
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    threading.Thread(target=state_flusher_loop, daemon=True).start()
    threading.Thread(target=sftp_retry_worker_loop, daemon=True).start()
    # MQTT/default audio upload-play worker removed. Person warning audio remains direct.
    # Live talk worker removed.
    # Network audio monitor removed.
    threading.Thread(target=mqtt_command_loop, daemon=True).start()
    threading.Thread(target=router_reboot_schedule_loop, daemon=True).start()
    threading.Thread(target=power_saving_schedule_loop, daemon=True).start()


def shutdown(*_args) -> None:
    global router_reboot_gpio_initialized

    stop_event.set()

    try:
        stop_current_audio_process()
    except Exception:
        pass

    try:
        set_live_talk_active(False)
        set_live_talk_stopping(False)
        stop_live_talk_processes()
        clear_live_talk_queue()
    except Exception:
        pass

    try:
        stop_recording_process()
    except Exception:
        pass

    try:
        flush_state(True)
    except Exception:
        pass
    try:
        stop_live_tunnel()
    except Exception:
        pass

    router_reboot_gpio_initialized = False


atexit.register(shutdown)
signal.signal(signal.SIGTERM, shutdown)
signal.signal(signal.SIGINT, shutdown)

if __name__ == "__main__":
    startup()
    serve(app, host=HOST, port=PORT, threads=16, connection_limit=200, channel_timeout=120)
PY

echo "[16/17] Write controller.py..."
cat > "$APP_DIR/controller.py" <<'PY'
import atexit
import datetime as dt
import json
import re
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

import paho.mqtt.client as mqtt

APP_DIR = Path("/opt/gcam")
DATA_DIR = APP_DIR / "data"
CONFIG_FILE = DATA_DIR / "config.json"

APP_SERVICE_NAME = "gcam.service"
CLOUDFLARE_SERVICE_NAME = "cloudflared.service"
CLOUDFLARE_WATCHDOG_SERVICE_NAME = "gcam-cloudflare-watchdog.service"
CLOUDFLARE_READY_URL = "http://127.0.0.1:20241/ready"
CLOUDFLARED_BIN = "/usr/bin/cloudflared"
CAMERA_TUNNEL_DURATION_SEC = 600
CLOUDFLARE_RESTART_COMMAND_TIMEOUT_SEC = 45
CLOUDFLARE_CONNECTOR_READY_TIMEOUT_SEC = 75
CLOUDFLARE_PUBLIC_READY_TIMEOUT_SEC = 45

stop_event = threading.Event()
tunnel_lock = threading.Lock()
camera_tunnel_proc: Optional[subprocess.Popen] = None
camera_tunnel_url: Optional[str] = None
camera_tunnel_expiry_ts: float = 0.0
camera_tunnel_stop_timer: Optional[threading.Timer] = None
cloudflare_restart_lock = threading.Lock()


def load_config() -> Dict[str, Any]:
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


CONFIG = load_config()

DEVICE_ID = CONFIG["device_id"]
CAMERA_NAME = CONFIG["camera_name"]
CAMERA_IP = CONFIG["camera_ip"]
CAMERA_CONFIG_TARGET_URL = str(CONFIG.get("camera_config_url", f"https://{CAMERA_IP}:443")).strip().rstrip("/")
CAMERA_CONFIG_URL = CAMERA_CONFIG_TARGET_URL

SUBDOMAIN_NAME = str(CONFIG.get("subdomain_name", "")).strip().lower()
BASE_DOMAIN = str(CONFIG.get("base_domain", "")).strip().lower()
PERMANENT_LIVE_BASE_URL = str(CONFIG.get("permanent_live_base_url", "")).strip().rstrip("/")
if not PERMANENT_LIVE_BASE_URL and SUBDOMAIN_NAME and BASE_DOMAIN:
    PERMANENT_LIVE_BASE_URL = f"https://{SUBDOMAIN_NAME}.{BASE_DOMAIN}"

PERMANENT_CAMERA_CONFIG_URL = str(CONFIG.get("permanent_camera_config_url", "")).strip().rstrip("/")
if not PERMANENT_CAMERA_CONFIG_URL and PERMANENT_LIVE_BASE_URL:
    PERMANENT_CAMERA_CONFIG_URL = f"{PERMANENT_LIVE_BASE_URL}/camera"
if not PERMANENT_CAMERA_CONFIG_URL:
    PERMANENT_CAMERA_CONFIG_URL = CAMERA_CONFIG_TARGET_URL

PERMANENT_HEALTH_URL = (
    f"{PERMANENT_LIVE_BASE_URL}/api/state"
    if PERMANENT_LIVE_BASE_URL
    else ""
)

MQTT_HOST = CONFIG["mqtt"]["host"]
MQTT_PORT = int(CONFIG["mqtt"]["port"])
MQTT_USERNAME = CONFIG["mqtt"]["username"]
MQTT_PASSWORD = CONFIG["mqtt"]["password"]
MQTT_COMMAND_TOPIC = CONFIG["mqtt"].get("command_topic", "G-Cam-RnD/command")
MQTT_RESPONSE_TOPIC = CONFIG["mqtt"].get("response_topic", "G-Cam-RnD/device_response")
MQTT_COMMAND_TOKEN = CONFIG["mqtt"].get("command_token", "")


def now_str() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def validate_command(payload: Dict[str, Any]) -> bool:
    if not MQTT_COMMAND_TOKEN:
        return True
    return str(payload.get("token", "")).strip() == MQTT_COMMAND_TOKEN


def normalize_command(raw: str) -> str:
    cmd = re.sub(r"\s+", " ", str(raw or "").strip().lower())
    mapping = {
        "close the software": "close the software",
        "open the software": "open the software",

        "cloudflare restart": "cloudflare restart",
        "restart cloudflare": "cloudflare restart",
        "cloudflare service restart": "cloudflare restart",
        "restart cloudflare service": "cloudflare restart",
        "cloudflare tunnel restart": "cloudflare restart",
        "restart cloudflare tunnel": "cloudflare restart",
        "permanent cloudflare restart": "cloudflare restart",
        "cloudflare status": "cloudflare status",
        "cloudflare service status": "cloudflare status",
        "cloudflare tunnel status": "cloudflare status",

        "camera temp url": "camera temp url",
        "camera temporary url": "camera temp url",
        "camera temp access url": "camera temp url",
        "camera temporary access url": "camera temp url",
        "temp camera url": "camera temp url",
        "temporary camera url": "camera temp url",
        "temp camera access url": "camera temp url",
        "temporary camera access url": "camera temp url",
        "camera config temp url": "camera temp url",
        "camera temporary config url": "camera temp url",
        "camera access url": "camera temp url",
        "cloudflare camera url": "camera temp url",
        "cloudflare temp camera url": "camera temp url",
        "cloudflare temporary camera url": "camera temp url",
        "cloudflare temp camera access url": "camera temp url",
        "cloudflare temporary camera access url": "camera temp url",

        "camera live url": "camera permanent url",
        "camera permanent url": "camera permanent url",
        "camera config url": "camera permanent url",
        "camera url": "camera permanent url",

        "warning audio disable": "warning audio disable",
        "warning audio enable": "warning audio enable",
        "scheduled warning audio": "scheduled warning audio",
        "scheduled warning disabled": "scheduled warning disabled",
    }
    return mapping.get(cmd, cmd)


def mqtt_publish(payload: Dict[str, Any]) -> None:
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    client.connect(MQTT_HOST, MQTT_PORT, 20)
    info = client.publish(MQTT_RESPONSE_TOPIC, json.dumps(payload), qos=1, retain=False)
    info.wait_for_publish(timeout=5)
    client.disconnect()


def run_systemctl(
    action: str,
    service_name: str = APP_SERVICE_NAME,
    timeout_sec: int = 20,
) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["sudo", "/usr/bin/systemctl", action, service_name],
        capture_output=True,
        text=True,
        timeout=timeout_sec,
    )


def is_service_active(service_name: str) -> bool:
    proc = subprocess.run(
        ["sudo", "/usr/bin/systemctl", "is-active", service_name],
        capture_output=True,
        text=True,
        timeout=10,
    )
    return proc.returncode == 0 and proc.stdout.strip() == "active"


def is_app_active() -> bool:
    return is_service_active(APP_SERVICE_NAME)


def http_status(url: str, timeout_sec: float = 5.0) -> Optional[int]:
    if not url:
        return None

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "GCam-MQTT-Cloudflare-Recovery/1.0"},
        method="GET",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout_sec) as response:
            return int(response.status)
    except urllib.error.HTTPError as exc:
        return int(exc.code)
    except Exception:
        return None


def cloudflare_status_payload() -> Dict[str, Any]:
    service_active = is_service_active(CLOUDFLARE_SERVICE_NAME)
    ready_code = http_status(CLOUDFLARE_READY_URL, timeout_sec=3.0) if service_active else None
    connector_ready = ready_code == 200
    public_code = http_status(PERMANENT_HEALTH_URL, timeout_sec=8.0) if connector_ready else None
    public_healthy = public_code is not None and 200 <= public_code < 500

    if not service_active:
        status = "service_inactive"
    elif not connector_ready:
        status = "connector_not_ready"
    elif not public_healthy:
        status = "public_route_unavailable"
    else:
        status = "healthy"

    return {
        "cloudflare_status": status,
        "cloudflare_service": CLOUDFLARE_SERVICE_NAME,
        "cloudflare_service_active": service_active,
        "cloudflare_connector_ready": connector_ready,
        "cloudflare_ready_http_code": ready_code,
        "cloudflare_public_url": PERMANENT_LIVE_BASE_URL or None,
        "cloudflare_public_health_url": PERMANENT_HEALTH_URL or None,
        "cloudflare_public_http_code": public_code,
        "cloudflare_public_healthy": public_healthy,
    }


def wait_for_cloudflare_connector(timeout_sec: int = CLOUDFLARE_CONNECTOR_READY_TIMEOUT_SEC) -> bool:
    deadline = time.monotonic() + max(timeout_sec, 1)

    while time.monotonic() < deadline and not stop_event.is_set():
        if (
            is_service_active(CLOUDFLARE_SERVICE_NAME)
            and http_status(CLOUDFLARE_READY_URL, timeout_sec=3.0) == 200
        ):
            return True
        time.sleep(2)

    return False


def wait_for_cloudflare_public(timeout_sec: int = CLOUDFLARE_PUBLIC_READY_TIMEOUT_SEC) -> bool:
    if not PERMANENT_HEALTH_URL:
        return False

    deadline = time.monotonic() + max(timeout_sec, 1)

    while time.monotonic() < deadline and not stop_event.is_set():
        code = http_status(PERMANENT_HEALTH_URL, timeout_sec=8.0)
        if code is not None and 200 <= code < 500:
            return True
        time.sleep(3)

    return False


def run_cloudflare_restart() -> None:
    restart_return_code: Optional[int] = None
    restart_stdout = ""
    restart_stderr = ""
    restart_timed_out = False

    try:
        try:
            result = run_systemctl(
                "restart",
                CLOUDFLARE_SERVICE_NAME,
                timeout_sec=CLOUDFLARE_RESTART_COMMAND_TIMEOUT_SEC,
            )
            restart_return_code = result.returncode
            restart_stdout = result.stdout.strip()
            restart_stderr = result.stderr.strip()
        except subprocess.TimeoutExpired as exc:
            # The systemctl client can time out while systemd is still completing
            # the restart job. Do not report a false failure; poll the real service
            # and connector state below instead.
            restart_timed_out = True
            if exc.stdout:
                restart_stdout = exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else str(exc.stdout)
                restart_stdout = restart_stdout.strip()
            if exc.stderr:
                restart_stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else str(exc.stderr)
                restart_stderr = restart_stderr.strip()

        connector_ready = wait_for_cloudflare_connector()

        if connector_ready:
            # Give the Cloudflare edge route time to bind to the recovered connector.
            wait_for_cloudflare_public()

        status = cloudflare_status_payload()
        completed = bool(status["cloudflare_connector_ready"])
        public_healthy = bool(status["cloudflare_public_healthy"])

        if completed and public_healthy:
            event = "cloudflare_restart_completed"
            if restart_timed_out:
                message = (
                    "The systemctl client timed out, but systemd completed the restart and "
                    "the permanent Cloudflare tunnel is healthy."
                )
            else:
                message = "Cloudflare service restarted and the permanent tunnel is healthy."
        elif completed:
            event = "cloudflare_restart_partial"
            message = (
                "Cloudflare connector is ready, but the permanent hostname is still unavailable. "
                "Check that the Cloudflare published application hostname points to this same tunnel "
                "and routes to http://localhost:8080."
            )
        else:
            event = "cloudflare_restart_failed"
            message = (
                "Cloudflare service restart did not produce a ready connector. "
                "Check the tunnel token, DNS, outbound TCP/UDP port 7844, and cloudflared logs."
            )

        mqtt_publish({
            "device_id": DEVICE_ID,
            "event": event,
            "requested_at": now_str(),
            "message": message,
            "restart_return_code": restart_return_code,
            "restart_timed_out": restart_timed_out,
            "restart_stdout": restart_stdout,
            "restart_stderr": restart_stderr,
            **status,
        })
    except Exception as exc:
        try:
            mqtt_publish({
                "device_id": DEVICE_ID,
                "event": "cloudflare_restart_failed",
                "requested_at": now_str(),
                "message": str(exc),
                "restart_return_code": restart_return_code,
                "restart_timed_out": restart_timed_out,
                "restart_stdout": restart_stdout,
                "restart_stderr": restart_stderr,
                **cloudflare_status_payload(),
            })
        except Exception:
            pass
    finally:
        try:
            cloudflare_restart_lock.release()
        except RuntimeError:
            pass


def handle_cloudflare_restart() -> None:
    if not cloudflare_restart_lock.acquire(blocking=False):
        mqtt_publish({
            "device_id": DEVICE_ID,
            "event": "cloudflare_restart_ignored",
            "requested_at": now_str(),
            "message": "A Cloudflare restart is already in progress.",
            **cloudflare_status_payload(),
        })
        return

    mqtt_publish({
        "device_id": DEVICE_ID,
        "event": "cloudflare_restart_started",
        "requested_at": now_str(),
        "message": "Restarting the permanent Cloudflare Tunnel service.",
        **cloudflare_status_payload(),
    })

    threading.Thread(
        target=run_cloudflare_restart,
        daemon=True,
        name="mqtt-cloudflare-restart",
    ).start()


def handle_cloudflare_status() -> None:
    mqtt_publish({
        "device_id": DEVICE_ID,
        "event": "cloudflare_status",
        "requested_at": now_str(),
        **cloudflare_status_payload(),
    })


def camera_tunnel_is_active() -> bool:
    return camera_tunnel_proc is not None and camera_tunnel_proc.poll() is None and bool(camera_tunnel_url)


def stop_camera_tunnel() -> None:
    global camera_tunnel_proc, camera_tunnel_url, camera_tunnel_expiry_ts, camera_tunnel_stop_timer

    with tunnel_lock:
        if camera_tunnel_stop_timer is not None:
            try:
                camera_tunnel_stop_timer.cancel()
            except Exception:
                pass
            camera_tunnel_stop_timer = None

        if camera_tunnel_proc is not None:
            try:
                camera_tunnel_proc.terminate()
                camera_tunnel_proc.wait(timeout=5)
            except Exception:
                try:
                    camera_tunnel_proc.kill()
                except Exception:
                    pass

        camera_tunnel_proc = None
        camera_tunnel_url = None
        camera_tunnel_expiry_ts = 0.0


def start_camera_tunnel(duration_sec: int = CAMERA_TUNNEL_DURATION_SEC) -> Optional[Dict[str, Any]]:
    global camera_tunnel_proc, camera_tunnel_url, camera_tunnel_expiry_ts, camera_tunnel_stop_timer

    with tunnel_lock:
        now_ts = time.time()

        if camera_tunnel_is_active() and camera_tunnel_url:
            camera_tunnel_expiry_ts = now_ts + duration_sec

            if camera_tunnel_stop_timer is not None:
                try:
                    camera_tunnel_stop_timer.cancel()
                except Exception:
                    pass

            camera_tunnel_stop_timer = threading.Timer(duration_sec, stop_camera_tunnel)
            camera_tunnel_stop_timer.daemon = True
            camera_tunnel_stop_timer.start()

            return {
                "camera_config_local_url": CAMERA_CONFIG_TARGET_URL,
                "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
                "camera_config_temp_url": camera_tunnel_url,
                "camera_access_url_temp": camera_tunnel_url,
                "camera_config_expires_in_sec": int(max(camera_tunnel_expiry_ts - time.time(), 0)),
                "camera_config_expires_at": dt.datetime.fromtimestamp(camera_tunnel_expiry_ts).isoformat(),
                "camera_name": CAMERA_NAME,
                "device_id": DEVICE_ID,
            }

        if not Path(CLOUDFLARED_BIN).exists():
            return None

        if camera_tunnel_proc is not None:
            try:
                camera_tunnel_proc.terminate()
                camera_tunnel_proc.wait(timeout=5)
            except Exception:
                try:
                    camera_tunnel_proc.kill()
                except Exception:
                    pass

        cmd = [
            CLOUDFLARED_BIN,
            "tunnel",
            "--url",
            CAMERA_CONFIG_TARGET_URL,
            "--no-autoupdate",
            "--no-tls-verify",
        ]

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )

        found_url = None
        deadline = time.time() + 30
        pattern = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.IGNORECASE)

        while time.time() < deadline:
            line = proc.stdout.readline() if proc.stdout else ""
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(0.2)
                continue

            match = pattern.search(line)
            if match:
                found_url = match.group(0).rstrip("/")
                break

        if not found_url:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            return None

        camera_tunnel_proc = proc
        camera_tunnel_url = found_url
        camera_tunnel_expiry_ts = time.time() + duration_sec

        camera_tunnel_stop_timer = threading.Timer(duration_sec, stop_camera_tunnel)
        camera_tunnel_stop_timer.daemon = True
        camera_tunnel_stop_timer.start()

        return {
            "camera_config_local_url": CAMERA_CONFIG_TARGET_URL,
            "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
            "camera_config_temp_url": camera_tunnel_url,
            "camera_access_url_temp": camera_tunnel_url,
            "camera_config_expires_in_sec": int(max(camera_tunnel_expiry_ts - time.time(), 0)),
            "camera_config_expires_at": dt.datetime.fromtimestamp(camera_tunnel_expiry_ts).isoformat(),
            "camera_name": CAMERA_NAME,
            "device_id": DEVICE_ID,
        }


def handle_close_software() -> None:
    before_active = is_app_active()
    result = run_systemctl("stop")
    after_active = is_app_active()
    mqtt_publish({
        "device_id": DEVICE_ID,
        "event": "software_closed",
        "requested_at": now_str(),
        "was_active_before": before_active,
        "is_active_after": after_active,
        "service": APP_SERVICE_NAME,
        "return_code": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    })


def handle_open_software() -> None:
    before_active = is_app_active()
    result = run_systemctl("start")
    time.sleep(2)
    after_active = is_app_active()
    mqtt_publish({
        "device_id": DEVICE_ID,
        "event": "software_opened",
        "requested_at": now_str(),
        "was_active_before": before_active,
        "is_active_after": after_active,
        "service": APP_SERVICE_NAME,
        "return_code": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    })


def handle_camera_permanent_url() -> None:
    mqtt_publish({
        "device_id": DEVICE_ID,
        "event": "camera_permanent_url",
        "requested_at": now_str(),
        "camera_name": CAMERA_NAME,
        "camera_config_url": PERMANENT_CAMERA_CONFIG_URL,
        "camera_config_permanent_url": PERMANENT_CAMERA_CONFIG_URL,
        "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
        "camera_config_local_url": CAMERA_CONFIG_TARGET_URL,
        "message": "Permanent camera configuration URL is ready",
    })


def handle_camera_temp_url() -> None:
    payload = start_camera_tunnel(CAMERA_TUNNEL_DURATION_SEC)
    if payload is None:
        mqtt_publish({
            "device_id": DEVICE_ID,
            "event": "camera_temp_url_failed",
            "requested_at": now_str(),
            "camera_name": CAMERA_NAME,
            "camera_config_local_url": CAMERA_CONFIG_TARGET_URL,
            "camera_config_target_url": CAMERA_CONFIG_TARGET_URL,
            "message": "Unable to create Cloudflare temporary camera URL",
        })
        return

    mqtt_publish({
        "event": "camera_temp_url_created",
        "requested_at": now_str(),
        **payload,
    })


def handle_command(payload: Dict[str, Any]) -> None:
    if not validate_command(payload):
        mqtt_publish({
            "device_id": DEVICE_ID,
            "event": "command_rejected",
            "requested_at": now_str(),
            "message": "Invalid token",
        })
        return

    cmd = normalize_command(payload.get("command", ""))

    if cmd == "close the software":
        handle_close_software()
        return

    if cmd == "open the software":
        handle_open_software()
        return

    if cmd == "cloudflare restart":
        handle_cloudflare_restart()
        return

    if cmd == "cloudflare status":
        handle_cloudflare_status()
        return

    if cmd == "camera permanent url":
        handle_camera_permanent_url()
        return

    if cmd == "camera temp url":
        handle_camera_temp_url()
        return

    # Commands not owned by the controller are handled by app.py, which
    # subscribes to the same command topic. Do not publish a false unknown-command
    # response from this secondary listener.
    return


def mqtt_loop() -> None:
    def on_connect(client, userdata, flags, reason_code, properties=None):
        client.subscribe(MQTT_COMMAND_TOPIC, qos=1)

    def on_message(client, userdata, msg):
        try:
            # Do not execute commands retained by the MQTT broker. A retained
            # command is replayed after every reconnect and can repeat actions.
            if bool(getattr(msg, "retain", False)):
                print(
                    f"Ignored retained MQTT controller command on {msg.topic}; clearing it.",
                    flush=True
                )
                try:
                    client.publish(msg.topic, payload=b"", qos=1, retain=True)
                except Exception as clear_exc:
                    print(f"Failed to clear retained MQTT command: {clear_exc}", flush=True)
                return

            raw = msg.payload.decode("utf-8", errors="ignore").strip()
            if not raw:
                return

            payload = json.loads(raw) if raw.startswith("{") else {"command": raw}
            handle_command(payload)
        except Exception as exc:
            try:
                mqtt_publish({
                    "device_id": DEVICE_ID,
                    "event": "controller_error",
                    "requested_at": now_str(),
                    "message": str(exc),
                })
            except Exception:
                pass

    while not stop_event.is_set():
        client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"{DEVICE_ID}-controller"
        )
        client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
        client.on_connect = on_connect
        client.on_message = on_message

        try:
            client.connect(MQTT_HOST, MQTT_PORT, 20)
            client.loop_start()
            while not stop_event.is_set():
                time.sleep(1)
        except Exception:
            pass
        finally:
            try:
                client.loop_stop()
            except Exception:
                pass
            try:
                client.disconnect()
            except Exception:
                pass

        time.sleep(5)


def shutdown(*_args) -> None:
    stop_event.set()
    try:
        stop_camera_tunnel()
    except Exception:
        pass


atexit.register(shutdown)
signal.signal(signal.SIGTERM, shutdown)
signal.signal(signal.SIGINT, shutdown)

if __name__ == "__main__":
    mqtt_loop()
PY

echo "[17/17] Write state, services and timers..."
cat > "$APP_DIR/data/state.json" <<JSON
{
  "app_name": "G-Cam \"RealTech Systems\"",
  "started_at": null,
  "camera_ip": "$CAMERA_IP",
  "router_ip": "$ROUTER_IP",
  "raspberry_ip": "$PI_IP",
  "device_id": "$DEVICE_ID",
  "camera_name": "$CAMERA_NAME",
  "camera_config_url": "$PERMANENT_CAMERA_CONFIG_URL",
  "camera_config_target_url": "$CAMERA_CONFIG_URL",
  "public_ip": null,
  "system": {
    "camera_connected": false,
    "last_frame_at": null,
    "last_error": null,
    "sftp_last_ok": null,
    "sftp_last_error": null,
    "mqtt_last_ok": null,
    "mqtt_last_error": null,
    "command_listener": false,
    "garbage_mode": "hybrid_reference_filtered",
    "pi_temperature_c": null,
    "network_status": null,
    "network_iface": null,
    "network_link_speed_mbps": null,
    "network_rx_bps": 0,
    "network_tx_bps": 0,
    "battery_voltage": null,
    "battery_current_a": null,
    "battery_current_ma": null,
    "battery_status": null,
    "ram_total_mb": null,
    "ram_used_mb": null,
    "ram_percent": null,
    "geo_location": null,
    "last_restart_request_at": null
  },
  "links": {
    "dashboard_local": null,
    "stream_local": null
  },
  "live_link": {
    "active": false,
    "url": null,
    "expires_at": null
  },
  "counts": {
    "HIGH": 0,
    "MEDIUM": 0,
    "LOW": 0
  },
  "last_person": {
    "detected": false,
    "time": null,
    "image": null,
	"count": 0,
	"best_confidence": 0.0,
	"stable_inside_sec": 0.0,
	"stable_required_sec": 5.0,
	"stable_hit_count": 0
  },
  "last_garbage": {
    "detected": false,
    "time": null,
    "image": null,
    "severity": null,
    "diff_ratio": 0.0,
    "edge_ratio": 0.0,
    "blob_area_ratio": 0.0,
    "blob_count": 0,
    "triggered_by": null,
    "reference_items": [
      "Dust",
      "Bags",
      "Covers",
      "Carry bags",
      "Box",
      "Leaf",
      "Slippers",
      "Shoes",
      "Paper",
      "Notebooks",
      "Cloths",
      "Dress"
    ]
  },
  "last_audio": {
    "file": null,
    "source_path": null,
    "time": null,
    "status": null
  },
  "events": []
}
JSON

sudo tee "$MAINT_SCRIPT" >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
LOG_FILE="/var/log/gcam-maintenance.log"
{
  echo "=================================================="
  echo "G-Cam maintenance started at $(date '+%Y-%m-%d %H:%M:%S')"
  apt-get update
  apt-get -y autoremove
  apt-get -y autoclean
  journalctl --vacuum-time=3d || true
  sync
  echo "G-Cam maintenance completed at $(date '+%Y-%m-%d %H:%M:%S')"
} >> "$LOG_FILE" 2>&1
EOF
sudo chmod +x "$MAINT_SCRIPT"

sudo tee "$MAINT_SERVICE" >/dev/null <<EOF
[Unit]
Description=G-Cam Maintenance Job
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$MAINT_SCRIPT
EOF

sudo tee "$MAINT_TIMER" >/dev/null <<EOF
[Unit]
Description=Run G-Cam maintenance twice daily

[Timer]
OnCalendar=*-*-* 02:45:00
OnCalendar=*-*-* 14:45:00
Persistent=true
Unit=gcam-maintenance.service

[Install]
WantedBy=timers.target
EOF

sudo tee "$APP_RESTART_SERVICE" >/dev/null <<EOF
[Unit]
Description=Restart G-Cam app service

[Service]
Type=oneshot
ExecStart=/usr/bin/systemctl restart gcam.service
EOF

sudo tee "$APP_RESTART_TIMER" >/dev/null <<EOF
[Unit]
Description=Restart G-Cam app every 3 hours

[Timer]
OnCalendar=*-*-* 00,03,06,09,12,15,18,21:00:00
Persistent=true
Unit=gcam-app-restart.service

[Install]
WantedBy=timers.target
EOF

sudo tee "$PI_REBOOT_SERVICE" >/dev/null <<EOF
[Unit]
Description=Reboot Raspberry Pi for G-Cam stability

[Service]
Type=oneshot
ExecStart=/usr/bin/systemctl reboot
EOF

sudo tee "$PI_REBOOT_TIMER" >/dev/null <<EOF
[Unit]
Description=Reboot Raspberry Pi twice daily

[Timer]
OnCalendar=*-*-* ${REBOOT_TIME_1}
OnCalendar=*-*-* ${REBOOT_TIME_2}
# Never execute a missed reboot immediately after boot or NTP clock sync.
Persistent=false
AccuracySec=1min
RandomizedDelaySec=0
Unit=gcam-pi-reboot.service

[Install]
WantedBy=timers.target
EOF

sudo tee "$SERVICE_FILE" >/dev/null <<EOF
[Unit]
Description=G-Cam RealTech Systems
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$PI_USER
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV_DIR/bin/python $APP_DIR/app.py
Restart=always
RestartSec=5
TimeoutStopSec=10
KillSignal=SIGINT
KillMode=mixed

[Install]
WantedBy=multi-user.target
EOF
sudo tee "$CONTROLLER_SERVICE_FILE" >/dev/null <<EOF
[Unit]
Description=G-Cam MQTT Controller
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$PI_USER
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV_DIR/bin/python $APP_DIR/controller.py
Restart=always
RestartSec=5
TimeoutStopSec=10
KillSignal=SIGINT
KillMode=mixed

[Install]
WantedBy=multi-user.target
EOF

sudo chown -R "$PI_USER:$PI_USER" "$APP_DIR"

echo "[INFO] Camera config permanent URL: ${PERMANENT_CAMERA_CONFIG_URL}"
echo "[INFO] SUB stream is used for AI detection and live view: ${CLOUDFLARE_LIVE_RTSP_URL}"
echo "[INFO] MAIN stream is used for high-quality image/video SFTP uploads: ${RTSP_URL}"
echo "[INFO] Permanent live URL remains: ${PERMANENT_LIVE_BASE_URL}/live"
echo "[INFO] Storage-based playback URL: ${PERMANENT_LIVE_BASE_URL}/playback"
echo "[INFO] Playback recorder reuses the local shared SUB live feed (no second camera RTSP session)."
echo "[INFO] MQTT Playback URL includes play/pause, forward/reverse, 0.5x-8x speed, seek and fullscreen controls."
echo "[INFO] Clean reinstall erases all old local playback recordings before installation."
echo "[INFO] Camera config target URL remains: ${CAMERA_CONFIG_URL}"


echo "[PATCH] Configure permanent Cloudflare service and watchdog..."

if [[ "$ENABLE_PERMANENT_CLOUDFLARE" == "yes" ]]; then
  sudo install -d -m 700 -o root -g root "$CLOUDFLARE_TOKEN_DIR"
  printf '%s\n' "$CLOUDFLARE_TUNNEL_TOKEN" | sudo tee "$CLOUDFLARE_TOKEN_FILE" >/dev/null
  sudo chown root:root "$CLOUDFLARE_TOKEN_FILE"
  sudo chmod 600 "$CLOUDFLARE_TOKEN_FILE"

  sudo tee "$CLOUDFLARE_SERVICE_FILE" >/dev/null <<EOF
[Unit]
Description=G-Cam Permanent Cloudflare Tunnel
Documentation=https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
TimeoutStartSec=60
# Keep this comfortably below the MQTT controller's systemctl timeout so a
# stuck cloudflared process is force-killed before the controller gives up.
TimeoutStopSec=15
ExecStartPre=/usr/bin/test -s ${CLOUDFLARE_TOKEN_FILE}
ExecStart=/usr/bin/cloudflared tunnel --no-autoupdate --protocol ${CLOUDFLARE_PROTOCOL} --loglevel info --metrics ${CLOUDFLARE_METRICS_ADDR} run --token-file ${CLOUDFLARE_TOKEN_FILE}
Restart=always
RestartSec=5
KillSignal=SIGTERM
KillMode=control-group
SendSIGKILL=yes

[Install]
WantedBy=multi-user.target
EOF

  sudo tee "$CLOUDFLARE_WATCHDOG_SCRIPT" >/dev/null <<'EOF'
#!/usr/bin/env bash
set -uo pipefail

PUBLIC_URL="__PUBLIC_HEALTH_URL__"
LOCAL_URL="__LOCAL_HEALTH_URL__"
READY_URL="__READY_URL__"
CLOUDFLARE_SERVICE="cloudflared.service"
GCAM_SERVICE="gcam.service"

LOG_FILE="/opt/gcam/logs/cloudflare_watchdog.log"
FAILURE_FILE="/run/gcam-cloudflare-watchdog.failures"
LAST_RESTART_FILE="/run/gcam-cloudflare-watchdog.last-restart"
LOCK_FILE="/run/gcam-cloudflare-watchdog.lock"

MAX_FAILURES=2
RESTART_COOLDOWN_SEC=180
CONNECT_TIMEOUT_SEC=5
TOTAL_TIMEOUT_SEC=15
POST_RESTART_WAIT_SEC=12

mkdir -p "$(dirname "$LOG_FILE")"
exec 9>"$LOCK_FILE"
flock -n 9 || exit 0

rotate_log_if_needed() {
  local max_bytes=$((5 * 1024 * 1024))
  local current_bytes=0

  if [[ -f "$LOG_FILE" ]]; then
    current_bytes="$(stat -c '%s' "$LOG_FILE" 2>/dev/null || echo 0)"
  fi

  if (( current_bytes >= max_bytes )); then
    mv -f "$LOG_FILE" "${LOG_FILE}.1" 2>/dev/null || true
  fi
}

log_message() {
  local message="$*"
  rotate_log_if_needed
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$message" >> "$LOG_FILE"
  logger -t gcam-cloudflare-watchdog -- "$message" 2>/dev/null || true
}

read_number_file() {
  local path="$1"
  local default_value="$2"
  local value

  if [[ ! -f "$path" ]]; then
    printf '%s' "$default_value"
    return
  fi

  value="$(cat "$path" 2>/dev/null || true)"
  if [[ "$value" =~ ^[0-9]+$ ]]; then
    printf '%s' "$value"
  else
    printf '%s' "$default_value"
  fi
}

write_number_file() {
  local path="$1"
  local value="$2"
  printf '%s\n' "$value" > "$path"
}

http_status() {
  local url="$1"

  curl \
    --silent \
    --show-error \
    --output /dev/null \
    --write-out '%{http_code}' \
    --connect-timeout "$CONNECT_TIMEOUT_SEC" \
    --max-time "$TOTAL_TIMEOUT_SEC" \
    --user-agent 'GCam-Cloudflare-Watchdog/2.0' \
    "$url" 2>/dev/null
}

local_origin_is_healthy() {
  local code
  code="$(http_status "$LOCAL_URL")" || return 1
  [[ "$code" =~ ^2[0-9][0-9]$ ]]
}

connector_is_ready() {
  local code
  code="$(http_status "$READY_URL")" || return 1
  [[ "$code" == "200" ]]
}

public_tunnel_is_healthy() {
  local code
  code="$(http_status "$PUBLIC_URL")" || return 1

  case "$code" in
    2??|3??|4??) return 0 ;;
    *) return 1 ;;
  esac
}

restart_unit() {
  local unit="$1"

  log_message "Restarting ${unit}"
  if systemctl restart "$unit"; then
    log_message "Restart command succeeded for ${unit}"
    return 0
  fi

  log_message "ERROR: Restart command failed for ${unit}"
  return 1
}

restart_cloudflare_with_cooldown() {
  local reason="$1"
  local now last_restart elapsed

  now="$(date +%s)"
  last_restart="$(read_number_file "$LAST_RESTART_FILE" 0)"
  elapsed=$((now - last_restart))

  if (( elapsed < RESTART_COOLDOWN_SEC )); then
    log_message "Cloudflare restart suppressed by cooldown after ${reason}; ${elapsed}s elapsed of ${RESTART_COOLDOWN_SEC}s"
    return 0
  fi

  log_message "${reason}; restarting Cloudflare connector"
  restart_unit "$CLOUDFLARE_SERVICE" || true
  write_number_file "$LAST_RESTART_FILE" "$now"
  write_number_file "$FAILURE_FILE" 0

  sleep "$POST_RESTART_WAIT_SEC"

  if connector_is_ready; then
    if public_tunnel_is_healthy; then
      log_message "Permanent Cloudflare tunnel recovered after restart"
    else
      log_message "WARNING: Connector is ready, but public hostname is unavailable. Check hostname-to-tunnel route and http://localhost:8080 service mapping."
    fi
  else
    log_message "WARNING: Connector is still not ready after restart. Check token, DNS, outbound port 7844, and journalctl -u cloudflared.service."
  fi
}

record_failure_and_maybe_restart() {
  local reason="$1"
  local failures

  failures="$(read_number_file "$FAILURE_FILE" 0)"
  failures=$((failures + 1))
  write_number_file "$FAILURE_FILE" "$failures"
  log_message "${reason}; failure ${failures}/${MAX_FAILURES}"

  if (( failures >= MAX_FAILURES )); then
    restart_cloudflare_with_cooldown "$reason"
  fi
}

main() {
  local previous_failures

  if ! systemctl is-active --quiet "$GCAM_SERVICE"; then
    log_message "${GCAM_SERVICE} is inactive; restarting local application"
    restart_unit "$GCAM_SERVICE" || true
    write_number_file "$FAILURE_FILE" 0
    exit 0
  fi

  if ! local_origin_is_healthy; then
    log_message "Local origin failed at ${LOCAL_URL}; restarting ${GCAM_SERVICE}"
    restart_unit "$GCAM_SERVICE" || true
    write_number_file "$FAILURE_FILE" 0
    exit 0
  fi

  if ! systemctl is-active --quiet "$CLOUDFLARE_SERVICE"; then
    log_message "${CLOUDFLARE_SERVICE} is inactive; restarting permanent tunnel"
    restart_unit "$CLOUDFLARE_SERVICE" || true
    write_number_file "$FAILURE_FILE" 0
    write_number_file "$LAST_RESTART_FILE" "$(date +%s)"
    exit 0
  fi

  if ! connector_is_ready; then
    record_failure_and_maybe_restart "Cloudflare connector readiness endpoint failed at ${READY_URL}"
    exit 0
  fi

  if ! public_tunnel_is_healthy; then
    record_failure_and_maybe_restart "Permanent URL is unavailable at ${PUBLIC_URL}"
    exit 0
  fi

  previous_failures="$(read_number_file "$FAILURE_FILE" 0)"
  if (( previous_failures > 0 )); then
    log_message "Permanent Cloudflare URL recovered: ${PUBLIC_URL}"
  fi
  write_number_file "$FAILURE_FILE" 0
}

main "$@"
EOF

  sudo sed -i \
    -e "s|__PUBLIC_HEALTH_URL__|${PERMANENT_HEALTH_URL}|g" \
    -e "s|__LOCAL_HEALTH_URL__|${LOCAL_HEALTH_URL}|g" \
    -e "s|__READY_URL__|${CLOUDFLARE_READY_URL}|g" \
    "$CLOUDFLARE_WATCHDOG_SCRIPT"
  sudo chmod 755 "$CLOUDFLARE_WATCHDOG_SCRIPT"
  sudo chown root:root "$CLOUDFLARE_WATCHDOG_SCRIPT"

  sudo tee "$CLOUDFLARE_WATCHDOG_SERVICE" >/dev/null <<EOF
[Unit]
Description=G-Cam Permanent Cloudflare Tunnel Health Check
After=network-online.target gcam.service cloudflared.service
Wants=network-online.target

[Service]
Type=oneshot
User=root
ExecStart=$CLOUDFLARE_WATCHDOG_SCRIPT
EOF

  sudo tee "$CLOUDFLARE_WATCHDOG_TIMER" >/dev/null <<EOF
[Unit]
Description=Check G-Cam Permanent Cloudflare Tunnel Every Minute

[Timer]
OnBootSec=45s
OnUnitActiveSec=60s
AccuracySec=5s
RandomizedDelaySec=3s
Persistent=false
Unit=gcam-cloudflare-watchdog.service

[Install]
WantedBy=timers.target
EOF
else
  sudo rm -f "$CLOUDFLARE_SERVICE_FILE" "$CLOUDFLARE_WATCHDOG_SERVICE" "$CLOUDFLARE_WATCHDOG_TIMER"
  sudo rm -f "$CLOUDFLARE_WATCHDOG_SCRIPT"
  echo "[WARNING] Permanent Cloudflare service was not configured by this installer."
fi

echo "[FINAL] Python compile check..."
sudo -u "$PI_USER" "$VENV_DIR/bin/python" -m py_compile "$APP_DIR/app.py"
sudo -u "$PI_USER" "$VENV_DIR/bin/python" -m py_compile "$APP_DIR/controller.py"

sudo systemctl daemon-reload
sudo systemctl enable gcam.service
sudo systemctl restart gcam.service
sudo systemctl enable gcam-controller.service
sudo systemctl restart gcam-controller.service
sudo systemctl enable --now gcam-maintenance.timer
sudo systemctl enable --now gcam-app-restart.timer

if [[ "$ENABLE_PERMANENT_CLOUDFLARE" == "yes" ]]; then
  sudo systemctl enable cloudflared.service
  sudo systemctl restart cloudflared.service
  sudo systemctl enable --now gcam-cloudflare-watchdog.timer

  # Run one immediate check after the app and connector have had time to start.
  sleep 5
  sudo systemctl start gcam-cloudflare-watchdog.service 2>/dev/null || true
else
  sudo systemctl disable --now cloudflared.service 2>/dev/null || true
  sudo systemctl disable --now gcam-cloudflare-watchdog.timer 2>/dev/null || true
fi

# Full Pi reboot scheduling is opt-in. Keeping it disabled avoids reboot loops
# caused by stale timer catch-up after network time synchronization.
sudo systemctl disable --now gcam-pi-reboot.timer 2>/dev/null || true
if [[ "$ENABLE_PI_REBOOT_TIMER" == "yes" ]]; then
  sudo systemctl enable --now gcam-pi-reboot.timer
  echo "[INFO] Automatic Pi reboot timer enabled at ${REBOOT_TIME_1} and ${REBOOT_TIME_2}."
else
  echo "[INFO] Automatic Pi reboot timer disabled."
fi

if [[ "$ENABLE_PERMANENT_CLOUDFLARE" == "yes" ]]; then
  echo "[VERIFY] Checking Cloudflare connector readiness..."
  CLOUDFLARE_CONNECTOR_OK="no"

  for _ in $(seq 1 24); do
    READY_CODE="$(curl --silent --output /dev/null --write-out '%{http_code}' --connect-timeout 3 --max-time 5 "$CLOUDFLARE_READY_URL" 2>/dev/null || true)"
    if [[ "$READY_CODE" == "200" ]]; then
      CLOUDFLARE_CONNECTOR_OK="yes"
      break
    fi
    sleep 2
  done

  if [[ "$CLOUDFLARE_CONNECTOR_OK" != "yes" ]]; then
    echo "[WARNING] cloudflared is installed, but no healthy connector reached Cloudflare."
    echo "[WARNING] Check the tunnel token, DNS, and outbound TCP/UDP port 7844."
    echo "[WARNING] Run: sudo journalctl -u cloudflared.service -n 200 --no-pager"
  else
    echo "[OK] Cloudflare connector is ready."
    echo "[VERIFY] Checking permanent Cloudflare hostname..."
    CLOUDFLARE_PUBLIC_OK="no"

    for _ in $(seq 1 12); do
      HTTP_CODE="$(curl --silent --output /dev/null --write-out '%{http_code}' --connect-timeout 5 --max-time 15 "$PERMANENT_HEALTH_URL" 2>/dev/null || true)"
      case "$HTTP_CODE" in
        2??|3??|4??)
          CLOUDFLARE_PUBLIC_OK="yes"
          break
          ;;
      esac
      sleep 5
    done

    if [[ "$CLOUDFLARE_PUBLIC_OK" == "yes" ]]; then
      echo "[OK] Permanent Cloudflare URL is responding: ${PERMANENT_LIVE_BASE_URL}"
    else
      echo "[WARNING] Connector is ready, but the permanent hostname still does not respond."
      echo "[WARNING] In Cloudflare, map ${SUBDOMAIN_NAME}.${BASE_DOMAIN} to THIS tunnel and set service http://localhost:8080."
      echo "[WARNING] A hostname routed to a different tunnel token will continue to show Error 1033."
    fi
  fi
fi

echo "=================================================="
echo " FULL CLEAN REINSTALL COMPLETED"
echo "=================================================="
echo "Dashboard                : http://${PI_IP}:8080"
echo "Live only                : http://${PI_IP}:8080/live"
echo "Camera config Target URL : ${CAMERA_CONFIG_URL}"
echo "Permanent Camera URL    : ${PERMANENT_CAMERA_CONFIG_URL}"
echo "Permanent Dashboard URL  : ${PERMANENT_LIVE_BASE_URL}"
echo "Permanent Live URL       : ${PERMANENT_LIVE_BASE_URL}/live"
echo "Permanent CF Managed     : ${ENABLE_PERMANENT_CLOUDFLARE}"
echo "Cloudflare Protocol      : ${CLOUDFLARE_PROTOCOL}"
echo "MQTT Command Topic       : ${MQTT_COMMAND_TOPIC}"
echo "MQTT Response Topic      : ${MQTT_RESPONSE_TOPIC}"
echo "Automatic Pi Reboots    : ${ENABLE_PI_REBOOT_TIMER}"
echo "SFTP Base Path           : ${SFTP_BASE_DIR}"
echo "SFTP Garbage Path        : ${SFTP_GARBAGE_DIR}"
echo "SFTP Audio Path          : ${SFTP_AUDIO_DIR}"
echo
echo "New MQTT commands:"
echo '  {"command":"Close The Software","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Open The Software","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Cloudflare Restart","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Cloudflare Status","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Camera Permanent URL","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Person Detection Enable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Person Detection Disable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Vehicle Detection Enable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Vehicle Detection Disable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Person Video Recording Enable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Person Video Recording Disable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Vehicle Video Recording Enable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo '  {"command":"Vehicle Video Recording Disable","token":"'"${MQTT_COMMAND_TOKEN}"'"}'
echo
echo "Check app service:"
echo "  sudo systemctl status gcam.service --no-pager"
echo
echo "Check controller service:"
echo "  sudo systemctl status gcam-controller.service --no-pager"
echo
echo "Check app logs:"
echo "  journalctl -u gcam.service -n 100 --no-pager"
echo
echo "Check controller logs:"
echo "  journalctl -u gcam-controller.service -n 100 --no-pager"
echo
if [[ "$ENABLE_PERMANENT_CLOUDFLARE" == "yes" ]]; then
  echo "Check permanent Cloudflare service:"
  echo "  sudo systemctl status cloudflared.service --no-pager"
  echo "  sudo journalctl -u cloudflared.service -n 200 --no-pager"
  echo
  echo "Check permanent Cloudflare watchdog:"
  echo "  sudo systemctl status gcam-cloudflare-watchdog.timer --no-pager"
  echo "  sudo journalctl -u gcam-cloudflare-watchdog.service -n 100 --no-pager"
  echo "  sudo tail -n 100 /opt/gcam/logs/cloudflare_watchdog.log"
  echo
fi
echo "Check timers:"
echo "  systemctl list-timers --all | grep gcam"
echo
echo "Battery reader script:"
echo "  sudo nano ${BATTERY_SCRIPT}"
